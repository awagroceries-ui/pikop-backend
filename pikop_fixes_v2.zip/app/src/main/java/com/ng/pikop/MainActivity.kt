package com.ng.pikop

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.ui.Alignment
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Build
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.navArgument
import androidx.navigation.compose.*
import com.google.android.gms.maps.model.LatLng
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.FirebaseApp
import com.ng.pikop.core.datastore.TokenManager
import com.ng.pikop.core.network.ApiService
import com.ng.pikop.core.cart.CartManager
import com.ng.pikop.feature.auth.*
import com.ng.pikop.feature.chat.*
import com.ng.pikop.feature.commerce.CommerceCheckoutScreen
import com.ng.pikop.feature.commerce.StorefrontScreen
import com.ng.pikop.feature.fleetpartner.FleetPartnerDashboardScreen
import com.ng.pikop.feature.fulfiller.*
import com.ng.pikop.feature.merchant.AddEditProductScreen
import com.ng.pikop.feature.merchant.BulkDispatchScreen
import com.ng.pikop.feature.merchant.MerchantPortalScreen
import com.ng.pikop.feature.order.*
import com.ng.pikop.feature.growth.GrowthRewardsScreen
import com.ng.pikop.feature.merchant.MerchantPortalScreen
import com.ng.pikop.feature.wallet.WalletScreen
import com.ng.pikop.feature.wallet.WithdrawalScreen
import com.ng.pikop.ui.components.CelebrationViewModel
import com.ng.pikop.ui.components.SuccessCelebrationOverlay
import com.ng.pikop.ui.theme.PikopTheme
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    private val _intentFlow = MutableStateFlow<Intent?>(null)
    val intentFlow = _intentFlow.asStateFlow()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            android.util.Log.d("PikopLifecycle", "MainActivity onCreate - START (Process: ${android.os.Process.myPid()})")
            enableEdgeToEdge()
            
            // Initial intent
            _intentFlow.value = intent

            setContent {
                PikopTheme {
                    SideEffect {
                        android.util.Log.d("PikopLifecycle", "MainActivity - First Frame Rendered")
                    }
                    PikopAppNavigation(intentFlow = intentFlow)
                }
            }
            android.util.Log.d("PikopLifecycle", "MainActivity onCreate - SUCCESS")
        } catch (e: Throwable) {
            android.util.Log.e("PikopLifecycle", "CRITICAL CRASH IN ONCREATE: ${e.message}", e)
            // Show toast if possible or just crash with log
            throw e
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        _intentFlow.value = intent
        android.util.Log.d("PikopLifecycle", "MainActivity onNewIntent: ${intent.data}")
    }

    override fun onDestroy() {
        super.onDestroy()
        android.util.Log.d("PikopLifecycle", "MainActivity onDestroy")
    }
}

@Composable
fun PikopAppNavigation(intentFlow: kotlinx.coroutines.flow.StateFlow<Intent?>) {
    val navController = rememberNavController()
    val celebrationViewModel: CelebrationViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
    val context = LocalContext.current
    val tokenManager = remember { TokenManager(context) }
    val scope = rememberCoroutineScope()
    
    val incomingIntent by intentFlow.collectAsState()
    val userEmail by tokenManager.userEmail.collectAsState(initial = null)
    val userId by tokenManager.userId.collectAsState(initial = null)
    val userName by tokenManager.userName.collectAsState(initial = null)
    val userPhone by tokenManager.userPhone.collectAsState(initial = null)
    val userRole by tokenManager.userRole.collectAsState(initial = null)
    val isVerified by tokenManager.isVerified.collectAsState(initial = false)
    val referralCode by tokenManager.referralCode.collectAsState(initial = null)
    val kycStatus by tokenManager.kycStatus.collectAsState(initial = null)
    val accessToken by tokenManager.accessToken.collectAsState(initial = null)

    // SESSION GUARD: Prevent flickering until storage is read
    var isSessionLoaded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        // Wait for first non-null emission or timeout
        kotlinx.coroutines.withTimeoutOrNull(2000) {
            tokenManager.accessToken.first()
        }
        isSessionLoaded = true
    }

    if (!isSessionLoaded) {
        Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    // Global Session Monitor
    LaunchedEffect(Unit) {
        tokenManager.sessionEvents.collect { event ->
            if (event == TokenManager.SessionEvent.EXPIRED) {
                tokenManager.clearTokens()
                navController.navigate("login") {
                    popUpTo(0) { inclusive = true }
                }
                android.widget.Toast.makeText(context, "Session expired. Please sign in again.", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    // Redirect to OTP if not verified (Strict Gating)
    LaunchedEffect(accessToken, isVerified) {
        if (accessToken != null && !isVerified) {
            // Check current destination to avoid infinite loop
            val current = navController.currentDestination?.route
            if (current != null && !current.startsWith("email_otp") && current != "splash" && !current.startsWith("terms")) {
                navController.navigate("email_otp/$userEmail/$userRole") {
                    popUpTo(0) { inclusive = true }
                }
            }
        }
    }

    // Notification Permission Request
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            android.util.Log.d("PikopFCM", "Notification permission granted")
        }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    // Handle Intent Deep-linking
    LaunchedEffect(incomingIntent) {
        val intent = incomingIntent ?: return@LaunchedEffect
        val dataUri = intent.data
        val navigateTo = intent.getStringExtra("navigate_to")
        val orderId = intent.getStringExtra("order_id")
        val conversationId = intent.getStringExtra("conversation_id")

        android.util.Log.d("PikopIntent", "Processing intent: $dataUri | navigate_to: $navigateTo | orderId: $orderId | conversationId: $conversationId")

        // 1. Handle Scheme-based Deep Links (e.g. pikop://payment/success)
        if (dataUri != null && dataUri.scheme == "pikop") {
            if (dataUri.host == "payment" && dataUri.path == "/success") {
                val reference = dataUri.getQueryParameter("reference") ?: ""
                navController.navigate("confirm_payment/$reference")
            } else if (dataUri.host == "store") {
                val slug = dataUri.lastPathSegment
                if (slug != null) {
                    scope.launch {
                        try {
                            val api = ApiService.create(tokenManager)
                            val res = api.getMerchantBySlug(slug)
                            res.data?.let { merchant ->
                                // Route to correct storefront with merchant filter
                                val base = if (merchant.type == "vendor") "storefront_shop" else "storefront_food"
                                navController.navigate("$base?merchantId=${merchant.id}")
                                android.util.Log.d("DeepLink", "Resolved store: ${merchant.id} (${merchant.type})")
                            }
                        } catch (e: Exception) {
                            android.util.Log.e("DeepLink", "Store resolution failed", e)
                        }
                    }
                }
            }
        // 1b. Handle the https://api.pikop.com.ng/track/{orderId} App Link
        // (the SMS tracking link customers receive). "pikop" scheme is
        // handled above; this is the ordinary https host+pathPrefix match
        // declared in AndroidManifest.xml.
        } else if (dataUri != null && dataUri.scheme == "https" && dataUri.host == "api.pikop.com.ng" &&
                   dataUri.pathSegments.firstOrNull() == "track") {
            val orderId = dataUri.lastPathSegment
            if (!orderId.isNullOrBlank()) {
                navController.navigate("track_order/$orderId")
            }
        }

        if (accessToken != null && navigateTo != null) {
            when (navigateTo) {
                "SUPPORT_CHAT", "chat" -> {
                    if (conversationId != null) {
                        navController.navigate("chat/$conversationId")
                    } else {
                        scope.launch {
                            try {
                                val api = ApiService.create(tokenManager)
                                val conv = api.getOrCreateSupportConversation()
                                navController.navigate("chat/${conv.id}")
                            } catch (_: Exception) {
                                navController.navigate("main")
                            }
                        }
                    }
                }
                "ORDER_CHAT" -> {
                    if (orderId != null) navController.navigate("order_chat/$orderId")
                    else navController.navigate("main")
                }
                "MISSION_OFFER" -> {
                    navController.navigate("main")
                }
                "ACKNOWLEDGMENT_REQUEST" -> {
                    if (orderId != null) navController.navigate("order_acknowledgment/$orderId")
                    else navController.navigate("main")
                }
                "ORDER_UPDATE" -> {
                    if (orderId != null) {
                        if (userRole == "FULFILLER") navController.navigate("active_order/$orderId")
                        else navController.navigate("track_order/$orderId")
                    } else {
                        navController.navigate("main")
                    }
                }
                else -> navController.navigate("main")
            }
        }
    }

    // Profile Auto-Sync & Push Token Registration
    LaunchedEffect(accessToken) {
        val currentToken = accessToken ?: return@LaunchedEffect
        // Socket Connectivity
        userId?.let { com.ng.pikop.core.network.SocketManager.connect(it) }

        // 1. Sync Profile Data and Start Background Approval Monitoring
        scope.launch {
            while (true) {
                val activeToken = tokenManager.accessToken.first() ?: break
                try {
                    val api = ApiService.create(tokenManager)
                    val profile = api.getUserProfile()
                    
                    // Check if status changed
                    val currentKyc = tokenManager.kycStatus.first()
                    if (profile.kyc_status != currentKyc) {
                        android.util.Log.d("PikopSync", "KYC Status Update detected: ${profile.kyc_status}")
                    }

                    tokenManager.saveTokens(
                        accessToken = activeToken,
                        refreshToken = tokenManager.refreshToken.first() ?: "",
                        userId = userId,
                        email = userEmail ?: "",
                        role = profile.role ?: userRole ?: "CUSTOMER",
                        name = profile.full_name,
                        phone = profile.phone,
                        isVerified = isVerified,
                        referralCode = referralCode,
                        kycStatus = profile.kyc_status
                    )
                } catch (e: Exception) {
                    android.util.Log.e("PikopSync", "Profile sync failed: ${e.message}")
                }
                
                // If verified, we can stop or slow down polling
                val status = tokenManager.kycStatus.first()
                if (status == "VERIFIED") {
                    delay(300000) // 5 mins if verified
                } else {
                    delay(60000) // 1 min if pending/not started
                }
            }
        }

        // 2. FCM Token Registration
        try {
            val apps = FirebaseApp.getApps(context)
            if (apps.isNotEmpty()) {
                FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val token = task.result
                        android.util.Log.d("PikopFCM", "FCM Token retrieved: ${token.take(10)}...")
                        scope.launch {
                            try {
                                val api = ApiService.create(tokenManager)
                                val response = api.updateFCMToken(mapOf("token" to token))
                                android.util.Log.d("PikopFCM", "FCM Token registered: ${response.message}")
                            } catch (e: Exception) {
                                android.util.Log.e("PikopFCM", "FCM Token registration failed: ${e.message}")
                            }
                        }
                    } else {
                        android.util.Log.w("PikopFCM", "Fetching FCM registration token failed", task.exception)
                    }
                }
            } else {
                // Fallback: Try to initialize if somehow missed
                try {
                    FirebaseApp.initializeApp(context)
                } catch (e: Exception) {}
            }
        } catch (e: Throwable) {}
    }

    val showCelebration by celebrationViewModel.showCelebration.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            SplashScreen(onAnimationFinished = {
                if (accessToken != null) {
                    if (isVerified) {
                        navController.navigate("main") { popUpTo("splash") { inclusive = true } }
                    } else {
                        navController.navigate("email_otp/$userEmail/$userRole") { popUpTo("splash") { inclusive = true } }
                    }
                } else {
                    navController.navigate("user_type_selection") { popUpTo("splash") { inclusive = true } }
                }
            })
        }

        composable("user_type_selection") {
            UserTypeSelectionScreen(onRoleSelected = { role ->
                if (role == "LOGIN") navController.navigate("login")
                else if (role == "CUSTOMER") navController.navigate("signup_customer")
                else if (role == "FULFILLER") navController.navigate("fulfiller_category_selection")
                else if (role == "MERCHANT") navController.navigate("signup_merchant")
                else if (role == "FLEET_PARTNER") navController.navigate("signup_fleet")
                else if (role == "CORPORATE") navController.navigate("signup_corporate")
            })
        }
        
        composable("fulfiller_category_selection") {
            FulfillerCategorySelectionScreen(
                onCategorySelected = { category ->
                    navController.navigate("signup_fulfiller/$category")
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable("login") {
            LoginScreen(
                onLoginSuccess = { _ ->
                    navController.navigate("main") { popUpTo("login") { inclusive = true } }
                },
                onUnverified = { email, role ->
                    navController.navigate("email_otp/$email/$role")
                },
                onGoToSignup = { navController.navigate("user_type_selection") },
                onForgotPassword = { navController.navigate("forgot_password") }
            )
        }

        composable("forgot_password") {
            ForgotPasswordScreen(
                onBackToLogin = { navController.popBackStack() }
            )
        }

        composable("signup_customer") {
            SignupCustomerScreen(
                onSignupSuccess = { email, userRole ->
                    navController.navigate("email_otp/$email/$userRole")
                },
                onViewTerms = { navController.navigate("terms_viewer/false") },
                onViewPrivacy = { navController.navigate("privacy_policy") }
            )
        }
        
        composable(
            route = "signup_fulfiller/{category}",
            arguments = listOf(navArgument("category") { type = NavType.StringType })
        ) { backStackEntry ->
            val category = backStackEntry.arguments?.getString("category") ?: "RIDER"
            SignupFulfillerScreen(
                category = category,
                onSignupSuccess = { email, userRole ->
                    navController.navigate("email_otp/$email/$userRole")
                },
                onViewTerms = { navController.navigate("terms_viewer/true") },
                onViewPrivacy = { navController.navigate("privacy_policy") }
            )
        }
        
        composable("signup_merchant") {
            SignupMerchantScreen(
                onSignupSuccess = { email, userRole ->
                    navController.navigate("email_otp/$email/$userRole")
                },
                onViewTerms = { navController.navigate("terms_viewer/false") },
                onViewPrivacy = { navController.navigate("privacy_policy") }
            )
        }

        composable("signup_fleet") {
            SignupFleetPartnerScreen(
                onSignupSuccess = { email, userRole ->
                    navController.navigate("email_otp/$email/$userRole")
                },
                onViewTerms = { navController.navigate("terms_viewer/false") },
                onViewPrivacy = { navController.navigate("privacy_policy") }
            )
        }

        composable("signup_corporate") {
            SignupCorporateScreen(
                onSignupSuccess = { email, userRole ->
                    navController.navigate("email_otp/$email/$userRole")
                },
                onViewTerms = { navController.navigate("terms_viewer/false") },
                onViewPrivacy = { navController.navigate("privacy_policy") }
            )
        }

        composable("email_otp/{email}/{role}") { backStackEntry ->
            val email = backStackEntry.arguments?.getString("email") ?: ""
            val role = backStackEntry.arguments?.getString("role") ?: "CUSTOMER"
            EmailOtpScreen(
                email = email, 
                onVerificationSuccess = { 
                    if (role == "MERCHANT") {
                        navController.navigate("merchant_business_setup") {
                            popUpTo(0) { inclusive = true }
                        }
                    } else if (role == "FLEET_PARTNER") {
                        navController.navigate("fleet_business_setup") {
                            popUpTo(0) { inclusive = true }
                        }
                    } else {
                        // Skip redundant terms screen as consent was captured at signup
                        navController.navigate("main") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                },
                onLogout = {
                    scope.launch {
                        tokenManager.clearTokens()
                        navController.navigate("user_type_selection") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            )
        }

        composable("merchant_business_setup") {
            com.ng.pikop.feature.auth.MerchantBusinessSetupScreen(
                navController = navController,
                onSetupSuccess = {
                    navController.navigate("main") {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable("fleet_business_setup") {
            FleetPartnerBusinessSetupScreen(
                onSetupSuccess = {
                    navController.navigate("main") {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable("corporate_business_setup") {
            CorporateBusinessSetupScreen(
                onSetupSuccess = {
                    navController.navigate("main") {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }

        composable("main") {
            if (userRole == "MERCHANT") {
                com.ng.pikop.feature.merchant.MerchantAppScaffold(
                    rootNavController = navController,
                    userEmail = userEmail ?: "",
                    userName = userName ?: "",
                    userRole = userRole ?: "MERCHANT",
                    tokenManager = tokenManager,
                    onCelebration = { celebrationViewModel.trigger() }
                )
            } else if (userRole == "FLEET_PARTNER") {
                FleetPartnerDashboardScreen(
                    onLogout = {
                        scope.launch {
                            tokenManager.clearTokens()
                            navController.navigate("user_type_selection") {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    }
                )
            } else if (userRole == "CORPORATE") {
                CorporateDashboardScreen(
                    onBack = {
                        scope.launch {
                            tokenManager.clearTokens()
                            navController.navigate("user_type_selection") {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    }
                )
            } else {
                MainAppScaffold(
                    navController = navController,
                    userEmail = userEmail ?: "",
                    userName = userName ?: "",
                    userPhone = userPhone ?: "",
                    userRole = userRole ?: "CUSTOMER",
                    referralCode = referralCode ?: "",
                    kycStatus = kycStatus,
                    tokenManager = tokenManager,
                    onCelebration = { celebrationViewModel.trigger() }
                )
            }
        }

        // Sub-flows (Full screen)
        composable("active_order/{orderId}") { backStackEntry ->
            val orderId = backStackEntry.arguments?.getString("orderId") ?: ""
            ActiveOrderScreen(
                orderId = orderId, 
                onOrderCompleted = { navController.popBackStack() },
                onBack = { navController.popBackStack() },
                onNavigateToChat = { id -> navController.navigate("order_chat/$id") }
            )
        }
        composable("order_acknowledgment/{orderId}") { backStackEntry ->
            val orderId = backStackEntry.arguments?.getString("orderId") ?: ""
            OrderAcknowledgmentScreen(
                orderId = orderId,
                onSuccess = { navController.navigate("main") { popUpTo(0) { inclusive = true } } },
                onBack = { navController.popBackStack() }
            )
        }
        composable("track_order/{orderId}") { backStackEntry ->
            val orderId = backStackEntry.arguments?.getString("orderId") ?: ""
            TrackOrderScreen(
                orderId = orderId,
                onCelebration = { celebrationViewModel.trigger() }
            )
        }
        composable("confirm_payment/{reference}") { backStackEntry ->
            val reference = backStackEntry.arguments?.getString("reference") ?: ""
            PaymentConfirmationScreen(
                reference = reference,
                onCelebration = { celebrationViewModel.trigger() },
                onConfirmed = { orderId ->
                    if (orderId.isNotBlank()) {
                        navController.navigate("track_order/$orderId") {
                            popUpTo("main") { inclusive = false }
                        }
                    } else {
                        navController.navigate("main") {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                },
                onFailed = { _ ->
                    navController.navigate("main") {
                        popUpTo(0) { inclusive = true }
                    }
                }
            )
        }
        composable("order_quote") {
            OrderQuoteScreen(
                navController = navController,
                userEmail = userEmail ?: "",
                userName = userName ?: "",
                userPhone = userPhone ?: "",
                onOrderComplete = {
                    navController.navigate("main") {
                        popUpTo("main") { inclusive = true }
                    }
                },
                onCelebration = { celebrationViewModel.trigger() },
                onNavigateToPayment = { url, qId, pLat, pLng, dLat, dLng, itemUrl, pSum, dSum, rName, rPhone, notes, promoId ->
                    CheckoutHelper.activeQuote = CheckoutHelper.CheckoutData(
                        url = url,
                        quoteId = qId,
                        pLat = pLat,
                        pLng = pLng,
                        dLat = dLat,
                        dLng = dLng,
                        itemPhotoUrl = itemUrl,
                        pickupSummary = pSum,
                        deliverySummary = dSum,
                        recipientName = rName,
                        recipientPhone = rPhone,
                        notes = notes,
                        promoId = promoId
                    )
                    // Use the in-app WebView (not an external browser Intent).
                    // An external browser hands the whole checkout session off to
                    // Chrome, which relies on a programmatic (non user-tap)
                    // redirect to the pikop:// scheme succeeding to bring the
                    // user back — Chrome frequently blocks or silently drops
                    // that kind of redirect, which is why real (non-free)
                    // payments appeared to "complete on Paystack but never
                    // start the mission". The in-app WebView intercepts the
                    // redirect itself via shouldOverrideUrlLoading, with no
                    // hand-off and no dependency on an external app honoring
                    // a custom-scheme redirect.
                    navController.navigate("payment_webview")
                }
            )
        }
        composable("payment_webview") {
            val checkoutUrl = CheckoutHelper.activeQuote?.url
            if (checkoutUrl.isNullOrBlank()) {
                LaunchedEffect(Unit) {
                    navController.navigate("main") { popUpTo(0) { inclusive = true } }
                }
            } else {
                PaymentWebView(
                    url = checkoutUrl,
                    onSuccess = { reference, _ ->
                        navController.navigate("confirm_payment/$reference") {
                            popUpTo("order_quote") { inclusive = true }
                        }
                    },
                    onCancel = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }
        }
        composable("kyc_upload") {
            KycUploadScreen(userEmail = userEmail ?: "", onBack = { navController.popBackStack() })
        }
        composable("chat/{conversationId}") { backStackEntry ->
            val conversationId = backStackEntry.arguments?.getString("conversationId") ?: ""
            ChatScreen(
                conversationId = conversationId, 
                userId = userId?.toIntOrNull() ?: 0, 
                userRole = userRole ?: "CUSTOMER", 
                onBack = { navController.popBackStack() }
            )
        }
        composable("order_chat/{orderId}") { backStackEntry ->
            val orderId = backStackEntry.arguments?.getString("orderId") ?: ""
            ChatScreen(
                orderId = orderId, 
                userId = userId?.toIntOrNull() ?: 0, 
                userRole = userRole ?: "CUSTOMER", 
                onBack = { navController.popBackStack() }
            )
        }
        composable("privacy_policy") { 
            LegalViewerScreen(
                title = "Privacy Policy",
                url = "https://api.pikop.com.ng/legal/privacy",
                onBack = { navController.popBackStack() }
            )
        }
        
        composable("terms_conditions") {
            LegalViewerScreen(
                title = "Terms & Conditions",
                url = "https://api.pikop.com.ng/legal/terms",
                onBack = { navController.popBackStack() }
            )
        }
        
        composable("terms_viewer/{showFulfillerTerms}") { backStackEntry ->
            val showFulfillerTerms = backStackEntry.arguments?.getString("showFulfillerTerms")?.toBoolean() ?: false
            LegalViewerScreen(
                title = if (showFulfillerTerms) "Fulfiller Conduct Policy & Terms" else "Terms & Conditions",
                url = if (showFulfillerTerms) "https://api.pikop.com.ng/legal/terms/fulfiller" else "https://api.pikop.com.ng/legal/terms",
                onBack = { navController.popBackStack() }
            )
        }
        composable("profile_edit") { ProfileEditScreen(onBack = { navController.popBackStack() }) }
        composable("growth_rewards") { 
            GrowthRewardsScreen(
                onBack = { navController.popBackStack() },
                onCelebration = { celebrationViewModel.trigger() }
            ) 
        }
        composable("merchant_portal") {
            MerchantPortalScreen(
                navController = navController,
                onAddItem = { type, id -> navController.navigate("add_edit_product/$type/$id") },
                onEditItem = { type, mId, pId -> navController.navigate("add_edit_product/$type/$mId?productId=$pId") },
                onCreateBatch = { navController.navigate("bulk_dispatch") },
                onBack = { navController.popBackStack() }
            )
        }
        composable(
            route = "add_edit_product/{merchantType}/{merchantId}?productId={productId}",
            arguments = listOf(
                navArgument("merchantType") { type = NavType.StringType },
                navArgument("merchantId") { type = NavType.StringType },
                navArgument("productId") { 
                    type = NavType.StringType
                    nullable = true
                    defaultValue = null 
                }
            )
        ) { backStackEntry ->
            val mType = backStackEntry.arguments?.getString("merchantType") ?: "vendor"
            val mId = backStackEntry.arguments?.getString("merchantId") ?: ""
            val pId = backStackEntry.arguments?.getString("productId")
            
            AddEditProductScreen(
                merchantType = mType,
                merchantId = mId,
                productId = pId,
                onSuccess = { navController.popBackStack() },
                onCelebration = { celebrationViewModel.trigger() },
                onBack = { navController.popBackStack() }
            )
        }
        composable("bulk_dispatch") {
            BulkDispatchScreen(
                navController = navController,
                onSuccess = { navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }
        composable("notifications_settings") { NotificationSettingsScreen(onBack = { navController.popBackStack() }) }
        composable("recipients_mgmt") { RecipientManagementScreen(onBack = { navController.popBackStack() }) }
        composable("session_mgmt") { SessionManagementScreen(onBack = { navController.popBackStack() }) }
        composable("corporate_dashboard") { CorporateDashboardScreen(onBack = { navController.popBackStack() }) }
        composable("insights") { InsightsScreen(onBack = { navController.popBackStack() }) }
        composable("saved_addresses") { 
            SavedAddressesScreen(
                navController = navController,
                onBack = { navController.popBackStack() }
            ) 
        }
        
        composable("map_address_search/{title}/{type}") { backStackEntry ->
            val title = backStackEntry.arguments?.getString("title") ?: "Location"
            val type = backStackEntry.arguments?.getString("type") ?: "pickup"
            MapAddressSearchScreen(
                title = title,
                onBack = { navController.popBackStack() },
                onAddressSelected = { address, lat, lng, state ->
                    navController.previousBackStackEntry?.savedStateHandle?.set("${type}_address", address)
                    navController.previousBackStackEntry?.savedStateHandle?.set("${type}_lat", lat)
                    navController.previousBackStackEntry?.savedStateHandle?.set("${type}_lng", lng)
                    navController.previousBackStackEntry?.savedStateHandle?.set("${type}_state", state)
                    navController.popBackStack()
                }
            )
        }

        composable("support_hub") {
            SupportHubScreen(
                userRole = userRole ?: "CUSTOMER",
                onNavigateToFaqList = { id -> navController.navigate("faq_detail/$id") },
                onNavigateToChat = {
                    scope.launch {
                        try {
                            val api = ApiService.create(tokenManager)
                            val conv = api.getOrCreateSupportConversation()
                            navController.navigate("chat/${conv.id}")
                        } catch (_: Exception) {}
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }
        composable("faq_detail/{articleId}") { backStackEntry ->
            val articleId = backStackEntry.arguments?.getString("articleId") ?: ""
            FaqDetailScreen(
                articleId = articleId,
                onBack = { navController.popBackStack() }
            )
        }

        // Removed internal payment_webview in favor of external intent
    }

    SuccessCelebrationOverlay(
        isVisible = showCelebration,
        onDismiss = { celebrationViewModel.dismiss() }
    )
}
}

@Composable
fun MainAppScaffold(
    navController: NavHostController,
    userEmail: String,
    userName: String,
    userPhone: String,
    userRole: String,
    referralCode: String,
    kycStatus: String? = null,
    tokenManager: TokenManager,
    onCelebration: () -> Unit = {}
) {
    val nestedNavController = rememberNavController()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    
    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                val navBackStackEntry by nestedNavController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination?.route

                NavigationBarItem(
                    icon = { Icon(Icons.Default.Home, contentDescription = null) },
                    label = { Text("Home") },
                    selected = currentDestination == "home",
                    onClick = { nestedNavController.navigate("home") { launchSingleTop = true } },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                        selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.6f),
                        unselectedTextColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.6f),
                        indicatorColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f)
                    )
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.History, contentDescription = null) },
                    label = { Text("Missions") },
                    selected = currentDestination == "history",
                    onClick = { nestedNavController.navigate("history") { launchSingleTop = true } },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                        selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.6f),
                        unselectedTextColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.6f),
                        indicatorColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f)
                    )
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Wallet, contentDescription = null) },
                    label = { Text("Wallet") },
                    selected = currentDestination == "wallet",
                    onClick = { nestedNavController.navigate("wallet") { launchSingleTop = true } },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                        selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.6f),
                        unselectedTextColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.6f),
                        indicatorColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f)
                    )
                )
                NavigationBarItem(
                    icon = { Icon(Icons.Default.Person, contentDescription = null) },
                    label = { Text("Menu") },
                    selected = currentDestination == "account",
                    onClick = { nestedNavController.navigate("account") { launchSingleTop = true } },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                        selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                        unselectedIconColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.6f),
                        unselectedTextColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.6f),
                        indicatorColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f)
                    )
                )
            }
        }
    ) { padding ->
        NavHost(
            navController = nestedNavController,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") {
                if (userRole == "FULFILLER") {
                    FulfillerDashboardScreen(
                        userEmail = userEmail ?: "",
                        kycStatus = kycStatus ?: "NOT_STARTED",
                        onAcceptOffer = { id -> navController.navigate("active_order/$id") },
                        onGoToWallet = { nestedNavController.navigate("wallet") },
                        onGoToKyc = { navController.navigate("kyc_upload") },
                        onGoToInsights = { navController.navigate("insights") },
                        onGoToAbout = { nestedNavController.navigate("account") },
                        onCelebration = onCelebration,
                        onLogout = {} 
                    )
                } else {
                    CustomerHomeScreen(
                        userEmail = userEmail,
                        userName = userName,
                        onNewDelivery = { navController.navigate("order_quote") },
                        onNavigateToFood = { nestedNavController.navigate("storefront_food") },
                        onNavigateToGroceries = { nestedNavController.navigate("storefront_groceries") },
                        onNavigateToShop = { nestedNavController.navigate("storefront_shop") },
                        onTrackOrder = { id -> navController.navigate("track_order/$id") },
                        onNavigateToAcknowledgment = { id -> navController.navigate("order_acknowledgment/$id") },
                        onNavigateToWallet = { nestedNavController.navigate("wallet") },
                        onNavigateToAddresses = { nestedNavController.navigate("account") },
                        onNavigateToSupport = { navController.navigate("support_hub") },
                        onNavigateToAccount = { nestedNavController.navigate("account") }
                    )
                }
            }
            composable("storefront_food?merchantId={merchantId}") { backStackEntry ->
                val mId = backStackEntry.arguments?.getString("merchantId")
                com.ng.pikop.feature.commerce.FoodStorefrontScreen(
                    merchantId = mId,
                    onViewCart = { nestedNavController.navigate("commerce_cart") },
                    onItemClick = { item: com.ng.pikop.core.network.DiscoveryItem ->
                        nestedNavController.navigate("commerce_checkout?itemId=${android.net.Uri.encode(item.id)}&itemType=${android.net.Uri.encode(item.item_type ?: "meal")}")
                    }
                )
            }
            composable("storefront_groceries") {
                com.ng.pikop.feature.commerce.GroceryStorefrontScreen(
                    onViewCart = { nestedNavController.navigate("commerce_cart") },
                    onItemClick = { item: com.ng.pikop.core.network.DiscoveryItem ->
                        nestedNavController.navigate("commerce_checkout?itemId=${android.net.Uri.encode(item.id)}&itemType=${android.net.Uri.encode(item.item_type ?: "groceries")}")
                    }
                )
            }
            composable("storefront_shop?merchantId={merchantId}") { backStackEntry ->
                val mId = backStackEntry.arguments?.getString("merchantId")
                com.ng.pikop.feature.commerce.ShopStorefrontScreen(
                    merchantId = mId,
                    onViewCart = { nestedNavController.navigate("commerce_cart") },
                    onItemClick = { item: com.ng.pikop.core.network.DiscoveryItem ->
                        nestedNavController.navigate("commerce_checkout?itemId=${android.net.Uri.encode(item.id)}&itemType=${android.net.Uri.encode(item.item_type ?: "product")}")
                    }
                )
            }
            composable("commerce_cart") {
                com.ng.pikop.feature.commerce.CartScreen(
                    onCheckout = {
                        nestedNavController.navigate("commerce_checkout?useCart=true")
                    },
                    onBack = { nestedNavController.popBackStack() }
                )
            }
            composable(
                route = "commerce_checkout?itemId={itemId}&itemType={itemType}&useCart={useCart}",
                arguments = listOf(
                    navArgument("itemId") { type = NavType.StringType; defaultValue = "" },
                    navArgument("itemType") { type = NavType.StringType; defaultValue = "product" },
                    navArgument("useCart") { type = NavType.BoolType; defaultValue = false }
                )
            ) { backStackEntry ->
                val itemId = backStackEntry.arguments?.getString("itemId") ?: ""
                val itemType = backStackEntry.arguments?.getString("itemType") ?: "product"
                val useCart = backStackEntry.arguments?.getBoolean("useCart") ?: false
                
                CommerceCheckoutScreen(
                    itemId = itemId,
                    itemType = itemType,
                    navController = navController, // Keep root for map_address_search/track_order
                    useCart = useCart,
                    onSuccess = { 
                        CartManager.clear()
                        navController.navigate("main") { popUpTo(0) { inclusive = true } } 
                    },
                    onCelebration = onCelebration,
                    onBack = { nestedNavController.popBackStack() }
                )
            }
            composable("history") {
                if (userRole == "FULFILLER") {
                    FulfillerOrdersScreen(
                        onBack = { nestedNavController.popBackStack() },
                        onNavigateToActiveOrder = { id -> navController.navigate("active_order/$id") }
                    )
                } else {
                    OrdersDashboardScreen(
                        userEmail = userEmail ?: "",
                        onNewDelivery = { navController.navigate("order_quote") },
                        onTrackOrder = { id -> navController.navigate("track_order/$id") },
                        onManageAddresses = { nestedNavController.navigate("account") },
                        onGoToWallet = { nestedNavController.navigate("wallet") },
                        onGoToAbout = { nestedNavController.navigate("account") },
                        onLogout = {}
                    )
                }
            }
            composable("wallet") {
                WalletScreen(
                    onBack = { nestedNavController.popBackStack() }, 
                    isFulfiller = userRole == "FULFILLER",
                    onNavigateToWithdrawal = { navController.navigate("withdrawal") }
                )
            }
            composable("withdrawal") {
                WithdrawalScreen(
                    onSuccess = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }
            composable("account") {
                AccountScreen(
                    userEmail = userEmail,
                    userName = userName,
                    userRole = userRole,
                    referralCode = referralCode,
                    kycStatus = kycStatus,
                    onNavigateToSupport = { navController.navigate("support_hub") },
                    onNavigateToAddresses = { 
                        // Implementation for addresses flow
                    },
                    onNavigateToProfile = { navController.navigate("profile_edit") },
                    onNavigateToNotifications = { navController.navigate("notifications_settings") },
                    onNavigateToRecipients = { navController.navigate("recipients_mgmt") },
                    onNavigateToSessions = { navController.navigate("session_mgmt") },
                    onNavigateToCorporate = { navController.navigate("corporate_dashboard") },
                    onNavigateToGrowth = { navController.navigate("growth_rewards") },
                    onNavigateToMerchant = { 
                        if (userRole == "MERCHANT") {
                            navController.navigate("main") 
                        } else {
                            navController.navigate("merchant_portal") 
                        }
                    },
                    onNavigateToMerchantRegistration = { navController.navigate("merchant_business_setup") },
                    onNavigateToTerms = { navController.navigate("terms_viewer/false") },
                    onNavigateToPrivacy = { navController.navigate("privacy_policy") },
                    onNavigateToKyc = { navController.navigate("kyc_upload") },
                    onLogout = {
                        scope.launch {
                            tokenManager.clearTokens()
                            navController.navigate("user_type_selection") {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    }
                )
            }
        }
    }
}
