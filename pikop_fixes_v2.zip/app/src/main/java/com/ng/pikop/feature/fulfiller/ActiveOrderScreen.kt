package com.ng.pikop.feature.fulfiller

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.Help
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.JointType
import com.google.android.gms.maps.model.RoundCap
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.maps.android.compose.*
import com.ng.pikop.core.datastore.TokenManager
import com.ng.pikop.core.network.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import com.ng.pikop.core.ui.SignaturePad
import android.graphics.Bitmap
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import kotlin.math.max

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ActiveOrderScreen(
    orderId: String, 
    onOrderCompleted: () -> Unit, 
    onBack: () -> Unit,
    onNavigateToChat: (String) -> Unit
) {
    var orderDetails by remember { mutableStateOf<OrderDetailsResponse?>(null) }
    var orderStatus by remember { mutableStateOf("MATCHED") }
    var fulfillerLocation by remember { mutableStateOf<LatLng?>(null) }
    var isFetchingDetails by remember { mutableStateOf(true) }
    
    var queueCandidates by remember { mutableStateOf<List<OfferResponse>>(emptyList()) }
    var realRoadActiveRoute by remember { mutableStateOf<List<LatLng>>(emptyList()) }
    
    var pickupCode by remember { mutableStateOf("") }
    var deliveryCode by remember { mutableStateOf("") }
    
    var isLoading by remember { mutableStateOf(false) }
    var showRatingDialog by remember { mutableStateOf(false) }
    var showIncidentDialog by remember { mutableStateOf(false) }
    
    var sosActive by remember { mutableStateOf(false) }
    var sosHoldProgress by remember { mutableFloatStateOf(0f) }
    var sosTriggered by remember { mutableStateOf(false) }
    
    // Timer for "Mark Failed" (10-minute wait)
    var secondsAtDestination by remember { mutableStateOf(0) }
    var isArrived by remember { mutableStateOf(false) }
    var isActionLoading by remember { mutableStateOf(false) }

    LaunchedEffect(isArrived) {
        if (isArrived) {
            while (true) {
                delay(1000)
                secondsAtDestination++
            }
        }
    }

    val context = LocalContext.current
    val tokenManager = remember { TokenManager(context) }
    val coroutineScope = rememberCoroutineScope()
    val apiService = remember { ApiService.create(tokenManager) }
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    
    val userId by tokenManager.userId.collectAsState(initial = null)
    val defaultLagos = remember { LatLng(6.5244, 3.3792) }
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(defaultLagos, 12f)
    }

    // Secure Photo Storage for POD with process death persistence
    val podFile = remember { File(context.cacheDir, "pod_${orderId}.jpg") }
    val podUri by remember {
        derivedStateOf {
            try {
                FileProvider.getUriForFile(context, "${context.packageName}.provider", podFile)
            } catch (e: Exception) {
                null
            }
        }
    }

    var deliveryPhotoUriString by androidx.compose.runtime.saveable.rememberSaveable {
        mutableStateOf(if (podFile.exists()) podUri?.toString() else null)
    }
    val deliveryPhotoUri = remember(deliveryPhotoUriString) {
        deliveryPhotoUriString?.let { Uri.parse(it) }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) deliveryPhotoUriString = podUri?.toString()
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            podUri?.let { cameraLauncher.launch(it) }
                ?: Toast.makeText(context, "Storage error: Cannot launch camera", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Camera permission is required for Proof of Delivery", Toast.LENGTH_LONG).show()
        }
    }

    // Fetch Order Details on Init
    LaunchedEffect(orderId) {
        isFetchingDetails = true
        try {
            val response = apiService.getOrderDetails(orderId)
            orderDetails = response
            orderStatus = (response.status ?: "MATCHED").uppercase()
            
            if (orderStatus == "PICKED_UP") {
                queueCandidates = apiService.getQueueCandidates()
            }
        } catch (e: Exception) {
            Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_SHORT).show()
        } finally {
            isFetchingDetails = false
        }
    }

    // Socket Connection & Location Tracking
    DisposableEffect(userId) {
        SocketManager.connect(userId)
        onDispose {
            // v4.5 fix (#6): don't tear down the shared app-wide socket on leaving
            // this screen -- MainActivity owns its lifecycle, and other screens
            // (dashboard, tracking, chat) depend on it staying connected. See the
            // matching fix in TrackOrderScreen.kt for the full rationale.
        }
    }

    LaunchedEffect(orderStatus) {
        val normStatus = orderStatus.uppercase()
        val trackableStatuses = listOf("MATCHED", "SEARCHING", "ASSIGNED", "ACCEPTED", "ARRIVED_AT_PICKUP", "PICKED_UP", "IN_TRANSIT", "ARRIVED_AT_DELIVERY", "PAYMENT_CAPTURED")
        
        if (normStatus in trackableStatuses) {
            while (true) {
                try {
                    fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                        .addOnSuccessListener { location ->
                            if (location != null) {
                                val currentLatLng = LatLng(location.latitude, location.longitude)
                                fulfillerLocation = currentLatLng
                                
                                val data = JSONObject().apply {
                                    put("orderId", orderId)
                                    put("lat", location.latitude)
                                    put("lng", location.longitude)
                                }
                                SocketManager.emit("update_mission_location", data)
                                android.util.Log.d("ActiveOrder", "Location PING sent for Mission #$orderId")
                            }
                        }
                } catch (e: SecurityException) {
                    android.util.Log.e("ActiveOrder", "Location permission missing", e)
                } catch (e: Exception) {
                    android.util.Log.e("ActiveOrder", "Location stream error", e)
                }
                delay(if (sosTriggered) 5000 else 10000)
                
                // Break loop if status changes to non-trackable (Double Check)
                if (orderStatus.uppercase() !in trackableStatuses) break
            }
        }
    }

    // Auto-zoom map safely without 0,0 ocean bounds
    LaunchedEffect(fulfillerLocation, orderStatus, orderDetails) {
        val fLoc = fulfillerLocation
        val details = orderDetails

        if (details != null) {
            val normStatus = orderStatus.uppercase()
            val targetLat = if (normStatus in listOf("MATCHED", "SEARCHING", "ASSIGNED", "ACCEPTED", "ARRIVED_AT_PICKUP")) details.pickup_lat ?: 0.0 else details.delivery_lat ?: 0.0
            val targetLng = if (normStatus in listOf("MATCHED", "SEARCHING", "ASSIGNED", "ACCEPTED", "ARRIVED_AT_PICKUP")) details.pickup_lng ?: 0.0 else details.delivery_lng ?: 0.0
            
            val validTarget = if (targetLat != 0.0 && targetLng != 0.0) LatLng(targetLat, targetLng) else null
            val validFulfiller = if (fLoc != null && fLoc.latitude != 0.0) fLoc else null

            try {
                if (validTarget != null && validFulfiller != null) {
                    val bounds = LatLngBounds.builder()
                        .include(validFulfiller)
                        .include(validTarget)
                        .build()
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngBounds(bounds, 180))
                } else if (validTarget != null) {
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(validTarget, 15f))
                } else if (validFulfiller != null) {
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(validFulfiller, 15f))
                } else {
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(defaultLagos, 12f))
                }
            } catch (e: Exception) {
                cameraPositionState.position = CameraPosition.fromLatLngZoom(validTarget ?: validFulfiller ?: defaultLagos, 14f)
            }
        } else if (fLoc != null && fLoc.latitude != 0.0) {
            cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(fLoc, 15f))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Mission Tracking", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground
                )
            )
        },
        floatingActionButton = {
            if (!sosTriggered) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(72.dp)
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onPress = {
                                    sosActive = true
                                    val startTime = System.currentTimeMillis()
                                    while (sosActive && sosHoldProgress < 1f) {
                                        val elapsed = System.currentTimeMillis() - startTime
                                        sosHoldProgress = (elapsed.toFloat() / 3000f).coerceAtMost(1f)
                                        if (sosHoldProgress >= 1f) {
                                            // TRIGGER SOS
                                            coroutineScope.launch {
                                                try {
                                                    val location = try {
                                                        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                                                    } catch (_: Exception) { null }
                                                    
                                                    apiService.triggerSOS(SOSRequest(
                                                        orderId = orderId,
                                                        lat = location?.latitude ?: 0.0,
                                                        lng = location?.longitude ?: 0.0
                                                    ))
                                                    sosTriggered = true
                                                    Toast.makeText(context, "SOS SIGNAL SENT!", Toast.LENGTH_LONG).show()
                                                } catch (e: Exception) {
                                                    Toast.makeText(context, "SOS Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                        delay(50)
                                    }
                                    sosActive = false
                                    if (!sosTriggered) sosHoldProgress = 0f
                                }
                            )
                        }
                ) {
                    CircularProgressIndicator(
                        progress = { sosHoldProgress },
                        modifier = Modifier.fillMaxSize(),
                        color = Color.Red,
                        strokeWidth = 6.dp,
                        trackColor = Color.LightGray.copy(alpha = 0.3f)
                    )
                    FloatingActionButton(
                        onClick = { 
                            if (sosHoldProgress < 1f) {
                                Toast.makeText(context, "Hold for 3 seconds to trigger SOS", Toast.LENGTH_SHORT).show()
                            }
                        },
                        containerColor = if (sosHoldProgress > 0) Color.Red else Color.DarkGray,
                        contentColor = Color.White,
                        modifier = Modifier.size(56.dp),
                        shape = CircleShape
                    ) {
                        Text("SOS", fontWeight = FontWeight.ExtraBold)
                    }
                }
            } else {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.Red),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("EMERGENCY ACTIVE", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { padding ->
        Surface(
            modifier = Modifier.padding(padding).fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Map Section (Top 40%)
                Box(modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.4f)) {
                    GoogleMap(
                        modifier = Modifier.fillMaxSize(),
                        cameraPositionState = cameraPositionState,
                        uiSettings = MapUiSettings(zoomControlsEnabled = false)
                    ) {
                        fulfillerLocation?.let {
                            Marker(
                                state = MarkerState(position = it),
                                title = "Your Location",
                                icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)
                            )
                        }
                        
                        if (orderDetails != null) {
                            val normStatus = orderStatus.uppercase()
                            val targetLatLng = if (normStatus in listOf("MATCHED", "SEARCHING", "ASSIGNED", "ACCEPTED", "ARRIVED_AT_PICKUP", "PAYMENT_CAPTURED", "PAYMENT_PENDING")) {
                                LatLng(orderDetails?.pickup_lat ?: 0.0, orderDetails?.pickup_lng ?: 0.0)
                            } else {
                                LatLng(orderDetails?.delivery_lat ?: 0.0, orderDetails?.delivery_lng ?: 0.0)
                            }
                            
                            Marker(
                                state = MarkerState(position = targetLatLng),
                                title = if (normStatus in listOf("MATCHED", "SEARCHING", "ASSIGNED", "ACCEPTED", "ARRIVED_AT_PICKUP")) "Pickup" else "Delivery",
                                icon = BitmapDescriptorFactory.defaultMarker(
                                    if (normStatus in listOf("MATCHED", "SEARCHING", "ASSIGNED", "ACCEPTED", "ARRIVED_AT_PICKUP")) BitmapDescriptorFactory.HUE_GREEN else BitmapDescriptorFactory.HUE_RED
                                )
                            )
                            
                            LaunchedEffect(fulfillerLocation, targetLatLng) {
                                val ful = fulfillerLocation
                                if (ful != null && (targetLatLng.latitude != 0.0 || targetLatLng.longitude != 0.0)) {
                                    realRoadActiveRoute = RoadRouteService.fetchRoadRoute(ful, targetLatLng, com.ng.pikop.BuildConfig.GOOGLE_MAPS_API_KEY)
                                }
                            }

                            val brandGreen = Color(0xFF00E676)
                            if (realRoadActiveRoute.isNotEmpty()) {
                                Polyline(
                                    points = realRoadActiveRoute,
                                    color = brandGreen,
                                    width = 14f,
                                    jointType = JointType.ROUND,
                                    startCap = RoundCap(),
                                    endCap = RoundCap()
                                )
                            } else fulfillerLocation?.let { 
                                Polyline(
                                    points = listOf(it, targetLatLng),
                                    color = brandGreen,
                                    width = 14f,
                                    jointType = JointType.ROUND,
                                    startCap = RoundCap(),
                                    endCap = RoundCap()
                                )
                            }
                        }
                    }
                    
                    IconButton(
                        onClick = { showIncidentDialog = true },
                        modifier = Modifier.align(Alignment.TopEnd).padding(16.dp).padding(top = 64.dp),
                        colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Icon(Icons.Default.ReportProblem, contentDescription = "Report Incident", tint = MaterialTheme.colorScheme.error)
                    }

                    // Chat Button
                    IconButton(
                        onClick = { onNavigateToChat(orderId) },
                        modifier = Modifier.align(Alignment.TopEnd).padding(16.dp),
                        colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = "Chat", tint = MaterialTheme.colorScheme.primary)
                    }
                }

                // Details Section (Bottom 60%)
                Column(modifier = Modifier.padding(16.dp).weight(0.6f).verticalScroll(rememberScrollState())) {
                    val isCod = (orderDetails?.item_price ?: 0.0) > 0
                    if (isCod) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = com.ng.pikop.ui.theme.PikopGreen),
                            modifier = Modifier.padding(bottom = 12.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Payments, null, modifier = Modifier.size(16.dp), tint = com.ng.pikop.ui.theme.PikopGold)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Delivery + COD (Escrow Protected)", style = MaterialTheme.typography.labelSmall, color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    
                    Text(text = "Active Mission", style = MaterialTheme.typography.headlineMedium)
                    Text(
                        text = "Order ID: #$orderId", 
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.clickable {
                            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Order ID", orderId))
                            Toast.makeText(context, "Order ID copied", Toast.LENGTH_SHORT).show()
                        }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    if (isFetchingDetails) {
                        Spacer(modifier = Modifier.height(32.dp))
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Loading mission details...", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                    } else {
                        val normalizedStatus = orderStatus.uppercase()
                        
                        val isPickupPhase = normalizedStatus in listOf("MATCHED", "SEARCHING", "ASSIGNED", "ACCEPTED", "ARRIVED_AT_PICKUP", "PENDING", "PAID", "PAYMENT_CAPTURED", "PAYMENT_PENDING")
                        val isDeliveryPhase = normalizedStatus in listOf("PICKED_UP", "IN_TRANSIT", "ARRIVED_AT_DELIVERY")
                        val isAwaitingRelease = normalizedStatus == "DELIVERED_PENDING_CONFIRMATION"
                        val isQueued = normalizedStatus == "QUEUED"

                        if (isPickupPhase) {
                            PhaseCard(
                                title = "Phase 1: Pickup",
                                address = orderDetails?.pickup_address ?: "Address unavailable",
                                recipientName = orderDetails?.recipient_name,
                                recipientPhone = orderDetails?.recipient_phone,
                                buttonText = "Navigate to Pickup",
                                onNavigate = { 
                                    navigateToLocation(
                                        context, 
                                        orderDetails?.pickup_address ?: "",
                                        orderDetails?.pickup_lat,
                                        orderDetails?.pickup_lng
                                    ) 
                                },
                                onCallRecipient = {
                                    orderDetails?.recipient_phone?.let { phone -> callPhone(context, phone) }
                                }
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            if (normalizedStatus != "ARRIVED_AT_PICKUP") {
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isLoading = true
                                            try {
                                                apiService.updateOrderStatus(orderId, mapOf("status" to "ARRIVED_AT_PICKUP"))
                                                orderStatus = "ARRIVED_AT_PICKUP"
                                                Toast.makeText(context, "Arrival confirmed. Enter the pickup code below.", Toast.LENGTH_SHORT).show()
                                            } catch (e: Exception) {
                                                Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_SHORT).show()
                                            } finally { isLoading = false }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isLoading
                                ) {
                                    if (isLoading) CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    else Text("Confirm Arrival at Pickup")
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                            }

                            OutlinedTextField(
                                value = pickupCode,
                                onValueChange = { pickupCode = it },
                                label = { Text("Enter 4-digit Pickup Code") },
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        isLoading = true
                                        try {
                                            apiService.verifyPickup(orderId, VerifyCodeRequest(pickupCode))
                                            orderStatus = "PICKED_UP"
                                            Toast.makeText(context, "Pickup Verified!", Toast.LENGTH_SHORT).show()
                                            queueCandidates = apiService.getQueueCandidates()
                                        } catch (e: Exception) {
                                            Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_SHORT).show()
                                        } finally {
                                            isLoading = false
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !isLoading && pickupCode.length == 4
                            ) {
                                if (isLoading) CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                                else Text("Verify Pickup")
                            }
                        } else if (isDeliveryPhase) {
                            PhaseCard(
                                title = "Phase 2: Delivery",
                                address = orderDetails?.delivery_address ?: "Address unavailable",
                                recipientName = orderDetails?.recipient_name,
                                recipientPhone = orderDetails?.recipient_phone,
                                buttonText = "Navigate to Delivery",
                                onNavigate = { 
                                    navigateToLocation(
                                        context, 
                                        orderDetails?.delivery_address ?: "",
                                        orderDetails?.delivery_lat,
                                        orderDetails?.delivery_lng
                                    ) 
                                },
                                onCallRecipient = {
                                    orderDetails?.recipient_phone?.let { phone -> callPhone(context, phone) }
                                }
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            if (normalizedStatus != "ARRIVED_AT_DELIVERY") {
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isLoading = true
                                            try {
                                                apiService.updateOrderStatus(orderId, mapOf("status" to "ARRIVED_AT_DELIVERY"))
                                            orderStatus = "ARRIVED_AT_DELIVERY"
                                            isArrived = true
                                            Toast.makeText(context, "Delivery Protocol Initiated. Please wait for recipient.", Toast.LENGTH_SHORT).show()
                                            } catch (e: Exception) {
                                                Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_SHORT).show()
                                            } finally { isLoading = false }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isLoading
                                ) {
                                    if (isLoading) CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    else Text("Confirm Arrival at Destination")
                                }
                            }

                            if (normalizedStatus == "ARRIVED_AT_DELIVERY") {
                            // Logistics Edge Case Tools (v3.9.1)
                            val remainingWait = max(0, 600 - secondsAtDestination)
                            val isWaitComplete = remainingWait == 0
                            
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isActionLoading = true
                                            try {
                                                apiService.requestConsent(orderId, mapOf("note" to "Arrived at destination"))
                                                Toast.makeText(context, "Consent link sent to recipient.", Toast.LENGTH_SHORT).show()
                                            } catch (e: Exception) {
                                                Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_LONG).show()
                                            } finally { isActionLoading = false }
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    enabled = !isActionLoading && !isLoading,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    if (isActionLoading) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = MaterialTheme.colorScheme.onSecondary)
                                    else Text("Request Consent", fontSize = 12.sp)
                                }

                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isLoading = true
                                            try {
                                                // Fail flow requires photo as evidence
                                                if (deliveryPhotoUri != null) {
                                                    val compressedFile = ImageUtils.compressFile(context, podFile)
                                                    val requestFile = compressedFile.asRequestBody("image/*".toMediaTypeOrNull())
                                                    val body = MultipartBody.Part.createFormData("file", compressedFile.name, requestFile)
                                                    val uploadRes = apiService.uploadOrderPhoto(body)
                                                    val photoUrl = uploadRes["url"] ?: ""
                                                    
                                                    apiService.failDelivery(orderId, mapOf("reason" to "Recipient Absent", "evidence_photo_url" to photoUrl))
                                                    orderStatus = "RECIPIENT_ABSENT"
                                                    Toast.makeText(context, "Mission Failed - Recipient Absent", Toast.LENGTH_LONG).show()
                                                } else {
                                                    Toast.makeText(context, "Please capture a photo of the location as evidence.", Toast.LENGTH_LONG).show()
                                                }
                                            } catch (e: Exception) {
                                                Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_LONG).show()
                                            } finally { isLoading = false }
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    enabled = isWaitComplete && !isLoading,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                                ) {
                                    if (isLoading) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                                    else if (isWaitComplete) Text("Mark Failed", fontSize = 12.sp)
                                    else Text("Wait ${remainingWait}s", fontSize = 12.sp)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Card(
                                    onClick = { 
                                        val hasCameraPerm = androidx.core.content.ContextCompat.checkSelfPermission(
                                            context, 
                                            android.Manifest.permission.CAMERA
                                        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                                        
                                        if (hasCameraPerm) {
                                            podUri?.let { cameraLauncher.launch(it) }
                                                ?: Toast.makeText(context, "Storage error: Cannot launch camera", Toast.LENGTH_SHORT).show()
                                        } else {
                                            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = if (deliveryPhotoUri != null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.AddAPhoto, contentDescription = null)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(if (deliveryPhotoUri != null) "Photo Captured ✅" else "Capture Proof of Delivery")
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Text("Recipient Signature", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.Start))
                                SignaturePad(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp)
                                        .height(150.dp)
                                        .background(Color.White, shape = MaterialTheme.shapes.small),
                                    onSignatureCaptured = { /* We will capture on complete */ }
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                OutlinedTextField(
                                    value = deliveryCode,
                                    onValueChange = { deliveryCode = it },
                                    label = { Text("Enter 4-digit Delivery Code") },
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = {
                                        coroutineScope.launch {
                                            isLoading = true
                                            try {
                                                val location = try {
                                                    fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
                                                } catch (e: SecurityException) { null }
                                                
                                                if (podFile.exists()) {
                                                    val compressedFile = ImageUtils.compressFile(context, podFile)
                                                    val requestFile = compressedFile.asRequestBody("image/*".toMediaTypeOrNull())
                                                    val body = MultipartBody.Part.createFormData("file", compressedFile.name, requestFile)
                                                    val uploadRes = apiService.uploadOrderPhoto(body)
                                                    val photoUrl = uploadRes["url"] ?: ""

                                                    try {
                                                        apiService.verifyDelivery(
                                                            orderId, 
                                                            VerifyCodeRequest(
                                                                code = deliveryCode, 
                                                                delivery_photo_url = photoUrl,
                                                                lat = location?.latitude,
                                                                lng = location?.longitude,
                                                                device_timestamp = System.currentTimeMillis()
                                                            )
                                                        )
                                                    } catch (e: Throwable) {
                                                        // Robust Fallback: Check if backend already marked as delivered (avoids 500/timeout confusion)
                                                        val checkRes = apiService.getOrderDetails(orderId)
                                                        if (checkRes.status?.uppercase() != "DELIVERED") {
                                                            throw e
                                                        }
                                                    }
                                                    
                                                    orderStatus = "DELIVERED"
                                                    showRatingDialog = true
                                                } else {
                                                    Toast.makeText(context, "Please capture a proof photo first.", Toast.LENGTH_SHORT).show()
                                                }
                                            } catch (e: Throwable) {
                                                android.util.Log.e("ActiveOrder", "Complete Mission Failed", e)
                                                val errorMessage = com.ng.pikop.core.network.ErrorUtils.parseError(e as? Exception ?: Exception(e.message))
                                                Toast.makeText(context, "Process Failure: $errorMessage", Toast.LENGTH_LONG).show()
                                            } finally {
                                                isLoading = false
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isLoading && deliveryCode.length == 4 && deliveryPhotoUri != null
                                ) {
                                    if (isLoading) CircularProgressIndicator(modifier = Modifier.size(24.dp), color = MaterialTheme.colorScheme.onPrimary)
                                    else Text("Complete Mission")
                                }
                            }
                        } else if (isAwaitingRelease) {
                            val earningAmount = ((orderDetails?.delivery_fee ?: 0.0) * 0.75).toInt()
                            val isSeller = userId == orderDetails?.seller_id?.toString()
                            
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(48.dp), tint = com.ng.pikop.ui.theme.PikopGreen)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text("Mission Successfully Completed!", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                    
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text(
                                        text = "₦$earningAmount has been credited to your available balance for this delivery.",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = com.ng.pikop.ui.theme.PikopGreen,
                                        textAlign = TextAlign.Center
                                    )

                                    if (isSeller) {
                                        val fee = if (orderDetails?.fee_payer == "SELLER") orderDetails?.platform_fee_amount ?: 0.0 else 0.0
                                        val netPayout = (orderDetails?.item_price ?: 0.0) - fee
                                        
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Text(
                                            "The item payment (₦${netPayout}) is pending customer confirmation. It will be released to your wallet shortly.",
                                            textAlign = TextAlign.Center,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        if (fee > 0.0) {
                                            Text(
                                                "(₦$fee platform fee deducted from total ₦${orderDetails?.item_price})",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color.Gray,
                                                textAlign = TextAlign.Center
                                            )
                                        }
                                    } else if ((orderDetails?.item_price ?: 0.0) > 0) {
                                        Spacer(modifier = Modifier.height(16.dp))
                                        Text(
                                            "The item payment will be released to the seller once the customer confirms receipt.",
                                            textAlign = TextAlign.Center,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.Gray
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(24.dp))
                                    Button(onClick = onOrderCompleted, modifier = Modifier.fillMaxWidth()) {
                                        Text("Back to Dashboard")
                                    }
                                }
                            }
                        } else if (isQueued) {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                            ) {
                                Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.secondary)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("Mission Queued", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("You have another active mission in progress. This mission will begin as soon as your current mission is completed.", textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showIncidentDialog) {
        IncidentReportDialog(
            onDismiss = { showIncidentDialog = false },
            onReport = { category, resolution, notes, severity ->
                coroutineScope.launch {
                    try {
                        apiService.fileIncident(orderId, IncidentRequest(category, notes, resolution, severity))
                        Toast.makeText(context, "Incident reported. Check status.", Toast.LENGTH_LONG).show()
                        onOrderCompleted()
                    } catch (e: Exception) {
                        Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_LONG).show()
                    }
                    showIncidentDialog = false
                }
            }
        )
    }

    if (showRatingDialog) {
        RatingDialog(
            onDismiss = { 
                showRatingDialog = false
                onOrderCompleted()
            },
            onSubmit = { rating ->
                coroutineScope.launch {
                    try {
                        apiService.rateCustomer(orderId, com.ng.pikop.core.network.RatingRequest(rating))
                        Toast.makeText(context, "Rating submitted!", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        val errorMsg = com.ng.pikop.core.network.ErrorUtils.parseError(e)
                        Toast.makeText(context, "Rating failed: $errorMsg", Toast.LENGTH_SHORT).show()
                    }
                    showRatingDialog = false
                    onOrderCompleted()
                }
            }
        )
    }
}

@Composable
fun IncidentReportDialog(onDismiss: () -> Unit, onReport: (String, String, String, String) -> Unit) {
    var category by remember { mutableStateOf("breakdown") }
    var resolution by remember { mutableStateOf("handoff") }
    var severity by remember { mutableStateOf("MEDIUM") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Report Incident", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Column {
                    Text("Severity", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = severity == "LOW", onClick = { severity = "LOW" }, label = { Text("Low") })
                        FilterChip(selected = severity == "MEDIUM", onClick = { severity = "MEDIUM" }, label = { Text("Medium") })
                        FilterChip(selected = severity == "HIGH", onClick = { severity = "HIGH" }, label = { Text("High") })
                    }
                }

                Column {
                    Text("What happened?", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = category == "breakdown", onClick = { category = "breakdown" }, label = { Text("Breakdown") })
                        FilterChip(selected = category == "security_risk", onClick = { category = "security_risk" }, label = { Text("Security") })
                        FilterChip(selected = category == "accident", onClick = { category = "accident" }, label = { Text("Accident") })
                    }
                }
                
                Column {
                    Text("Requested Resolution", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = resolution == "handoff", onClick = { resolution = "handoff" }, label = { Text("Handoff") })
                        FilterChip(selected = resolution == "cancel_with_waiver_request", onClick = { resolution = "cancel_with_waiver_request" }, label = { Text("Abort") })
                    }
                }

                OutlinedTextField(
                    value = notes, 
                    onValueChange = { notes = it }, 
                    label = { Text("Notes / Details") }, 
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onReport(category, resolution, notes, severity) }, 
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("File Report")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun PhaseCard(
    title: String,
    address: String,
    recipientName: String? = null,
    recipientPhone: String? = null,
    buttonText: String,
    onNavigate: () -> Unit,
    onCallRecipient: (() -> Unit)? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title, 
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = address, 
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface
            )
            
            if (!recipientName.isNullOrBlank() || !recipientPhone.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        if (!recipientName.isNullOrBlank()) {
                            Text(
                                text = "Recipient: $recipientName", 
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        if (!recipientPhone.isNullOrBlank()) {
                            Text(
                                text = recipientPhone, 
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.Gray
                            )
                        }
                    }
                    if (onCallRecipient != null && !recipientPhone.isNullOrBlank()) {
                        IconButton(
                            onClick = onCallRecipient,
                            colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Phone,
                                contentDescription = "Call Recipient",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            
            Button(
                onClick = onNavigate, 
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                )
            ) {
                Text(buttonText, fontWeight = FontWeight.Bold)
            }
        }
    }
}

fun callPhone(context: Context, phoneNumber: String) {
    try {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${phoneNumber.trim()}"))
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Cannot launch phone dialer", Toast.LENGTH_SHORT).show()
    }
}

fun navigateToLocation(context: Context, address: String, lat: Double? = null, lng: Double? = null) {
    val uri = if (lat != null && lng != null && lat != 0.0) {
        Uri.parse("google.navigation:q=$lat,$lng")
    } else {
        Uri.parse("geo:0,0?q=${Uri.encode(address)}")
    }
    val mapIntent = Intent(Intent.ACTION_VIEW, uri)
    mapIntent.setPackage("com.google.android.apps.maps")
    if (mapIntent.resolveActivity(context.packageManager) != null) {
        context.startActivity(mapIntent)
    } else {
        val fallbackUri = Uri.parse("geo:0,0?q=${Uri.encode(address)}")
        context.startActivity(Intent(Intent.ACTION_VIEW, fallbackUri))
    }
}
