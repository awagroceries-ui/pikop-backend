package com.ng.pikop.feature.wallet

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.CallMade
import androidx.compose.material.icons.automirrored.filled.CallReceived
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.ng.pikop.R
import com.ng.pikop.core.datastore.TokenManager
import com.ng.pikop.core.network.ApiService
import com.ng.pikop.core.network.ErrorUtils
import com.ng.pikop.core.network.WalletTransaction
import com.ng.pikop.core.network.WithdrawalRequest
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletScreen(
    onBack: () -> Unit, 
    isFulfiller: Boolean = false,
    onNavigateToWithdrawal: () -> Unit = {}
) {
    var balance by remember { mutableStateOf(0.0) }
    var pendingBalance by remember { mutableStateOf(0.0) }
    var transactions by remember { mutableStateOf<List<WalletTransaction>>(emptyList()) }
    var isLoading by remember { mutableStateOf(false) }
    var showTopupDialog by remember { mutableStateOf(false) }
    var showWithdrawDialog by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val tokenManager = remember { TokenManager(context) }
    val scope = rememberCoroutineScope()
    val apiService = remember { ApiService.create(tokenManager) }

    val fetchWallet = {
        scope.launch {
            isLoading = true
            try {
                val response = apiService.getWalletInfo()
                balance = response.actualBalance
                pendingBalance = response.actualPendingBalance
                transactions = response.actualTransactions
            } catch (e: Exception) {
                android.util.Log.e("WalletScreen", "Fetch wallet error: ${e.message}", e)
            }
            isLoading = false
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                fetchWallet()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(Unit) {
        fetchWallet()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My Wallet") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            if (isLoading && transactions.isEmpty()) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                    ) {
                        Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(painter = painterResource(id = R.drawable.pikop_logo), contentDescription = null, modifier = Modifier.size(80.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Current Balance", style = MaterialTheme.typography.labelMedium)
                            Text("₦${"%,.2f".format(balance)}", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            
                            if (pendingBalance > 0) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.2f))
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Pending (Secure Pay)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f))
                                        Text("₦${"%,.2f".format(pendingBalance)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { showTopupDialog = true },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                                ) {
                                    Text("Top up")
                                }
                                Button(
                                    onClick = {
                                        if (isFulfiller) {
                                            onNavigateToWithdrawal()
                                        } else {
                                            showWithdrawDialog = true
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    enabled = balance > 0,
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                                ) {
                                    Text("Withdraw")
                                }
                            }
                        }
                    }
                    Text(text = "Recent Activity", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                    if (transactions.isEmpty()) {
                        Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text("No transactions yet.", color = Color.Gray) }
                    } else {
                        LazyColumn(modifier = Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(transactions) { tx -> TransactionItem(tx) }
                        }
                    }
                }
            }
        }
    }
    if (showTopupDialog) {
        TopupDialog(
            onDismiss = { showTopupDialog = false },
            onConfirm = { amount ->
                scope.launch {
                    try {
                        val response = apiService.initializeTopup(mapOf("amount" to amount))
                        response.authorization_url?.let { url ->
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            context.startActivity(intent)
                        }
                        showTopupDialog = false
                    } catch (_: Exception) {}
                }
            }
        )
    }

    if (showWithdrawDialog) {
        UserWithdrawalDialog(
            maxBalance = balance,
            onDismiss = { showWithdrawDialog = false },
            onConfirm = { amount ->
                scope.launch {
                    try {
                        val res = apiService.requestWithdrawal(
                            WithdrawalRequest(
                                amount = amount,
                                type = "STANDARD"
                            )
                        )
                        Toast.makeText(context, res.message ?: "Withdrawal requested", Toast.LENGTH_LONG).show()
                        showWithdrawDialog = false
                        fetchWallet()
                    } catch (e: Exception) {
                        Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }
}

@Composable
fun TopupDialog(onDismiss: () -> Unit, onConfirm: (Double) -> Unit) {
    var amount by remember { mutableStateOf("1000") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Top up Wallet") },
        text = {
            Column {
                Text("Enter amount to add to your balance via Paystack.", style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = amount,
                    onValueChange = { if (it.all { c -> c.isDigit() }) amount = it },
                    label = { Text("Amount (₦)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(amount.toDoubleOrNull() ?: 0.0) }) { Text("Proceed to Pay") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun UserWithdrawalDialog(
    maxBalance: Double,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var amountText by remember { mutableStateOf("1000") }
    val amountDouble = amountText.toDoubleOrNull() ?: 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Withdraw Wallet Funds") },
        text = {
            Column {
                Text("Available Balance: ₦${"%,.2f".format(maxBalance)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Enter amount to withdraw to your bank account.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { if (it.all { c -> c.isDigit() }) amountText = it },
                    label = { Text("Withdrawal Amount (₦)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(amountDouble) },
                enabled = amountDouble >= 1000.0 && amountDouble <= maxBalance
            ) { Text("Request Withdrawal") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun TransactionItem(tx: WalletTransaction) {
    val isCredit = tx.entry_type == "CREDIT"
    Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = if (isCredit) Icons.AutoMirrored.Filled.CallReceived else Icons.AutoMirrored.Filled.CallMade, contentDescription = null, tint = if (isCredit) Color(0xFF388E3C) else Color(0xFFC62828))
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = (tx.purpose ?: "Transaction").replace("_", " ").lowercase().replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }, style = MaterialTheme.typography.bodyMedium)
                Text(text = (tx.created_at ?: "").take(10), style = MaterialTheme.typography.labelSmall, color = Color.Gray)
            }
            Text(text = "${if (isCredit) "+" else "-"}₦${tx.amount ?: 0.0}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold, color = if (isCredit) Color(0xFF388E3C) else Color(0xFFC62828))
        }
    }
}
