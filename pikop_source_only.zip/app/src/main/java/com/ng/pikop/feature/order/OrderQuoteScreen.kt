package com.ng.pikop.feature.order

import android.app.Activity
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import java.text.SimpleDateFormat
import java.util.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import androidx.navigation.NavHostController
import com.google.android.gms.maps.model.LatLng
import com.ng.pikop.R
import com.ng.pikop.core.datastore.TokenManager
import com.ng.pikop.core.network.*
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderQuoteScreen(
    navController: NavHostController,
    userEmail: String,
    userName: String = "",
    userPhone: String = "",
    onOrderComplete: (String) -> Unit,
    onCelebration: () -> Unit = {},
    onNavigateToPayment: (url: String, quoteId: String, pLat: Double, pLng: Double, dLat: Double, dLng: Double, itemUrl: String, pSum: String, dSum: String, rName: String, rPhone: String, notes: String?, promoId: String?) -> Unit
) {
    var pickupAddress by rememberSaveable { mutableStateOf("") }
    var pickupLat by rememberSaveable { mutableStateOf(0.0) }
    var pickupLng by rememberSaveable { mutableStateOf(0.0) }
    var pickupState by rememberSaveable { mutableStateOf<String?>(null) }
    var pickupLandmark by rememberSaveable { mutableStateOf("") }
    
    var deliveryAddress by rememberSaveable { mutableStateOf("") }
    var deliveryLat by rememberSaveable { mutableStateOf(0.0) }
    var deliveryLng by rememberSaveable { mutableStateOf(0.0) }
    var deliveryLandmark by rememberSaveable { mutableStateOf("") }

    val pickupLatLng = if (pickupLat != 0.0) LatLng(pickupLat, pickupLng) else null
    val deliveryLatLng = if (deliveryLat != 0.0) LatLng(deliveryLat, deliveryLng) else null
    
    // Use IDs to track which result we've already consumed
    var lastPickupResultId by rememberSaveable { mutableStateOf("") }
    var lastDeliveryResultId by rememberSaveable { mutableStateOf("") }

    val pAddrRes by navController.currentBackStackEntry?.savedStateHandle?.getStateFlow<String?>("pickup_address", null)?.collectAsState() ?: remember { mutableStateOf(null) }
    val pLatRes by navController.currentBackStackEntry?.savedStateHandle?.getStateFlow<Double?>("pickup_lat", null)?.collectAsState() ?: remember { mutableStateOf(null) }
    val pLngRes by navController.currentBackStackEntry?.savedStateHandle?.getStateFlow<Double?>("pickup_lng", null)?.collectAsState() ?: remember { mutableStateOf(null) }
    val pStateRes by navController.currentBackStackEntry?.savedStateHandle?.getStateFlow<String?>("pickup_state", null)?.collectAsState() ?: remember { mutableStateOf(null) }

    val dAddrRes by navController.currentBackStackEntry?.savedStateHandle?.getStateFlow<String?>("delivery_address", null)?.collectAsState() ?: remember { mutableStateOf(null) }
    val dLatRes by navController.currentBackStackEntry?.savedStateHandle?.getStateFlow<Double?>("delivery_lat", null)?.collectAsState() ?: remember { mutableStateOf(null) }
    val dLngRes by navController.currentBackStackEntry?.savedStateHandle?.getStateFlow<Double?>("delivery_lng", null)?.collectAsState() ?: remember { mutableStateOf(null) }

    LaunchedEffect(pAddrRes, pLatRes, pLngRes, pStateRes) {
        if (pAddrRes != null && pLatRes != null && pLngRes != null) {
            val resultId = "${pAddrRes}_${pLatRes}_${pLngRes}"
            if (resultId != lastPickupResultId) {
                pickupAddress = pAddrRes!!
                pickupLat = pLatRes!!
                pickupLng = pLngRes!!
                pickupState = pStateRes
                lastPickupResultId = resultId
                // We don't remove from handle immediately to avoid StateFlow race conditions
                // instead we rely on lastPickupResultId to avoid duplicates.
            }
        }
    }

    LaunchedEffect(dAddrRes, dLatRes, dLngRes) {
        if (dAddrRes != null && dLatRes != null && dLngRes != null) {
            val resultId = "${dAddrRes}_${dLatRes}_${dLngRes}"
            if (resultId != lastDeliveryResultId) {
                deliveryAddress = dAddrRes!!
                deliveryLat = dLatRes!!
                deliveryLng = dLngRes!!
                lastDeliveryResultId = resultId
            }
        }
    }

    var savedAddresses by remember { mutableStateOf<List<SavedAddress>>(emptyList()) }
    var corporateAccounts by remember { mutableStateOf<List<CorporateAccount>>(emptyList()) }
    var selectedCorporateAccount by remember { mutableStateOf<CorporateAccount?>(null) }
    
    var description by rememberSaveable { mutableStateOf("") }
    var itemPhotoUri by rememberSaveable { mutableStateOf<Uri?>(null) }

    var isSecurePay by rememberSaveable { mutableStateOf(false) }
    var itemPrice by rememberSaveable { mutableStateOf("") }
    var initiatorRole by rememberSaveable { mutableStateOf("PAYER") }
    var sellerPhone by rememberSaveable { mutableStateOf("") }

    var promoCode by rememberSaveable { mutableStateOf("") }
    var activePromo by remember { mutableStateOf<PromoValidationResponse?>(null) }
    
    var recipientName by rememberSaveable { mutableStateOf("") }
    var recipientPhone by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(userName, userPhone) {
        if (recipientName.isNullOrBlank()) {
            recipientName = userName ?: ""
        }
        if (recipientPhone.isNullOrBlank()) {
            recipientPhone = userPhone ?: ""
        }
    }

    var quoteResult by remember { mutableStateOf<QuoteResponse?>(null) }
    var quoteId by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showSchedulingDialog by remember { mutableStateOf(false) }
    var showWaitlistDialog by remember { mutableStateOf(false) }
    var isInsured by remember { mutableStateOf(false) }
    var scheduledAt by remember { mutableStateOf<String?>(null) }
    var walletBalance by remember { mutableStateOf(0.0) }
    var billingMethod by remember { mutableStateOf("PERSONAL") } // PERSONAL, CORPORATE, WALLET
    
    var isSchedulingEnabled by remember { mutableStateOf(false) }
    var selectedDateTime by remember { mutableStateOf<Calendar?>(null) }

    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val tokenManager = remember { TokenManager(context) }
    val apiService = remember { ApiService.create(tokenManager) }

    val photoLauncher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? -> itemPhotoUri = uri }

    fun showDateTimePicker() {
        val current = Calendar.getInstance()
        android.app.DatePickerDialog(
            context,
            { _, year, month, dayOfMonth ->
                val date = Calendar.getInstance()
                date.set(year, month, dayOfMonth)
                
                android.app.TimePickerDialog(
                    context,
                    { _, hourOfDay, minute ->
                        date.set(Calendar.HOUR_OF_DAY, hourOfDay)
                        date.set(Calendar.MINUTE, minute)
                        date.set(Calendar.SECOND, 0)
                        
                        if (date.after(Calendar.getInstance())) {
                            selectedDateTime = date
                            scheduledAt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).format(date.time)
                        } else {
                            Toast.makeText(context, "Please select a future time", Toast.LENGTH_SHORT).show()
                        }
                    },
                    current.get(Calendar.HOUR_OF_DAY),
                    current.get(Calendar.MINUTE),
                    false
                ).show()
            },
            current.get(Calendar.YEAR),
            current.get(Calendar.MONTH),
            current.get(Calendar.DAY_OF_MONTH)
        ).apply {
            datePicker.minDate = System.currentTimeMillis()
        }.show()
    }

    LaunchedEffect(Unit) {
        try {
            val response = apiService.getSavedAddresses()
            savedAddresses = response.addresses
            val authorizations = apiService.getMyAuthorizations()
            corporateAccounts = authorizations.data ?: emptyList()
            
            val walletRes = apiService.getWalletInfo()
            walletBalance = walletRes.actualBalance
        } catch (e: Exception) {}
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
        contentColor = MaterialTheme.colorScheme.onBackground
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(painter = painterResource(id = R.drawable.pikop_logo), contentDescription = "Pikop Logo", modifier = Modifier.size(80.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Request a Delivery", 
                style = MaterialTheme.typography.headlineMedium, 
                color = MaterialTheme.colorScheme.onBackground, 
                modifier = Modifier.align(Alignment.Start),
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(24.dp))

            // Locations
            LocationInput(
                label = "Pickup Location",
                address = pickupAddress,
                onClick = { navController.navigate("map_address_search/Pickup/pickup") }
            )
            if (pickupAddress.isNotBlank()) {
                LandmarkInput(
                    value = pickupLandmark,
                    onValueChange = { pickupLandmark = it },
                    lat = pickupLat,
                    lng = pickupLng,
                    apiService = apiService
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            LocationInput(
                label = "Delivery Location",
                address = deliveryAddress,
                onClick = { navController.navigate("map_address_search/Delivery/delivery") }
            )
            if (deliveryAddress.isNotBlank()) {
                LandmarkInput(
                    value = deliveryLandmark,
                    onValueChange = { deliveryLandmark = it },
                    lat = deliveryLat,
                    lng = deliveryLng,
                    apiService = apiService
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            
            OutlinedTextField(
                value = description, 
                onValueChange = { description = it }, 
                label = { Text("Item Description", color = MaterialTheme.colorScheme.primary) }, 
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = MaterialTheme.colorScheme.onBackground,
                    unfocusedTextColor = MaterialTheme.colorScheme.onBackground,
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedLabelColor = MaterialTheme.colorScheme.primary,
                    unfocusedLabelColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    focusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    unfocusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    cursorColor = MaterialTheme.colorScheme.primary
                )
            )

            Spacer(modifier = Modifier.height(16.dp))
            Card(
                onClick = { photoLauncher.launch("image/*") }, 
                modifier = Modifier.fillMaxWidth(), 
                colors = CardDefaults.cardColors(containerColor = if (itemPhotoUri != null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = if (itemPhotoUri != null) Icons.Default.CheckCircle else Icons.Default.AddAPhoto, contentDescription = null, tint = if (itemPhotoUri != null) MaterialTheme.colorScheme.primary else Color.Gray)
                    Spacer(modifier = Modifier.width(16.dp))
                    Text(text = if (itemPhotoUri != null) "Photo Attached" else "Take Photo of Item", style = MaterialTheme.typography.titleSmall, color = if (itemPhotoUri != null) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.primary)
                }
            }

            // Secure Pay Section
            Spacer(modifier = Modifier.height(24.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSecurePay) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) 
                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Secure Pay Protection", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Escrow-protected payment for your item.", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = isSecurePay, onCheckedChange = { isSecurePay = it })
                    }

                    if (isSecurePay) {
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Are you the Buyer or the Seller?", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = initiatorRole == "PAYER", onClick = { initiatorRole = "PAYER" }, label = { Text("I am the Buyer") })
                            FilterChip(selected = initiatorRole == "SELLER", onClick = { initiatorRole = "SELLER" }, label = { Text("I am the Seller") })
                        }

                        OutlinedTextField(
                            value = itemPrice,
                            onValueChange = { if (it.all { char -> char.isDigit() }) itemPrice = it },
                            label = { Text("Item Price (₦)") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                        )

                        if (initiatorRole == "PAYER") {
                            Spacer(modifier = Modifier.height(12.dp))
                            OutlinedTextField(
                                value = sellerPhone,
                                onValueChange = { sellerPhone = it },
                                label = { Text("Seller's Phone Number") },
                                modifier = Modifier.fillMaxWidth(),
                                keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone)
                            )
                        }
                    }
                }
            }

            // Promo Code
            Spacer(modifier = Modifier.height(24.dp))
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = promoCode,
                    onValueChange = { promoCode = it },
                    label = { Text("Promo Code", color = MaterialTheme.colorScheme.primary) },
                    modifier = Modifier.weight(1f),
                    enabled = activePromo == null,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = MaterialTheme.colorScheme.onBackground,
                        unfocusedTextColor = MaterialTheme.colorScheme.onBackground,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedLabelColor = MaterialTheme.colorScheme.primary,
                        unfocusedLabelColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                        focusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                        unfocusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                        cursorColor = MaterialTheme.colorScheme.primary
                    )
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        coroutineScope.launch {
                            try {
                                val deliveryFee = quoteResult?.delivery_fee ?: 0.0
                                activePromo = apiService.validatePromoCode(mapOf(
                                    "code" to promoCode,
                                    "amount" to deliveryFee.toString()
                                ))
                                Toast.makeText(context, activePromo?.message ?: "Code Applied", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Invalid Code", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    enabled = promoCode.isNotBlank() && activePromo == null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary, 
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    Text("Apply")
                }
            }
            activePromo?.let { 
                val deliveryFee = quoteResult?.delivery_fee ?: 0.0
                val calculatedDiscount = if (it.discount_type == "fixed") it.value ?: 0.0 else deliveryFee * ((it.value ?: 0.0) / 100)
                val discount = minOf(calculatedDiscount, deliveryFee)
                Text("Discount: ₦$discount applied to delivery", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
            }

            // Billing Method (v4.6 Unified)
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Billing Method", 
                style = MaterialTheme.typography.titleMedium, 
                color = MaterialTheme.colorScheme.onBackground, 
                modifier = Modifier.align(Alignment.Start),
                fontWeight = FontWeight.Bold
            )
            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), 
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = billingMethod == "PERSONAL", 
                        onClick = { billingMethod = "PERSONAL"; selectedCorporateAccount = null }, 
                        label = { Text("Card/Transfer") }
                    )
                }
                
                if (walletBalance > 0) {
                    item {
                        val canAfford = (quoteResult?.total_fare ?: 0.0) <= walletBalance
                        FilterChip(
                            selected = billingMethod == "WALLET",
                            onClick = { billingMethod = "WALLET"; selectedCorporateAccount = null },
                            label = { Text("My Wallet (₦${walletBalance.toInt()})") },
                            enabled = canAfford,
                            leadingIcon = if (!canAfford) { { Icon(Icons.Default.Lock, null, modifier = Modifier.size(14.dp)) } } else null
                        )
                    }
                }

                items(corporateAccounts) { acc ->
                    FilterChip(
                        selected = selectedCorporateAccount?.id == acc.id, 
                        onClick = { 
                            selectedCorporateAccount = acc
                            billingMethod = "CORPORATE"
                        }, 
                        label = { Text(acc.company_name ?: "Company") }
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Recipient Details", 
                style = MaterialTheme.typography.titleMedium, 
                color = MaterialTheme.colorScheme.onBackground, 
                modifier = Modifier.align(Alignment.Start),
                fontWeight = FontWeight.Bold
            )
            
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = recipientName, 
                onValueChange = { recipientName = it }, 
                label = { Text("Recipient Name", color = MaterialTheme.colorScheme.primary) }, 
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = MaterialTheme.colorScheme.onBackground,
                    unfocusedTextColor = MaterialTheme.colorScheme.onBackground,
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedLabelColor = MaterialTheme.colorScheme.primary,
                    unfocusedLabelColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    focusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    unfocusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    cursorColor = MaterialTheme.colorScheme.primary
                )
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = recipientPhone, 
                onValueChange = { recipientPhone = it }, 
                label = { Text("Recipient Phone", color = MaterialTheme.colorScheme.primary) }, 
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = MaterialTheme.colorScheme.onBackground,
                    unfocusedTextColor = MaterialTheme.colorScheme.onBackground,
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedLabelColor = MaterialTheme.colorScheme.primary,
                    unfocusedLabelColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                    focusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    unfocusedPlaceholderColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                    cursorColor = MaterialTheme.colorScheme.primary
                )
            )

            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Delivery Schedule", 
                style = MaterialTheme.typography.titleMedium, 
                color = MaterialTheme.colorScheme.onBackground, 
                modifier = Modifier.align(Alignment.Start),
                fontWeight = FontWeight.Bold
            )
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !isSchedulingEnabled, onClick = { isSchedulingEnabled = false; scheduledAt = null }, label = { Text("Deliver Now") })
                FilterChip(selected = isSchedulingEnabled, onClick = { isSchedulingEnabled = true }, label = { Text("Schedule for Later") })
            }

            if (isSchedulingEnabled) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            val displayText = selectedDateTime?.let { 
                                SimpleDateFormat("EEE, MMM d, hh:mm a", Locale.getDefault()).format(it.time)
                            } ?: "Select Date & Time"
                            Text(displayText, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Bold)
                            
                            Button(onClick = { showDateTimePicker() }) {
                                Text("Change")
                            }
                        }
                        
                        Text(
                            "Note: Scheduled missions activate 30 mins before the set time. Night deliveries (6 PM - 6 AM) are restricted to vehicle-only.",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray,
                            modifier = Modifier.padding(top = 8.dp)
                        )

                        // Inline Validation (v4.5 Hardening)
                        selectedDateTime?.let {
                            val hour = it.get(Calendar.HOUR_OF_DAY)
                            if (hour < 6 || hour >= 18) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.errorContainer,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        "Night scheduling is restricted to Vehicle dispatch only. Foot agents and Cyclists will not be matched.",
                                        modifier = Modifier.padding(8.dp),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (quoteResult != null) {
                Spacer(modifier = Modifier.height(24.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                    val result = quoteResult!!
                    val size = result.size_tier ?: "MEDIUM"
                    val promo = activePromo
                    
                    // Promo Rule: Only applies to Delivery Fee, capped at Delivery Fee amount.
                    val deliveryFee = result.delivery_fee ?: 0.0
                    val itemPriceNum = result.item_price ?: 0.0
                    val platformFee = result.platform_fee_amount ?: 0.0
                    val smsCharge = result.sms_charge_amount ?: 0.0
                    val insuranceFee = result.insurance_fee ?: 0.0
                    
                    val isBuyer = initiatorRole == "PAYER"
                    val totalFareSum = if (isBuyer) itemPriceNum + platformFee + deliveryFee + smsCharge + (if (isInsured) insuranceFee else 0.0) else 0.0
                    
                    val isFullFreePromo = promo != null && (promo.value ?: 0.0) >= 100.0
                    val calculatedDiscount = if (promo == null) 0.0 
                        else if (isFullFreePromo) totalFareSum
                        else if (promo.discount_type == "fixed") promo.value ?: 0.0 
                        else deliveryFee * ((promo.value ?: 0.0) / 100.0)
                    
                    val discount = if (isFullFreePromo) totalFareSum else minOf(calculatedDiscount, deliveryFee)
                    val amountToCharge = maxOf(0.0, totalFareSum - discount)

                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Order Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        // Section 1: COD Item & Fees
                        if (isSecurePay) {
                            Text("Secure Pay Breakdown", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            SummaryLine("Item price", "₦$itemPriceNum")
                            SummaryLine("Platform fee (Buyer pays)", "₦$platformFee")
                            
                            val subtotal = itemPriceNum + platformFee
                            SummaryLine(if (isBuyer) "Item Subtotal (You pay)" else "Item Subtotal (Recipient pays)", "₦$subtotal", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(12.dp))
                        }

                        // Section 2: Delivery
                        Text("Logistics", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        SummaryLine("Delivery fee", "₦$deliveryFee")
                        if (discount > 0) {
                            SummaryLine("Promo discount", "-₦$discount", color = MaterialTheme.colorScheme.primary)
                        }
                        
                        // Dynamic Adjustments
                        val weatherMult = result.weather_multiplier ?: 1.0
                        if (weatherMult > 1.0) {
                            SummaryLine("Weather adjustment", "x$weatherMult", color = Color(0xFFF57C00))
                        }
                        val trafficMult = result.traffic_multiplier ?: 1.0
                        if (trafficMult > 1.0) {
                            SummaryLine("Traffic adjustment", "x$trafficMult", color = Color(0xFFD32F2F))
                        }
                        val surgeMult = result.surge_multiplier ?: 1.0
                        if (surgeMult > 1.0) {
                            SummaryLine("High-demand adjustment", "x$surgeMult", color = Color(0xFFD32F2F))
                        }

                        // SMS Charge for Guest (ONLY if > 0)
                        val smsChargeVal = result.sms_charge_amount ?: 0.0
                        if (smsChargeVal > 0) {
                            SummaryLine("Guest SMS charge", "₦$smsChargeVal")
                        }

                        // Optional Item Insurance (v4.3)
                        if (insuranceFee > 0) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f), RoundedCornerShape(8.dp)).padding(8.dp)) {
                                Checkbox(checked = isInsured, onCheckedChange = { isInsured = it })
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Protect this item", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                    Text("Cover loss or damage for ₦$insuranceFee", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                                }
                            }
                            if (isInsured) {
                                SummaryLine("Item protection premium", "₦$insuranceFee", color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        val logisticsTotal = maxOf(0.0, deliveryFee - (if (isFullFreePromo) deliveryFee else discount)) + smsChargeVal
                        SummaryLine(if (isBuyer) "Logistics Subtotal (You pay)" else "Logistics Subtotal (Recipient pays)", "₦$logisticsTotal", fontWeight = FontWeight.Bold)

                        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), thickness = 0.5.dp)
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Total Upfront", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                            Text("₦$amountToCharge", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.primary)
                        }

                        if (isSecurePay && !isBuyer) {
                            Spacer(modifier = Modifier.height(8.dp))
                            val grandTotal = itemPriceNum + platformFee + logisticsTotal + (if (isInsured) insuranceFee else 0.0)
                            Text("Note: You are paying ₦0 now. The Recipient will receive an SMS to pay ₦$grandTotal to activate this mission.", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                        }

                        if (isSecurePay && result.payer_info?.type == "GUEST") {
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f))
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Recipient is not a Pikop user. They will receive an SMS link to pay.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                }
                            }
                        }
                    }
                }
            }

            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = errorMessage!!, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(32.dp))

            if (quoteId == null) {
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isLoading = true; errorMessage = null
                            try {
                                val response = apiService.getQuote(
                                    QuoteRequest(
                                        pickup_address = pickupAddress, 
                                        delivery_address = deliveryAddress, 
                                        pickup_landmark = pickupLandmark.ifBlank { "Main Gate" },
                                        delivery_landmark = deliveryLandmark.ifBlank { "Main Entrance" },
                                        item_description = description.ifBlank { "Package Delivery" }, 
                                        pickup_lat = pickupLatLng?.latitude ?: 0.0, 
                                        pickup_lng = pickupLatLng?.longitude ?: 0.0, 
                                        delivery_lat = deliveryLatLng?.latitude ?: 0.0, 
                                        delivery_lng = deliveryLatLng?.longitude ?: 0.0,
                                        item_price = if (isSecurePay) itemPrice.toDoubleOrNull() ?: 0.0 else 0.0,
                                        initiator_role = if (isSecurePay) initiatorRole else "PAYER",
                                        recipient_phone = if (isSecurePay) recipientPhone else null,
                                        pickup_state = (pickupState ?: "Lagos").ifBlank { "Lagos" }
                                    )
                                )
                                if (response.success && response.quote_id != null) {
                                    quoteId = response.quote_id
                                    quoteResult = response
                                    
                                    if (!response.is_live) {
                                        showWaitlistDialog = true
                                    } else if (response.restricted_dispatch && response.drivers_count == 0) {
                                        showSchedulingDialog = true
                                    }
                                } else {
                                    errorMessage = "Failed to get valid quote"
                                }
                            } catch (e: Exception) { 
                                errorMessage = ErrorUtils.parseError(e)
                                Toast.makeText(context, "Quote Fetch Failed: $errorMessage", Toast.LENGTH_SHORT).show()
                            } finally { isLoading = false }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    enabled = !isLoading && pickupAddress.isNotBlank() && deliveryAddress.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary, 
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp), 
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text("Get Fare Quote", fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                val isZeroUpfront = quoteResult?.total_fare == 0.0
                Button(
                    onClick = {
                        coroutineScope.launch {
                            isLoading = true
                            try {
                                val file = getFileFromUri(context, itemPhotoUri!!)
                                val uploadRes = apiService.uploadOrderPhoto(MultipartBody.Part.createFormData("file", file.name, file.asRequestBody("image/*".toMediaTypeOrNull())))
                                val pUrl = uploadRes["url"] ?: ""
                                
                                val qId = quoteId ?: ""
                                val result = quoteResult
                                if (selectedCorporateAccount != null) {
                                    val success = finalizeOrderAfterPayment(
                                        apiService = apiService, 
                                        quoteId = qId, 
                                        corporateAccountId = selectedCorporateAccount!!.id, 
                                        promoId = activePromo?.promo_id, 
                                        paymentReference = "CORPORATE", 
                                        recipientName = recipientName, 
                                        recipientPhone = recipientPhone, 
                                        notes = notes, 
                                        pLat = pickupLatLng?.latitude ?: 0.0, 
                                        pLng = pickupLatLng?.longitude ?: 0.0, 
                                        dLat = deliveryLatLng?.latitude ?: 0.0, 
                                        dLng = deliveryLatLng?.longitude ?: 0.0, 
                                        itemPhotoUrl = pUrl, 
                                        pSummary = pickupAddress.take(50), 
                                        dSummary = deliveryAddress.take(50),
                                        quoteResult = result,
                                        sellerPhone = if (isSecurePay && initiatorRole == "PAYER") sellerPhone else null,
                                        pickupState = pickupState,
                                        scheduledAt = scheduledAt,
                                        insuranceFee = result?.insurance_fee,
                                        isInsured = isInsured,
                                        surgeMultiplier = result?.surge_multiplier
                                    )
                                    if (success) {
                                        onCelebration()
                                        onOrderComplete("CORPORATE")
                                    } else {
                                        Toast.makeText(context, "Failed to finalize corporate order", Toast.LENGTH_SHORT).show()
                                    }
                                } else if (billingMethod == "WALLET") {
                                    val success = finalizeOrderAfterPayment(
                                        apiService = apiService, 
                                        quoteId = qId, 
                                        corporateAccountId = null, 
                                        promoId = activePromo?.promo_id, 
                                        paymentReference = "WALLET_${java.util.UUID.randomUUID()}", 
                                        recipientName = recipientName, 
                                        recipientPhone = recipientPhone, 
                                        notes = notes, 
                                        pLat = pickupLatLng?.latitude ?: 0.0, 
                                        pLng = pickupLatLng?.longitude ?: 0.0, 
                                        dLat = deliveryLatLng?.latitude ?: 0.0, 
                                        dLng = deliveryLatLng?.longitude ?: 0.0, 
                                        itemPhotoUrl = pUrl, 
                                        pSummary = pickupAddress.take(50), 
                                        dSummary = deliveryAddress.take(50),
                                        quoteResult = result,
                                        sellerPhone = if (isSecurePay && initiatorRole == "PAYER") sellerPhone else null,
                                        pickupState = pickupState,
                                        scheduledAt = scheduledAt,
                                        insuranceFee = result?.insurance_fee,
                                        isInsured = isInsured,
                                        surgeMultiplier = result?.surge_multiplier
                                    )
                                    if (success) {
                                        onCelebration()
                                        onOrderComplete("WALLET")
                                    } else {
                                        Toast.makeText(context, "Wallet payment failed", Toast.LENGTH_SHORT).show()
                                    }
                                } else if (result != null) {
                                    val promo = activePromo
                                    
                                    // Promo Rule: 100% coupons (e.g. TESTER100) waive the ENTIRE order total.
                                    val deliveryFee = result.delivery_fee ?: 0.0
                                    val itemPriceNum = result.item_price ?: 0.0
                                    val platformFee = result.platform_fee_amount ?: 0.0
                                    val smsCharge = result.sms_charge_amount ?: 0.0
                                    val insuranceFee = if (isInsured) result.insurance_fee ?: 0.0 else 0.0
                                    
                                    val isFullFreePromo = promo != null && (promo.value ?: 0.0) >= 100.0
                                    
                                    val calculatedDiscount = if (promo == null) 0.0 
                                        else if (isFullFreePromo) (itemPriceNum + platformFee + deliveryFee + smsCharge + insuranceFee)
                                        else if (promo.discount_type == "fixed") promo.value ?: 0.0 
                                        else deliveryFee * ((promo.value ?: 0.0) / 100)
                                    
                                    val discount = if (isFullFreePromo) calculatedDiscount else minOf(calculatedDiscount, deliveryFee)
                                    
                                    // Logic: If user is Buyer, they pay everything minus discount. If Seller, they pay 0.
                                    val isBuyer = initiatorRole == "PAYER"
                                    val baseCharge = if (isBuyer) itemPriceNum + platformFee + deliveryFee + smsCharge + insuranceFee else 0.0
                                    val amountToCharge = maxOf(0.0, baseCharge - discount)

                                    // ZERO UPFRONT BYPASS (Seller-initiated COD or 100% Promo)
                                    if (amountToCharge <= 0) {
                                        val freePaymentRef = if (isZeroUpfront) "REQUEST_${java.util.UUID.randomUUID()}" else "FREE_${java.util.UUID.randomUUID()}"
                                        try {
                                            val request = CreateOrderRequest(
                                                quote_id = qId, 
                                                corporate_account_id = null, 
                                                promo_id = activePromo?.promo_id, 
                                                payment_method = if (isZeroUpfront) "secure_pay_request" else "promo", 
                                                recipient_name = recipientName, 
                                                recipient_phone = recipientPhone, 
                                                notes = notes, 
                                                pickup_lat = pickupLatLng?.latitude ?: 0.0, 
                                                pickup_lng = pickupLatLng?.longitude ?: 0.0, 
                                                delivery_lat = deliveryLatLng?.latitude ?: 0.0, 
                                                delivery_lng = deliveryLatLng?.longitude ?: 0.0, 
                                                item_photo_url = pUrl, 
                                                pickup_display_summary = pickupAddress.take(50), 
                                                delivery_display_summary = deliveryAddress.take(50),
                                                payment_reference = freePaymentRef,
                                                item_price = result.item_price,
                                                delivery_fee = result.delivery_fee,
                                                seller_phone = if (isSecurePay && initiatorRole == "PAYER") sellerPhone else null,
                                                pickup_state = pickupState,
                                                recipient_payable = result.recipient_payable,
                                                scheduled_at = scheduledAt,
                                                insurance_fee = result.insurance_fee,
                                                is_insured = isInsured,
                                                surge_multiplier = result.surge_multiplier
                                            )
                                            val response = apiService.createOrder(request)
                                            if (response.status == "SEARCHING" || response.status == "AWAITING_PAYMENT" || response.status == "PAYMENT_CAPTURED" || response.status == "SCHEDULED") {
                                                Toast.makeText(context, if (scheduledAt != null) "Mission Scheduled for 06:00 AM" else if (isZeroUpfront) "Mission Created! Recipient will pay to activate." else "Mission Activated Successfully!", Toast.LENGTH_LONG).show()
                                                onCelebration()
                                                onOrderComplete("FREE")
                                            } else {
                                                Toast.makeText(context, "Server Error: Could not process mission", Toast.LENGTH_LONG).show()
                                            }
                                        } catch (e: Exception) {
                                            val detail = ErrorUtils.parseError(e)
                                            Toast.makeText(context, "Failed to create mission: $detail", Toast.LENGTH_LONG).show()
                                        }
                                        isLoading = false
                                        return@launch
                                    }

                                    try {
                                        val paymentInit = apiService.initializePayment(
                                            PaymentInitializationRequest(
                                                amount = amountToCharge, 
                                                email = userEmail,
                                                quote_id = qId,
                                                item_price = if (isSecurePay) itemPrice.toDoubleOrNull() ?: 0.0 else 0.0,
                                                delivery_fee = result.delivery_fee,
                                                platform_fee_amount = result.platform_fee_amount,
                                                fee_payer = result.fee_payer,
                                                seller_phone = if (isSecurePay && initiatorRole == "PAYER") sellerPhone else null,
                                                promo_id = activePromo?.promo_id,
                                                pickup_state = pickupState,
                                                metadata = mapOf(
                                                    "quote_id" to qId,
                                                    "is_insured" to isInsured.toString(),
                                                    "insurance_fee" to (result.insurance_fee ?: 0.0).toString(),
                                                    "surge_multiplier" to (result.surge_multiplier ?: 1.0).toString(),
                                                    "scheduled_at" to (scheduledAt ?: "")
                                                )
                                            )
                                        )
                                        val authUrl = paymentInit.authorization_url
                                        
                                        if (!authUrl.isNullOrBlank()) {
                                            onNavigateToPayment(
                                                authUrl!!,
                                                qId,
                                                pickupLatLng?.latitude ?: 0.0,
                                                pickupLatLng?.longitude ?: 0.0,
                                                deliveryLatLng?.latitude ?: 0.0,
                                                deliveryLatLng?.longitude ?: 0.0,
                                                pUrl,
                                                pickupAddress.take(50),
                                                deliveryAddress.take(50),
                                                recipientName,
                                                recipientPhone,
                                                notes,
                                                activePromo?.promo_id
                                            )
                                        } else {
                                            errorMessage = "Payment initialization failed: Missing gateway URL"
                                            Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
                                        }
                                    } catch (e: Exception) {
                                        errorMessage = ErrorUtils.parseError(e)
                                        Toast.makeText(context, "Payment Error: $errorMessage", Toast.LENGTH_LONG).show()
                                    }
                                }
                            } catch (e: Exception) { 
                                android.util.Log.e("PayDeploy", "Pay & Deploy failed", e)
                                errorMessage = ErrorUtils.parseError(e)
                                Toast.makeText(context, "Something went wrong: $errorMessage", Toast.LENGTH_SHORT).show()
                            } finally { isLoading = false }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                    enabled = !isLoading && recipientName.isNotBlank() && recipientPhone.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary, 
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    )
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp), 
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                    } else {
                        Text(if (scheduledAt != null) "Pay & Schedule Mission" else if (isZeroUpfront) "Deploy & Request Payment" else "Pay & Deploy Mission", fontWeight = FontWeight.Bold)
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(40.dp))
        }

        if (showWaitlistDialog) {
            val locationParts = pickupAddress.split(',')
            val areaName = if (locationParts.size >= 2) locationParts[locationParts.size - 2].trim() else "your area"
            
            AlertDialog(
                onDismissRequest = { showWaitlistDialog = false; quoteId = null },
                title = { Text("Pikop isn't live here yet!") },
                text = { Text("We're currently launching city-by-city across Nigeria. Would you like us to notify you when we activate missions in $areaName?") },
                confirmButton = {
                    Button(onClick = {
                        coroutineScope.launch {
                            try {
                                apiService.joinWaitlist(JoinWaitlistRequest(
                                    city_name = areaName,
                                    email = userEmail
                                ))
                                Toast.makeText(context, "Interest recorded! We'll be in touch.", Toast.LENGTH_LONG).show()
                            } catch (_: Exception) {}
                            showWaitlistDialog = false
                            quoteId = null
                        }
                    }) { Text("Notify Me") }
                },
                dismissButton = {
                    TextButton(onClick = { showWaitlistDialog = false; quoteId = null }) { Text("Cancel") }
                }
            )
        }

        if (showSchedulingDialog) {
            AlertDialog(
                onDismissRequest = { showSchedulingDialog = false; quoteId = null },
                title = { Text("Night Dispatch Restricted") },
                text = { Text("No drivers are currently available for this route. Would you like to schedule this mission for tomorrow morning at 06:00 AM?") },
                confirmButton = {
                    TextButton(onClick = {
                        val calendar = java.util.Calendar.getInstance()
                        calendar.add(java.util.Calendar.DAY_OF_YEAR, 1)
                        calendar.set(java.util.Calendar.HOUR_OF_DAY, 6)
                        calendar.set(java.util.Calendar.MINUTE, 0)
                        calendar.set(java.util.Calendar.SECOND, 0)
                        
                        val sdf = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US)
                        scheduledAt = sdf.format(calendar.time)
                        showSchedulingDialog = false
                    }) {
                        Text("Schedule for 06:00 AM")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { 
                        showSchedulingDialog = false
                        quoteId = null 
                    }) {
                        Text("Cancel Request")
                    }
                }
            )
        }
    }
}

@Composable
fun LandmarkInput(
    value: String,
    onValueChange: (String) -> Unit,
    lat: Double,
    lng: Double,
    apiService: ApiService
) {
    var suggestions by remember { mutableStateOf<List<LandmarkSuggestion>>(emptyList()) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(value) {
        if (value.length >= 2) {
            try {
                val res = apiService.getLandmarkSuggestions(lat, lng)
                suggestions = res.data.filter { it.display_text.contains(value, ignoreCase = true) }
            } catch (_: Exception) {}
        } else {
            suggestions = emptyList()
        }
    }

    Column(modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text("Landmark / Room / Suite (Required)", fontSize = 12.sp) },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("e.g. Opposite the Blue Bank", fontSize = 14.sp) },
            leadingIcon = { Icon(Icons.Default.Flag, null, modifier = Modifier.size(18.dp)) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
            )
        )
        
        if (suggestions.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column {
                    suggestions.forEach { suggestion ->
                        Text(
                            text = suggestion.display_text,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onValueChange(suggestion.display_text); suggestions = emptyList() }
                                .padding(12.dp),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SummaryLine(label: String, value: String, color: Color = Color.Unspecified, fontWeight: FontWeight = FontWeight.Normal) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Medium)
        Text(value, style = MaterialTheme.typography.bodyLarge, fontWeight = fontWeight, color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurface else color)
    }
}

@Composable
fun LocationInput(label: String, address: String?, onClick: () -> Unit) {
    val displayAddress = address ?: ""
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                        shape = androidx.compose.foundation.shape.CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (label.contains("Pickup")) Icons.Default.Circle else Icons.Default.Place, 
                    contentDescription = null, 
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                Text(
                    text = displayAddress.ifBlank { "Search address..." },
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (displayAddress.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurface,
                    fontWeight = if (displayAddress.isBlank()) FontWeight.Normal else FontWeight.Medium,
                    maxLines = 1,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
            }
        }
    }
}

private fun getFileFromUri(context: android.content.Context, uri: Uri): File {
    val tempFile = File(context.cacheDir, "item_temp_${System.currentTimeMillis()}.jpg")
    context.contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(tempFile).use { output -> input.copyTo(output) } }
    return tempFile
}

suspend fun finalizeOrderAfterPayment(
    apiService: ApiService, quoteId: String, corporateAccountId: String?, promoId: String?, 
    paymentReference: String, recipientName: String, recipientPhone: String, notes: String?, 
    pLat: Double, pLng: Double, dLat: Double, dLng: Double, itemPhotoUrl: String, 
    pSummary: String, dSummary: String, quoteResult: QuoteResponse? = null,
    sellerPhone: String? = null, pickupState: String? = null, scheduledAt: String? = null,
    insuranceFee: Double? = null, isInsured: Boolean = false, surgeMultiplier: Double? = null
): Boolean {
    return try {
        // ... (existing webhook check logic)
        
        // 2. Fallback: Manually trigger activation if Webhook is delayed
        val request = CreateOrderRequest(
            quote_id = quoteId, 
            corporate_account_id = corporateAccountId, 
            promo_id = promoId, 
            payment_method = if (corporateAccountId != null) "corporate" else "card", 
            recipient_name = recipientName, 
            recipient_phone = recipientPhone, 
            notes = notes, 
            pickup_lat = pLat, 
            pickup_lng = pLng, 
            delivery_lat = dLat, 
            delivery_lng = dLng, 
            item_photo_url = itemPhotoUrl, 
            pickup_display_summary = pSummary, 
            delivery_display_summary = dSummary,
            payment_reference = paymentReference,
            item_price = quoteResult?.item_price,
            delivery_fee = quoteResult?.delivery_fee,
            seller_phone = sellerPhone,
            pickup_state = pickupState,
            scheduled_at = scheduledAt,
            insurance_fee = quoteResult?.insurance_fee,
            is_insured = quoteResult?.insurance_fee != null && quoteResult.insurance_fee > 0,
            surge_multiplier = quoteResult?.surge_multiplier
        )
        val response = apiService.createOrder(request)
        response.status == "SEARCHING" || response.status == "MATCHED" || response.status == "QUEUED" || response.status == "PAYMENT_CAPTURED"
    } catch (e: Exception) { 
        android.util.Log.e("PikopPayment", "Finalization error: ${e.message}", e)
        false 
    }
}
