package com.ng.pikop.feature.fulfiller

import androidx.compose.foundation.Image
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.maps.android.compose.*
import com.ng.pikop.R
import com.ng.pikop.core.datastore.TokenManager
import com.ng.pikop.core.network.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import android.location.Geocoder
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import java.util.Locale
import kotlinx.coroutines.tasks.await

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FulfillerDashboardScreen(
    userEmail: String,
    kycStatus: String,
    onAcceptOffer: (String) -> Unit, 
    onGoToWallet: () -> Unit,
    onGoToKyc: () -> Unit,
    onGoToInsights: () -> Unit,
    onGoToAbout: () -> Unit,
    onCelebration: () -> Unit = {},
    onLogout: () -> Unit
) {
    var isOnline by remember { mutableStateOf(false) }
    var offers by remember { mutableStateOf<List<OfferResponse>>(emptyList()) }
    var isStatusLoading by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var history by remember { mutableStateOf<List<FulfillerOrderResponse>>(emptyList()) }
    var walletBalance by remember { mutableStateOf(0.0) }
    var profileData by remember { mutableStateOf<com.ng.pikop.core.network.FulfillerProfileResponse?>(null) }
    var agentLocation by remember { mutableStateOf<LatLng?>(null) }
    
    val context = LocalContext.current
    val tokenManager = remember { TokenManager(context) }
    val coroutineScope = rememberCoroutineScope()
    val apiService = remember { ApiService.create(tokenManager) }
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }
    val userId by tokenManager.userId.collectAsState(initial = null)

    // Smart Nigeria State & City Center Coordinate Resolver
    val getCityStateCoordinates: (String?) -> LatLng = { input ->
        val text = (input ?: "").lowercase(Locale.getDefault())
        when {
            text.contains("rivers") || text.contains("port harcourt") || text.contains("obio") || text.contains("eleme") || text.contains("bonny") || text.contains("onne") -> LatLng(4.8156, 7.0498) // Port Harcourt
            text.contains("fct") || text.contains("abuja") || text.contains("gwarinpa") || text.contains("wuse") || text.contains("maitama") || text.contains("asokoro") || text.contains("kubwa") -> LatLng(9.0765, 7.3986) // Abuja
            text.contains("oyo") || text.contains("ibadan") || text.contains("ogbomosho") -> LatLng(7.3775, 3.9470) // Ibadan
            text.contains("kano") -> LatLng(12.0022, 8.5919) // Kano
            text.contains("delta") || text.contains("asaba") || text.contains("warri") || text.contains("sapele") -> LatLng(6.2059, 6.6959) // Asaba/Warri
            text.contains("anambra") || text.contains("awka") || text.contains("onitsha") || text.contains("nnewi") -> LatLng(6.2209, 7.0670) // Awka
            text.contains("enugu") || text.contains("nsukka") -> LatLng(6.4584, 7.5464) // Enugu
            text.contains("edo") || text.contains("benin") -> LatLng(6.3350, 5.6037) // Benin City
            text.contains("kaduna") || text.contains("zaria") -> LatLng(10.5105, 7.4165) // Kaduna
            text.contains("ogun") || text.contains("abeokuta") || text.contains("ijebu") || text.contains("sango") -> LatLng(7.1475, 3.3619) // Abeokuta
            text.contains("akwa ibom") || text.contains("uyo") || text.contains("eket") -> LatLng(5.0377, 7.9128) // Uyo
            text.contains("cross river") || text.contains("calabar") -> LatLng(4.9757, 8.3417) // Calabar
            text.contains("imo") || text.contains("owerri") -> LatLng(5.4832, 7.0358) // Owerri
            text.contains("abia") || text.contains("aba") || text.contains("umuahia") -> LatLng(5.1066, 7.3667) // Aba
            text.contains("plateau") || text.contains("jos") -> LatLng(9.8965, 8.8583) // Jos
            else -> LatLng(6.5244, 3.3792) // Lagos default
        }
    }

    val agentCityCenter = remember(profileData) {
        getCityStateCoordinates(profileData?.current_state ?: profileData?.home_address)
    }

    val fetchDashboardData = {
        coroutineScope.launch {
            try {
                isLoading = true
                val profile = apiService.getFulfillerProfile()
                val prevStreak = profileData?.current_streak_days ?: 0
                val prevCompleted = profileData?.stats?.total_completed ?: 0
                
                profileData = profile.data ?: profile
                isOnline = profileData?.online_status == "ONLINE"

                val newStreak = profileData?.current_streak_days ?: 0
                val newCompleted = profileData?.stats?.total_completed ?: 0
                
                if ((newStreak == 7 && prevStreak < 7) || (newStreak == 30 && prevStreak < 30)) {
                    onCelebration()
                } else if (newCompleted == 1 && prevCompleted == 0) {
                    onCelebration()
                } else if (profileData?.kyc_status == "VERIFIED" && (kycStatus == "PENDING" || kycStatus == "NOT_STARTED")) {
                    onCelebration()
                }
                
                val wallet = apiService.getWalletInfo()
                walletBalance = wallet.actualBalance
                history = apiService.getFulfillerOrders()
                offers = apiService.getOffers()
            } catch (e: Exception) {
                android.util.Log.e("DashboardRefresh", "Fetch failed: ${e.message}")
            } finally {
                isLoading = false
            }
        }
    }

    // Location Resolution Helper
    val resolveAgentLocation: suspend () -> Unit = @android.annotation.SuppressLint("MissingPermission") {
        try {
            var loc = try { fusedLocationClient.lastLocation.await() } catch (_: Exception) { null }
            if (loc == null) {
                loc = try { fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await() } catch (_: Exception) { null }
            }
            if (loc != null) {
                val latLng = LatLng(loc.latitude, loc.longitude)
                agentLocation = latLng
                
                val state = withContext(kotlinx.coroutines.Dispatchers.IO) {
                    try {
                        val geocoder = Geocoder(context, Locale.getDefault())
                        @Suppress("DEPRECATION")
                        geocoder.getFromLocation(loc.latitude, loc.longitude, 1)?.firstOrNull()?.adminArea
                    } catch (e: Exception) { null }
                }
                
                apiService.updateStatus(FulfillerStatusRequest(
                    online_status = if (isOnline) "ONLINE" else "OFFLINE",
                    lat = loc.latitude,
                    lng = loc.longitude,
                    current_state = state
                ))
            }
        } catch (_: Exception) {}
    }

    // Runtime Permission Launcher
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.any { it }
        if (granted) {
            coroutineScope.launch {
                resolveAgentLocation()
            }
        }
    }

    // Initial Fetch on Launch
    LaunchedEffect(Unit) {
        fetchDashboardData()
        permissionLauncher.launch(arrayOf(
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        ))
        resolveAgentLocation()
    }

    // Socket Connection & Real-Time Event Listener
    DisposableEffect(userId) {
        val userIdStr = userId?.toString() ?: ""
        if (userIdStr.isNotBlank()) {
            SocketManager.connect(userIdStr)
            SocketManager.on("new_mission_offer") {
                android.util.Log.d("DashboardSocket", "Inbound mission offer via socket. Refreshing...")
                fetchDashboardData()
            }
            SocketManager.on("order_status_updated") {
                android.util.Log.d("DashboardSocket", "Order status update via socket. Refreshing...")
                fetchDashboardData()
            }
            SocketManager.on("status_updated") {
                fetchDashboardData()
            }
        }
        onDispose {}
    }

    // Polling & Background Sync (Runs every 5 seconds for real-time mission updates)
    LaunchedEffect(isOnline) {
        while (true) {
            try {
                if (isOnline) {
                    offers = apiService.getOffers()
                    resolveAgentLocation()
                }
                history = apiService.getFulfillerOrders()
                val wallet = apiService.getWalletInfo()
                walletBalance = wallet.actualBalance
            } catch (e: Exception) {
                android.util.Log.e("DashboardPoll", "Error: ${e.message}")
            }
            delay(5000) // 5s interval for instant mission updates
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { 
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Pikop Fulfiller", fontWeight = FontWeight.Bold)
                        if (kycStatus == "VERIFIED" || profileData?.kyc_status == "VERIFIED") {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = Color(0xFF008751).copy(alpha = 0.12f),
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF008751).copy(alpha = 0.5f))
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.pikop_badge),
                                        contentDescription = "Verified",
                                        modifier = Modifier.size(28.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("VERIFIED", fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF008751))
                                }
                            }
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { fetchDashboardData() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                }
            )
        }
    ) { padding ->
        Surface(
            modifier = Modifier.padding(padding).fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            var showHotspots by remember { mutableStateOf(false) }
            var hotspots by remember { mutableStateOf<List<LatLng>>(emptyList()) }
            
            val cameraPositionState = rememberCameraPositionState {
                position = CameraPosition.fromLatLngZoom(agentLocation ?: agentCityCenter, 13f)
            }

            // Immediately center map on agent's city when profile data is loaded
            LaunchedEffect(agentCityCenter) {
                if (agentLocation == null) {
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(agentCityCenter, 13f))
                }
            }

            // Animate map camera whenever agent's exact GPS location is resolved
            LaunchedEffect(agentLocation) {
                agentLocation?.let { pos ->
                    cameraPositionState.animate(CameraUpdateFactory.newLatLngZoom(pos, 14f))
                }
            }

            LaunchedEffect(showHotspots) {
                if (showHotspots) {
                    try {
                        val res = apiService.getDemandHeatmap()
                        @Suppress("UNCHECKED_CAST")
                        val data = res["data"] as? List<Map<String, Any>>
                        val parsedHotspots = data?.map { LatLng((it["lat"] as? Number)?.toDouble() ?: 0.0, (it["lng"] as? Number)?.toDouble() ?: 0.0) } ?: emptyList()
                        hotspots = parsedHotspots
                    } catch (_: Exception) {}
                }
            }

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                // 1. Map Section
                item {
                    Box(modifier = Modifier.fillMaxWidth().height(200.dp)) {
                        GoogleMap(
                            modifier = Modifier.fillMaxSize(),
                            cameraPositionState = cameraPositionState,
                            uiSettings = MapUiSettings(zoomControlsEnabled = false)
                        ) {
                            val activeMarkerPos = agentLocation ?: agentCityCenter
                            Marker(
                                state = MarkerState(position = activeMarkerPos),
                                icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE),
                                title = if (agentLocation != null) "Your Live GPS Location" else "Operating Area"
                            )
                            if (showHotspots) {
                                hotspots.forEach { spot ->
                                    Marker(
                                        state = MarkerState(position = spot),
                                        icon = BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_ORANGE),
                                        alpha = 0.6f,
                                        title = "High Demand Zone"
                                    )
                                }
                            }
                        }

                        FilterChip(
                            selected = showHotspots,
                            onClick = { showHotspots = !showHotspots },
                            label = { Text("Demand Hotspots", fontSize = 10.sp) },
                            modifier = Modifier.align(Alignment.TopEnd).padding(12.dp),
                            leadingIcon = { Icon(Icons.Default.LocalFireDepartment, null, modifier = Modifier.size(14.dp)) }
                        )
                    }
                }

                // Active Mission Resume Banner
                val activeMission = history.firstOrNull { 
                    val s = it.status?.uppercase() ?: ""
                    s.isNotBlank() && s != "QUEUED" && s !in listOf("DELIVERED", "CANCELLED", "RELEASED", "REFUNDED", "RECIPIENT_ABSENT") 
                }

                val queuedMission = history.firstOrNull { 
                    (it.status?.uppercase() ?: "") == "QUEUED"
                }

                if (activeMission != null) {
                    item {
                        Card(
                            onClick = { onAcceptOffer(activeMission.id.toString()) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.DirectionsBike, null, tint = Color.White, modifier = Modifier.size(32.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("ACTIVE MISSION IN PROGRESS 🚀", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                                    Text("Order #${activeMission.id} • ${activeMission.status?.uppercase()}", color = Color.White.copy(alpha = 0.9f), fontSize = 11.sp)
                                }
                                Button(
                                    onClick = { onAcceptOffer(activeMission.id.toString()) },
                                    colors = ButtonDefaults.buttonColors(containerColor = com.ng.pikop.ui.theme.PikopGold, contentColor = Color.Black)
                                ) {
                                    Text("RESUME", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                if (queuedMission != null) {
                    item {
                        Card(
                            onClick = { onAcceptOffer(queuedMission.id.toString()) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.HourglassTop, null, tint = MaterialTheme.colorScheme.onSecondaryContainer, modifier = Modifier.size(32.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("QUEUED MISSION WAITING ⏳", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer, fontSize = 12.sp)
                                    Text("Order #${queuedMission.id} • Next in Queue", color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.9f), fontSize = 11.sp)
                                }
                                Button(
                                    onClick = { onAcceptOffer(queuedMission.id.toString()) },
                                    colors = ButtonDefaults.buttonColors(containerColor = com.ng.pikop.ui.theme.PikopGold, contentColor = Color.Black)
                                ) {
                                    Text("START", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // 2. Dash Content
                item {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Verified Agent Banner
                        if (kycStatus == "VERIFIED" || profileData?.kyc_status == "VERIFIED") {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 12.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBBF7D0))
                            ) {
                                Row(
                                    modifier = Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.pikop_badge),
                                        contentDescription = "Verified Badge",
                                        modifier = Modifier.size(52.dp)
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            "VERIFIED PIKOP AGENT 🛡️",
                                            fontWeight = FontWeight.ExtraBold,
                                            color = Color(0xFF008751),
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            "KYC & Identity Verified • Ready for Missions",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color(0xFF15803D)
                                        )
                                    }
                                }
                            }
                        }

                        // Peak Hour Bonus Banner
                        val peakActive = profileData?.stats?.peak_active ?: false
                        val peakBonus = profileData?.stats?.peak_bonus ?: 0.0
                        if (peakActive && peakBonus > 0) {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiary)
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Timer, null, tint = MaterialTheme.colorScheme.onTertiary)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text("Peak Bonus Active! 🔥", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onTertiary)
                                        Text("Earn an extra ₦${peakBonus.toInt()} on every delivery.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onTertiary.copy(alpha = 0.9f))
                                    }
                                }
                            }
                        }

                        // Streak Tracker
                        val streak = profileData?.current_streak_days ?: 0
                        if (streak > 0) {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LocalFireDepartment, null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(32.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text("$streak Day Streak", fontWeight = FontWeight.Bold)
                                        val nextMilestone = if (streak < 7) 7 else 30
                                        Text("Keep it up! Next bonus at $nextMilestone days.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f))
                                    }
                                }
                            }
                        }

                        // KYC Card
                        if (kycStatus != "VERIFIED") {
                            val isPending = kycStatus == "PENDING_REVIEW"
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isPending) Color(0xFFFFF3E0) else MaterialTheme.colorScheme.errorContainer
                                ),
                                onClick = onGoToKyc
                            ) {
                                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (isPending) Icons.Default.Pending else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (isPending) Color(0xFFFF9800) else MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(48.dp)
                                    )
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isPending) "Verification Under Review" else "Account Not Verified",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = if (isPending) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.error
                                        )
                                        Text(
                                            text = if (isPending) "We are reviewing your details. This usually takes 24 hours." else "Complete verification to start earning.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (isPending) MaterialTheme.colorScheme.tertiary.copy(alpha = 0.8f) else MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                                        )
                                    }
                                }
                            }
                        }

                        // Wallet Card
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                            onClick = onGoToWallet,
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Withdrawable Balance", style = MaterialTheme.typography.labelSmall)
                                    Text("₦${"%,.2f".format(walletBalance)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                }
                                Row {
                                    TextButton(onClick = onGoToInsights) { Text("Insights", style = MaterialTheme.typography.labelSmall) }
                                    TextButton(onClick = onGoToWallet) { Text("Wallet", style = MaterialTheme.typography.labelSmall) }
                                }
                            }
                        }
                        
                        // Status Toggle
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isOnline) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.error.copy(alpha = 0.1f)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp).fillMaxWidth(), 
                                horizontalArrangement = Arrangement.SpaceBetween, 
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isOnline) "You are Online" else "You are Offline", 
                                    style = MaterialTheme.typography.titleMedium, 
                                    color = if (isOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                )
                                Switch(
                                    checked = isOnline,
                                    onCheckedChange = { checked ->
                                        val targetStatus = if (checked) "ONLINE" else "OFFLINE"
                                        coroutineScope.launch {
                                            isStatusLoading = true
                                            try {
                                                var state: String? = null
                                                if (checked) {
                                                    try {
                                                        val loc = fusedLocationClient.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null).await()
                                                        state = withContext(kotlinx.coroutines.Dispatchers.IO) {
                                                            try { Geocoder(context, Locale.getDefault()).getFromLocation(loc?.latitude ?: 0.0, loc?.longitude ?: 0.0, 1)?.firstOrNull()?.adminArea } catch (e: Exception) { null }
                                                        }
                                                    } catch (e: SecurityException) {}
                                                }
                                                apiService.updateStatus(FulfillerStatusRequest(online_status = targetStatus, current_state = state))
                                                isOnline = checked
                                            } catch (e: Exception) {
                                                Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_LONG).show()
                                            } finally { isStatusLoading = false }
                                        }
                                    },
                                    enabled = !isStatusLoading && kycStatus == "VERIFIED"
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(24.dp))
                        Text(text = "Available Offers", style = MaterialTheme.typography.titleLarge)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }

                // 3. Offers List
                if (isOnline) {
                    if (offers.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("Searching for nearby orders...", color = Color.Gray)
                            }
                        }
                    } else {
                        items(offers) { offer ->
                            Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
                                IncomingOfferComponent(
                                    offer = offer,
                                    onAccept = {
                                        coroutineScope.launch {
                                            try {
                                                isLoading = true
                                                val response = apiService.acceptOrder(offer.id ?: "", emptyMap())
                                                val claimedStatus = response.status ?: response.data?.status
                                                val isSuccess = claimedStatus == "MATCHED" || claimedStatus == "QUEUED" || 
                                                                response.message?.contains("Accepted", ignoreCase = true) == true || 
                                                                response.message?.contains("Claimed", ignoreCase = true) == true
                                                
                                                if (isSuccess) {
                                                    Toast.makeText(context, "Mission Accepted!", Toast.LENGTH_SHORT).show()
                                                    onAcceptOffer(offer.id ?: "")
                                                } else {
                                                    fetchDashboardData()
                                                }
                                            } catch (e: Exception) {
                                                Toast.makeText(context, ErrorUtils.parseError(e), Toast.LENGTH_LONG).show()
                                            } finally {
                                                isLoading = false
                                            }
                                        }
                                    },
                                    onDecline = {
                                        fetchDashboardData()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
