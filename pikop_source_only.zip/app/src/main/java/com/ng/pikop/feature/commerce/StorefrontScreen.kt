package com.ng.pikop.feature.commerce

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import android.widget.Toast
import com.ng.pikop.core.datastore.TokenManager
import com.ng.pikop.core.network.ApiService
import com.ng.pikop.core.network.DiscoveryItem
import com.ng.pikop.core.network.ErrorUtils
import com.ng.pikop.core.network.JoinWaitlistRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StorefrontScreen(
    onItemClick: (DiscoveryItem) -> Unit,
    onViewCart: () -> Unit = {}
) {
    val context = LocalContext.current
    val tokenManager = remember { TokenManager(context) }
    val apiService = remember { ApiService.create(tokenManager) }
    val scope = rememberCoroutineScope()
    val fusedLocationClient = remember { LocationServices.getFusedLocationProviderClient(context) }

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var items by remember { mutableStateOf<List<DiscoveryItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var isRefreshing by remember { mutableStateOf(false) }
    var currentCity by remember { mutableStateOf("Port Harcourt") }
    var isCityLive by remember { mutableStateOf(true) }
    var showWaitlistDialog by remember { mutableStateOf(false) }

    val categories = listOf("All", "Food", "Groceries", "Electronics", "Pharmacy", "Fashion", "Beauty")

    suspend fun fetchDiscovery() {
        try {
            val location = try {
                fusedLocationClient.getCurrentLocation(Priority.PRIORITY_BALANCED_POWER_ACCURACY, null).await()
            } catch (e: SecurityException) { null }

            val response = apiService.getDiscovery(
                lat = location?.latitude,
                lng = location?.longitude,
                category = if (selectedCategory == "All") null else selectedCategory,
                query = if (searchQuery.isBlank()) null else searchQuery
            )
            items = response.data
            
            // Resolve City from location if possible for Header
            if (location != null) {
                try {
                    val geocoder = android.location.Geocoder(context, java.util.Locale.getDefault())
                    val city = geocoder.getFromLocation(location.latitude, location.longitude, 1)?.firstOrNull()?.locality
                    if (city != null) {
                        currentCity = city
                        val rules = apiService.getCityRules(city)
                        isCityLive = rules["is_live"] as? Boolean ?: false
                    }
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            android.util.Log.e("Storefront", "Fetch error", e)
        } finally {
            isLoading = false
            isRefreshing = false
        }
    }

    LaunchedEffect(selectedCategory, searchQuery) {
        isLoading = true
        fetchDiscovery()
    }

    Scaffold(
        floatingActionButton = {
            if (com.ng.pikop.core.cart.CartManager.items.isNotEmpty()) {
                FloatingActionButton(
                    onClick = onViewCart,
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    BadgedBox(
                        badge = { Badge { Text("${com.ng.pikop.core.cart.CartManager.items.size}") } }
                    ) {
                        Icon(Icons.Default.ShoppingCart, "View Cart")
                    }
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxSize().background(MaterialTheme.colorScheme.background)) {
            // Search Header
            Surface(
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        if (isCityLive) "Discover $currentCity" else "Coming Soon to $currentCity",
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Search products, meals, or shops") },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent
                        ),
                        singleLine = true
                    )
                }
            }

            // Category Horizontal Scroll
            LazyRow(
                modifier = Modifier.padding(vertical = 12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { category ->
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        label = { Text(category) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            // Discovery Grid
            if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (items.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                        if (!isCityLive) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = com.ng.pikop.ui.theme.PikopGold.copy(alpha = 0.1f)),
                                border = androidx.compose.foundation.BorderStroke(1.dp, com.ng.pikop.ui.theme.PikopGold)
                            ) {
                                Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.Celebration, null, modifier = Modifier.size(48.dp), tint = com.ng.pikop.ui.theme.PikopGold)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text("Pikop is arriving soon in $currentCity!", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                    Text("We're currently setting up our local merchant network. Want to be the first to know?", style = MaterialTheme.typography.bodySmall, textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = Color.Gray, modifier = Modifier.padding(vertical = 8.dp))
                                    Button(
                                        onClick = { showWaitlistDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = com.ng.pikop.ui.theme.PikopGold, contentColor = Color.Black)
                                    ) {
                                        Text("NOTIFY ME", fontWeight = FontWeight.ExtraBold)
                                    }
                                }
                            }
                        } else {
                            Icon(Icons.Default.Storefront, null, modifier = Modifier.size(64.dp), tint = Color.LightGray)
                            Text("No items found nearby.", color = Color.Gray)
                        }
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(items) { item ->
                        DiscoveryItemCard(
                            item = item, 
                            onClick = { onItemClick(item) },
                            onCartError = {
                                // Handled via state or toast
                                Toast.makeText(context, "You can only add items from one store at a time. Clear your cart to switch.", Toast.LENGTH_LONG).show()
                            }
                        )
                    }
                }
            }
        }
    }

    if (showWaitlistDialog) {
        WaitlistDialog(
            cityName = currentCity,
            onDismiss = { showWaitlistDialog = false },
            onConfirm = { email ->
                scope.launch {
                    try {
                        apiService.joinWaitlist(JoinWaitlistRequest(city_name = currentCity, email = email))
                        Toast.makeText(context, "Added to Waitlist!", Toast.LENGTH_SHORT).show()
                    } catch (_: Exception) {}
                    showWaitlistDialog = false
                }
            }
        )
    }
}

@Composable
fun WaitlistDialog(cityName: String, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var email by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Join $cityName Waitlist") },
        text = {
            Column {
                Text("Enter your email and we'll send you an invitation when we go live in your area.", style = MaterialTheme.typography.bodySmall)
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Address") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(email) }, enabled = email.contains("@")) { Text("Join Waitlist") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun DiscoveryItemCard(item: DiscoveryItem, onClick: () -> Unit, onCartError: () -> Unit = {}) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(enabled = item.is_open) { onClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box {
                AsyncImage(
                    model = if (item.photo_url.isNullOrBlank()) {
                        "https://placehold.co/400x300?text=Pikop"
                    } else if (item.photo_url.startsWith("http")) {
                        item.photo_url
                    } else {
                        "https://api.pikop.com.ng${item.photo_url}"
                    },
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth().height(120.dp),
                    contentScale = ContentScale.Crop
                )
                if (item.item_type == "meal") {
                    Surface(
                        color = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.padding(8.dp).align(Alignment.TopStart),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("MEAL", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                if (!item.is_open) {
                    Box(
                        modifier = Modifier.fillMaxWidth().height(120.dp).background(Color.Black.copy(alpha = 0.5f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Surface(
                            color = Color.Black.copy(alpha = 0.8f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "CLOSED",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
            Column(modifier = Modifier.padding(12.dp)) {
                val textColor = if (item.is_open) Color.Unspecified else Color.Gray
                Text(
                    text = item.name,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.Bold,
                    color = textColor
                )
                Text(
                    text = if (item.is_open) item.vendor_name else "Opens at ${item.next_open_time ?: "--:--"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.Gray,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "₦${"%,.0f".format(item.price)}",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.ExtraBold
                    )
                    
                    if (item.is_open) {
                        Surface(
                            onClick = { 
                                val success = com.ng.pikop.core.cart.CartManager.addItem(item)
                                if (!success) onCartError()
                            },
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                            shape = CircleShape,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Add, null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    } else if (item.distance_km != null) {
                        Text(
                            text = "${"%.1f".format(item.distance_km)}km",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray
                        )
                    }
                }
            }
        }
    }
}
