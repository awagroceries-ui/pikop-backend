const db = require('../config/db');
const bcrypt = require('bcryptjs');
const emailService = require('../services/emailService');

const walletService = require('../services/walletService');
const paystackService = require('../services/paystackService');

/**
 * Handles admin login.
 */
const login = async (req, res) => {
  const { username, password } = req.body;
  try {
    const { rows } = await db.query('SELECT * FROM admin_users WHERE username = $1', [username]);

    if (rows.length === 0) {
        console.warn(`[Admin] Login Fail: User '${username}' not found in DB.`);
        return res.render('login', { error: 'Access Denied: User not found', layout: false });
    }

    const admin = rows[0];
    const match = await bcrypt.compare(password, admin.password_hash);

    console.log(`[Admin] Login attempt for user='${username}' - Result: ${match ? 'SUCCESS' : 'FAIL'}`);

    if (!match) return res.render('login', { error: 'Invalid credentials', layout: false });

    req.session.adminId = admin.id;
    req.session.adminRole = admin.role;
    req.session.adminUsername = admin.username;

    res.redirect('/admin/dashboard');
  } catch (error) {
    console.error('[Admin] Login Error:', error.message);
    res.render('login', { error: `Server error: ${error.message}`, layout: false });
  }
};

/**
 * Safe First Signup: Only works if no admins exist.
 */
const getSignup = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT COUNT(*) FROM admin_users");
        if (parseInt(rows[0].count) > 0) {
            return res.redirect('/admin/login');
        }
        res.render('signup', { layout: false });
    } catch (error) {
        res.status(500).send('Setup Check Failed');
    }
};

const postSignup = async (req, res) => {
    const { username, password } = req.body;
    try {
        const { rows } = await db.query("SELECT COUNT(*) FROM admin_users");
        if (parseInt(rows[0].count) > 0) {
            return res.status(403).send('System already initialized');
        }

        const passwordHash = await bcrypt.hash(password, 10);
        await db.query(
            "INSERT INTO admin_users (username, password_hash, role) VALUES ($1, $2, 'super_admin')",
            [username, passwordHash]
        );

        res.redirect('/admin/login');
    } catch (error) {
        res.status(500).send(`Signup Failed: ${error.message}`);
    }
};

/**
 * Renders the main dashboard with metrics.
 */
const getDashboard = async (req, res) => {
  try {
    const [ordersRes, usersRes, fleetRes] = await Promise.all([
      db.query(`
        SELECT
            COUNT(*) FILTER (WHERE status NOT IN ('DELIVERED', 'CANCELLED')) as active_count,
            SUM(total_fare) FILTER (WHERE payment_status = 'PAID' AND created_at >= NOW() - INTERVAL '24 hours') as revenue_24h
        FROM orders
      `),
      db.query(`
        SELECT
            COUNT(*) as total,
            COUNT(*) FILTER (WHERE role = 'CUSTOMER') as customers,
            COUNT(*) FILTER (WHERE role = 'FULFILLER') as fulfillers
        FROM users
      `),
      db.query(`
        SELECT
            (SELECT COUNT(*) FROM fulfillers WHERE online_status = 'ONLINE')::int as online_count,
            (SELECT COUNT(*) FROM fulfillers WHERE kyc_status = 'PENDING_REVIEW')::int as pending_kyc,
            (SELECT COUNT(*) FROM conversations WHERE status = 'OPEN')::int as open_support
      `)
    ]);

    const o = ordersRes.rows[0];
    const u = usersRes.rows[0];
    const f = fleetRes.rows[0];

    res.render('dashboard', {
      stats: {
        activeOrders: parseInt(o.active_count || 0),
        onlineFulfillers: parseInt(f.online_count || 0),
        totalRevenue: parseFloat(o.revenue_24h || 0),
        totalUsers: parseInt(u.total || 0),
        customerUsers: parseInt(u.customers || 0),
        fulfillerUsers: parseInt(u.fulfillers || 0),
        notifications: {
          kyc: parseInt(f.pending_kyc || 0),
          support: parseInt(f.open_support || 0),
          disputes: 0
        }
      }
    });
  } catch (error) {
    console.error('[Admin] Dashboard Error:', error.message);
    res.status(500).render('error', { message: error.message });
  }
};

/**
 * List all orders with filters.
 */
const getOrders = async (req, res) => {
    const { type, status } = req.query;
    try {
        let query = `
            SELECT o.*, u.full_name as user_name, f.full_name as fulfiller_name
            FROM orders o
            JOIN users u ON u.id = o.user_id
            LEFT JOIN fulfillers f ON f.id = o.fulfiller_id
            WHERE 1=1
        `;
        const params = [];
        if (type === 'COD') {
            query += " AND o.item_price > 0";
        }
        if (status) {
            params.push(status);
            query += ` AND o.status = $${params.length}`;
        }

        query += " ORDER BY o.created_at DESC LIMIT 100";

        const { rows } = await db.query(query, params);
        res.render('orders', { orders: rows, filters: { type, status } });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Live Mission Tracking for Admin.
 */
const trackOrder = async (req, res) => {
    const { id } = req.params;
    try {
        const { rows } = await db.query(`
            SELECT o.*,
            ST_Y(o.pickup_location::geometry) as pickup_lat, ST_X(o.pickup_location::geometry) as pickup_lng,
            ST_Y(o.delivery_location::geometry) as delivery_lat, ST_X(o.delivery_location::geometry) as delivery_lng,
            u.full_name as customer_name, u.phone as customer_phone,
            f.id as agent_db_id, f.full_name as agent_name, f.phone as agent_phone, f.kyc_status, f.primary_class, f.tier,
            ST_Y(f.current_location::geometry) as agent_lat, ST_X(f.current_location::geometry) as agent_lng
            FROM orders o
            JOIN users u ON u.id = o.user_id
            LEFT JOIN fulfillers f ON f.id = o.fulfiller_id
            WHERE o.id = $1`, [id]);

        if (rows.length === 0) return res.status(404).render('error', { message: 'Mission not found' });

        // Fetch Ledger for this order
        const ledger = await db.query(
            "SELECT l.*, w.owner_type FROM wallet_ledger_entries l JOIN wallets w ON w.id = l.wallet_id WHERE l.order_id = $1 ORDER BY l.created_at ASC",
            [id]
        );

        res.render('admin_track', { order: rows[0], ledger: ledger.rows });
    } catch (error) {
        res.status(500).render('error', { message: error.message });
    }
};

/**
 * Platform Settings (Master Brief Milestone 23)
 */
const getSettings = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT key, value FROM settings");
        const settingsMap = {};
        rows.forEach(r => settingsMap[r.key] = r.value);
        res.render('settings', { settings: settingsMap });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const updateSettings = async (req, res) => {
    const {
        base_fare_small, base_fare_medium, base_fare_large,
        per_km_rate, platform_commission, cod_fee_rate,
        food_commission, groceries_commission, shop_commission,
        guest_sms_charge,
        insurance_rate, insurance_min_item_value,
        max_surge_multiplier, manual_surge_multiplier,
        streak_bonus_7_day, streak_bonus_30_day,
        peak_hour_start, peak_hour_end, peak_hour_bonus
    } = req.body;

    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');

        const settings = [
            ['base_fare_small', base_fare_small],
            ['base_fare_medium', base_fare_medium],
            ['base_fare_large', base_fare_large],
            ['per_km_rate', per_km_rate],
            ['platform_commission', platform_commission],
            ['cod_fee_rate', cod_fee_rate],
            ['food_commission', food_commission],
            ['groceries_commission', groceries_commission],
            ['shop_commission', shop_commission],
            ['guest_sms_charge', guest_sms_charge],
            ['insurance_rate', insurance_rate],
            ['insurance_min_item_value', insurance_min_item_value],
            ['max_surge_multiplier', max_surge_multiplier],
            ['manual_surge_multiplier', manual_surge_multiplier],
            ['streak_bonus_7_day', streak_bonus_7_day],
            ['streak_bonus_30_day', streak_bonus_30_day],
            ['peak_hour_start', peak_hour_start],
            ['peak_hour_end', peak_hour_end],
            ['peak_hour_bonus', peak_hour_bonus]
        ];

        for (const [key, val] of settings) {
            if (val !== undefined && val !== '') {
                await client.query(
                    "INSERT INTO settings (key, value) VALUES ($1, $2) ON CONFLICT (key) DO UPDATE SET value = $2",
                    [key, val.toString()]
                );
            }
        }

        // Audit the change
        await client.query(
            "INSERT INTO audit_logs (admin_id, action, target_type, payload) VALUES ($1, $2, $3, $4)",
            [req.session.adminId, 'UPDATE_SETTINGS', 'system', JSON.stringify(req.body)]
        );

        await client.query('COMMIT');
        res.redirect('/admin/settings');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('[Admin] Settings update failed:', error.message);
        res.status(400).send(`Update Failed: ${error.message}`);
    } finally {
        client.release();
    }
};

/**
 * Support Inbox (V3 Real-time Ready)
 */
const getSupportInbox = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT c.*, u.full_name as participant_name,
            (SELECT COUNT(*) FROM messages WHERE conversation_id = c.id AND is_read = false AND sender_type != 'ADMIN') as unread_count
            FROM conversations c
            JOIN users u ON u.id = c.participant_id
            WHERE c.status = 'OPEN'
            ORDER BY c.last_message_at DESC
        `);
        res.render('support_inbox', { conversations: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const getConversationDetails = async (req, res) => {
    const { id } = req.params;
    try {
        const convRes = await db.query(`
            SELECT c.*, u.full_name as participant_name
            FROM conversations c
            JOIN users u ON u.id = c.participant_id
            WHERE c.id = $1`, [id]);

        if (convRes.rows.length === 0) return res.status(404).send('Not found');

        const messages = await db.query("SELECT * FROM messages WHERE conversation_id = $1 ORDER BY created_at ASC", [id]);

        res.render('support_detail', {
            conversation: convRes.rows[0],
            messages: messages.rows,
            adminId: req.session.adminId
        });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const getKYCQueue = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT f.*, u.full_name, u.email
            FROM fulfillers f
            JOIN users u ON u.id = f.user_id
            WHERE f.kyc_status != 'VERIFIED'
            ORDER BY f.created_at DESC
        `);
        res.render('kyc_queue', {
            fulfillers: rows,
            baseUrl: process.env.BASE_URL || 'https://api.pikop.com.ng'
        });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const getKYCReview = async (req, res) => {
    const { id } = req.params;
    try {
        const fRes = await db.query(`
            SELECT f.*, u.full_name, u.email, u.phone as user_phone
            FROM fulfillers f
            JOIN users u ON u.id = f.user_id
            WHERE f.id = $1`, [id]);

        if (fRes.rows.length === 0) return res.status(404).send('Fulfiller not found');

        const f = fRes.rows[0];

        // Ensure kyc_details is parsed if stringified
        if (f.kyc_details && typeof f.kyc_details === 'string') {
            try { f.kyc_details = JSON.parse(f.kyc_details); } catch (e) {}
        }

        const docs = await db.query("SELECT * FROM kyc_documents WHERE fulfiller_id = $1", [id]);

        res.render('kyc_review', {
            f,
            docs: docs.rows,
            baseUrl: process.env.BASE_URL || 'https://api.pikop.com.ng'
        });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Lists crowdsourced landmark suggestions.
 */
const getLandmarks = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT * FROM landmark_suggestions ORDER BY submission_count DESC, created_at DESC LIMIT 100");
        res.render('landmarks', { landmarks: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * List all traffic corridors.
 */
const getTrafficCorridors = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT * FROM traffic_corridors ORDER BY created_at DESC");
        const { rows: zones } = await db.query("SELECT id, name FROM zones ORDER BY name ASC");
        res.render('traffic_corridors', { corridors: rows, zones });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Creates a new traffic corridor.
 */
const addTrafficCorridor = async (req, res) => {
    const { name, pickup_zone_id, delivery_zone_id, multiplier, day_of_week, start_time, end_time } = req.body;
    try {
        const window = [{ day_of_week, start_time, end_time, multiplier }];
        await db.query(
            `INSERT INTO traffic_corridors (name, pickup_zone_id, delivery_zone_id, time_windows)
             VALUES ($1, $2, $3, $4)`,
            [name, pickup_zone_id, delivery_zone_id, JSON.stringify(window)]
        );
        res.redirect('/admin/traffic');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const updateKYCStatus = async (req, res) => {
    const { id } = req.params;
    const { status, note } = req.body; // status: VERIFIED, REJECTED
    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');
        const newStatus = status === 'VERIFIED' ? 'active' : 'suspended';

        // Use explicit parameter indices to avoid type deduction ambiguity in Postgres
        await client.query(
            "UPDATE fulfillers SET kyc_status = $1, status = $2, approved_at = CASE WHEN $3 = 'VERIFIED' THEN CURRENT_TIMESTAMP ELSE approved_at END WHERE id = $4",
            [status, newStatus, status, id]
        );

        // Audit log
        await client.query(
            "INSERT INTO audit_logs (admin_id, action, target_type, target_id, payload) VALUES ($1, $2, $3, $4, $5)",
            [req.session.adminId, 'UPDATE_KYC', 'fulfiller', id, JSON.stringify({ status, note })]
        );

        await client.query('COMMIT');

        // Fetch user email to send KYC status notification (Out of transaction)
        try {
            const { rows: fUser } = await db.query(
                "SELECT u.email, u.full_name, f.primary_class FROM fulfillers f JOIN users u ON u.id = f.user_id WHERE f.id = $1",
                [id]
            );
            if (fUser.length > 0) {
                if (status === 'VERIFIED') {
                    // Send Customized Welcome Email for Fulfiller
                    await emailService.sendWelcomeEmail(fUser[0].email, fUser[0].full_name, 'FULFILLER', {
                        category: fUser[0].primary_class
                    });
                } else {
                    // Send Rejection Email
                    emailService.sendKycStatusEmail(fUser[0].email, fUser[0].full_name, status, note)
                        .catch(e => console.error('[KycEmail] Error:', e.message));
                }
            }
        } catch (e) {}

        res.redirect('/admin/kyc');
    } catch (error) {
        await client.query('ROLLBACK');
        res.status(500).send(error.message);
    } finally {
        client.release();
    }
};

/**
 * Updates Merchant Business Verification Status.
 */
const updateMerchantKYCStatus = async (req, res) => {
    const type = req.params.type || req.body.type;
    const id = req.params.id || req.body.id;
    const { status, note } = req.body; // status: VERIFIED, REJECTED
    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');
        const table = type === 'kitchen' ? 'kitchens' : 'vendors';
        const newStatus = status === 'VERIFIED' ? 'active' : 'suspended';

        await client.query(
            `UPDATE ${table} SET status = $1, approved_at = CASE WHEN $2 = 'VERIFIED' THEN CURRENT_TIMESTAMP ELSE approved_at END WHERE id = $3`,
            [newStatus, status, id]
        );

          // Role Upgrade: Ensure user role is updated to MERCHANT on approval, preserving higher privileges
          if (status === 'VERIFIED') {
              const { rows: mRes } = await client.query(`SELECT user_id FROM ${table} WHERE id = $1`, [id]);
              if (mRes.length > 0) {
                  const { rows: uRes } = await client.query("SELECT role FROM users WHERE id = $1", [mRes[0].user_id]);
                  const currentRole = uRes[0]?.role;

                  // Only upgrade if currently a CUSTOMER or unassigned.
                  // If they are FULFILLER or CORPORATE, they keep that role but gain merchant capabilities (v4.5 Hardening)
                  if (currentRole === 'CUSTOMER') {
                      await client.query("UPDATE users SET role = 'MERCHANT' WHERE id = $1", [mRes[0].user_id]);
                      console.log(`[Admin] Role upgraded to MERCHANT for user ${mRes[0].user_id}`);
                  } else {
                      console.log(`[Admin] User ${mRes[0].user_id} is already ${currentRole}. Merchant capabilities unlocked without role overwrite.`);
                  }
              }
          }

        // Audit log
        await client.query(
            "INSERT INTO audit_logs (admin_id, action, target_type, target_id, payload) VALUES ($1, $2, $3, $4, $5)",
            [req.session.adminId, 'UPDATE_MERCHANT_KYC', type, id, JSON.stringify({ status, note })]
        );

        await client.query('COMMIT');

        // Fetch merchant/user info for welcome email (Out of transaction)
        try {
            const { rows: mUser } = await db.query(
                `SELECT u.email, u.full_name, m.category, m.accepts_cod
                 FROM ${table} m JOIN users u ON u.id = m.user_id WHERE m.id = $1`,
                [id]
            );
            if (mUser.length > 0 && status === 'VERIFIED') {
                await emailService.sendWelcomeEmail(mUser[0].email, mUser[0].full_name, 'MERCHANT', {
                    category: mUser[0].category,
                    accepts_cod: mUser[0].accepts_cod
                });
            }
        } catch (e) {
            console.error('[MerchantWelcomeEmail] Error:', e.message);
        }

        res.redirect(`/admin/${type}s`);
    } catch (error) {
        await client.query('ROLLBACK');
        res.status(500).send(error.message);
    } finally {
        client.release();
    }
};

/**
 * Business Entity Management
 */
const getVendors = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT v.*, u.full_name as contact_person, u.email as contact_email
            FROM vendors v
            JOIN users u ON u.id = v.user_id
            ORDER BY v.created_at DESC
        `);
        res.render('vendors', { vendors: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const getKitchens = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT k.*, u.full_name as contact_person, u.email as contact_email
            FROM kitchens k
            JOIN users u ON u.id = k.user_id
            ORDER BY k.created_at DESC
        `);
        res.render('kitchens', { kitchens: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Unified Merchant Management View.
 */
const getMerchants = async (req, res) => {
    try {
        const { rows } = await db.query(`
            (SELECT id, business_name, status, category, accepts_cod, created_at, 'vendor' as type FROM vendors)
            UNION ALL
            (SELECT id, business_name, status, category, accepts_cod, created_at, 'kitchen' as type FROM kitchens)
            ORDER BY created_at DESC
        `);
        res.render('merchants', { merchants: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Store Contents & Regulation Management (v4.8)
 */
const getMerchantStoreItems = async (req, res) => {
    const { type, id } = req.params;
    try {
        let merchant = null;
        let items = [];

        if (type === 'vendor') {
            const mRes = await db.query(`
                SELECT v.*, u.full_name as contact_person, u.email as contact_email
                FROM vendors v
                JOIN users u ON u.id = v.user_id
                WHERE v.id = $1
            `, [id]);
            if (mRes.rows.length === 0) return res.status(404).send('Vendor store not found');
            merchant = mRes.rows[0];

            const pRes = await db.query('SELECT * FROM products WHERE vendor_id = $1 ORDER BY created_at DESC', [id]);
            items = pRes.rows;
        } else {
            const mRes = await db.query(`
                SELECT k.*, u.full_name as contact_person, u.email as contact_email
                FROM kitchens k
                JOIN users u ON u.id = k.user_id
                WHERE k.id = $1
            `, [id]);
            if (mRes.rows.length === 0) return res.status(404).send('Kitchen store not found');
            merchant = mRes.rows[0];

            const mItemsRes = await db.query('SELECT * FROM menu_items WHERE kitchen_id = $1 ORDER BY created_at DESC', [id]);
            items = mItemsRes.rows;
        }

        res.render('merchant_store_items', { merchant, items, type });
    } catch (error) {
        console.error('[AdminStoreItems] Error:', error.message);
        res.status(500).send(error.message);
    }
};

const toggleMerchantItemStatus = async (req, res) => {
    const { type, id, itemId } = req.params;
    try {
        if (type === 'vendor') {
            await db.query('UPDATE products SET active = NOT active WHERE id = $1 AND vendor_id = $2', [itemId, id]);
        } else {
            await db.query('UPDATE menu_items SET available = NOT available WHERE id = $1 AND kitchen_id = $2', [itemId, id]);
        }
        res.redirect(`/admin/merchants/${type}/${id}/items`);
    } catch (error) {
        console.error('[AdminToggleItem] Error:', error.message);
        res.status(500).send(error.message);
    }
};

const updateMerchantItem = async (req, res) => {
    const { type, id, itemId } = req.params;
    const { name, price, category, description } = req.body;
    try {
        const numPrice = parseFloat(price) || 0;
        if (type === 'vendor') {
            await db.query(
                `UPDATE products SET name = $1, price = $2, category = $3, description = $4 WHERE id = $5 AND vendor_id = $6`,
                [name, numPrice, category || null, description || null, itemId, id]
            );
        } else {
            await db.query(
                `UPDATE menu_items SET name = $1, price = $2, category = $3, description = $4 WHERE id = $5 AND kitchen_id = $6`,
                [name, numPrice, category || null, description || null, itemId, id]
            );
        }
        res.redirect(`/admin/merchants/${type}/${id}/items`);
    } catch (error) {
        console.error('[AdminUpdateItem] Error:', error.message);
        res.status(500).send(error.message);
    }
};

const deleteMerchantItem = async (req, res) => {
    const { type, id, itemId } = req.params;
    try {
        if (type === 'vendor') {
            await db.query('DELETE FROM products WHERE id = $1 AND vendor_id = $2', [itemId, id]);
        } else {
            await db.query('DELETE FROM menu_items WHERE id = $1 AND kitchen_id = $2', [itemId, id]);
        }
        res.redirect(`/admin/merchants/${type}/${id}/items`);
    } catch (error) {
        console.error('[AdminDeleteItem] Error:', error.message);
        res.status(500).send(error.message);
    }
};

/**
 * Fleet Partner Management (v4.1)
 */
const getFleetPartners = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT * FROM fleet_partners ORDER BY created_at DESC");
        res.render('fleet_partners', { partners: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const updateFleetPartnerStatus = async (req, res) => {
    const { id } = req.params;
    const { status, commission_override, has_overflow_priority } = req.body;

    try {
        await db.query(
            `UPDATE fleet_partners
             SET status = COALESCE($1, status),
                 commission_override = COALESCE($2, commission_override),
                 has_overflow_priority = COALESCE($3, has_overflow_priority)
             WHERE id = $4`,
            [status, commission_override, has_overflow_priority, id]
        );
        res.redirect('/admin/fleet-partners');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Lists all admin users.
 */
const getAdminUsers = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT id, username, role, created_at FROM admin_users ORDER BY role ASC");
        res.render('admin_users', { users: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const addAdmin = async (req, res) => {
    const { username, password, role } = req.body;
    try {
        const passwordHash = await bcrypt.hash(password, 10);
        await db.query(
            "INSERT INTO admin_users (username, password_hash, role) VALUES ($1, $2, $3)",
            [username, passwordHash, role]
        );
        res.redirect('/admin/users');
    } catch (error) {
        res.status(500).send(`Failed to add admin: ${error.message}`);
    }
};

const deleteAdmin = async (req, res) => {
    const { id } = req.params;
    try {
        if (parseInt(id) === req.session.adminId) {
            return res.status(400).send('Self-deletion prohibited');
        }
        await db.query("DELETE FROM admin_users WHERE id = $1", [id]);
        res.redirect('/admin/users');
    } catch (error) {
        res.status(500).send('Deletion failed');
    }
};

/**
 * Returns currently logged in admin profile.
 */
const getProfile = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT * FROM admin_users WHERE id = $1", [req.session.adminId]);
        res.render('admin_profile', { user: rows[0] });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Coupon Management (v3 Growth Engine)
 */
const getCoupons = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT * FROM coupons ORDER BY created_at DESC");
        res.render('coupons_admin', { coupons: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const createCoupon = async (req, res) => {
    const { code, discount_type, discount_value, min_order_amount, usage_limit, applicability_scope } = req.body;
    try {
        await db.query(
            `INSERT INTO coupons (code, discount_type, discount_value, min_order_amount, usage_limit, applicability_scope, is_active)
             VALUES ($1, $2, $3, $4, $5, $6, true)`,
            [code.toUpperCase().trim(), discount_type, discount_value, min_order_amount || 0, usage_limit || 100, applicability_scope || 'DELIVERY_ONLY']
        );
        res.redirect('/admin/coupons');
    } catch (error) {
        res.status(500).send(`Failed to create coupon: ${error.message}`);
    }
};

const deleteCoupon = async (req, res) => {
    const { id } = req.params;
    try {
        await db.query("DELETE FROM coupons WHERE id = $1", [id]);
        res.redirect('/admin/coupons');
    } catch (error) {
        res.status(500).send('Deletion failed');
    }
};

/**
 * Lists all active disputes.
 */
const getDisputes = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT d.*, o.item_description, o.item_price, o.total_fare,
                   u.full_name as reporter_name, f.full_name as fulfiller_name
            FROM disputes d
            JOIN orders o ON o.id = d.order_id
            JOIN users u ON u.id = d.reporter_id
            LEFT JOIN fulfillers f ON f.id = o.fulfiller_id
            WHERE d.status IN ('OPEN', 'INVESTIGATING')
            ORDER BY d.created_at DESC
        `);
        res.render('disputes', { disputes: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Resolves a dispute with either 'REFUND' or 'RELEASE'.
 */
/**
 * Unified Dispute & Incident Resolution Center (Milestone 35).
 */
const getDisputeResolutionCenter = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT d.*, o.item_description, o.item_price, o.total_fare, o.status as order_status,
                   o.is_insured,
                   u.full_name as reporter_name, u.role as reporter_role,
                   f.full_name as fulfiller_name
            FROM disputes d
            JOIN orders o ON o.id = d.order_id
            JOIN users u ON u.id = d.reporter_id
            LEFT JOIN fulfillers f ON f.id = o.fulfiller_id
            WHERE d.status IN ('OPEN', 'INVESTIGATING')
            ORDER BY
              CASE WHEN d.severity = 'HIGH' THEN 1 WHEN d.severity = 'MEDIUM' THEN 2 ELSE 3 END,
              d.created_at DESC
        `);
        res.render('dispute_resolution', { disputes: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Resolves a dispute with structured actions (REFUND, RELEASE, WAIVER).
 */
const resolveDispute = async (req, res) => {
    const { id } = req.params;
    const { action, resolution_notes, waiver_type } = req.body;
    const adminId = req.session.adminId;

    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');

        const { rows } = await client.query("SELECT * FROM disputes WHERE id = $1 FOR UPDATE", [id]);
        if (rows.length === 0) throw new Error('Dispute not found');
        const dispute = rows[0];

        // 1. Core Financial Actions
        if (action === 'REFUND') {
            await walletService.refundEscrow(dispute.order_id, client);
        } else if (action === 'RELEASE') {
            await walletService.releaseEscrow(dispute.order_id, client);
        } else if (action === 'WAIVER' && waiver_type) {
            await walletService.applyAutomatedWaiver(dispute.order_id, waiver_type, client);
        } else if (action === 'INSURANCE_CLAIM') {
            const { rows: oRes } = await client.query("SELECT item_price, is_insured FROM orders WHERE id = $1", [dispute.order_id]);
            if (oRes.rows[0]?.is_insured) {
                await walletService.processInsuranceClaim(dispute.order_id, parseFloat(oRes.rows[0].item_price), client);
            } else {
                throw new Error('Order is not insured.');
            }
        }

        // 2. Update Dispute Status
        await client.query(
            "UPDATE disputes SET status = 'RESOLVED', resolution_notes = $1, assigned_admin_id = $2 WHERE id = $3",
            [resolution_notes, adminId, id]
        );

        // 3. Audit Log
        await client.query(
            "INSERT INTO audit_logs (admin_id, action, target_type, target_id, payload) VALUES ($1, $2, $3, $4, $5)",
            [adminId, `RESOLVE_DISPUTE_${action}`, 'dispute', id, JSON.stringify({ resolution_notes, action, waiver_type })]
        );

        await client.query('COMMIT');
        res.redirect('/admin/disputes');
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('[Admin] Resolution center error:', error.message);
        res.status(500).send(`Resolution failed: ${error.message}`);
    } finally {
        client.release();
    }
};

/**
 * Lists all pending withdrawals.
 */
const getWithdrawals = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT w.*, f.full_name as fulfiller_name, f.bank_name, f.account_number, f.paystack_recipient_code
            FROM withdrawals w
            JOIN fulfillers f ON f.id = w.fulfiller_id
            WHERE w.status = 'PENDING'
            ORDER BY w.requested_at DESC
        `);
        res.render('withdrawals', { withdrawals: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Approves a withdrawal and initiates Paystack Transfer.
 */
const approveWithdrawal = async (req, res) => {
    const { id } = req.params;
    const adminId = req.session.adminId;

    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');

        // 1. Lock withdrawal record
        const { rows } = await client.query(
            `SELECT w.*, f.full_name, f.account_number, f.bank_code, f.paystack_recipient_code, f.account_name
             FROM withdrawals w
             JOIN fulfillers f ON f.id = w.fulfiller_id
             WHERE w.id = $1 FOR UPDATE`,
            [id]
        );

        if (rows.length === 0) throw new Error('Withdrawal not found');
        const w = rows[0];

        if (w.status !== 'PENDING') throw new Error('Withdrawal already processed');

        // 2. Ensure Paystack Recipient exists
        let recipientCode = w.paystack_recipient_code;
        if (!recipientCode) {
            if (!w.account_number || !w.bank_code) throw new Error('Fulfiller bank details missing');

            // Use Account Name from DB if available, fallback to full_name
            const recipientName = w.account_name || w.full_name;
            const recipientRes = await paystackService.createTransferRecipient(recipientName, w.account_number, w.bank_code);
            recipientCode = recipientRes.data.recipient_code;

            await client.query("UPDATE fulfillers SET paystack_recipient_code = $1 WHERE id = $2", [recipientCode, w.fulfiller_id]);
        }

        // 3. Initiate Transfer
        const transferRef = `WDL_${id}_${Date.now()}`;
        const transferRes = await paystackService.initiateTransfer(w.amount, recipientCode, transferRef);

        // 4. Update Status to PROCESSING
        await client.query(
            "UPDATE withdrawals SET status = 'PROCESSING', paystack_transfer_code = $1 WHERE id = $2",
            [transferRes.data.transfer_code, id]
        );

        // Audit Log
        await client.query(
            "INSERT INTO audit_logs (admin_id, action, target_type, target_id, payload) VALUES ($1, $2, $3, $4, $5)",
            [adminId, 'APPROVE_WITHDRAWAL', 'withdrawal', id, JSON.stringify({ transfer_code: transferRes.data.transfer_code })]
        );

        await client.query('COMMIT');
        res.redirect('/admin/withdrawals');

    } catch (error) {
        await client.query('ROLLBACK');
        console.error('[Admin] Withdrawal Approval Failed:', error.message);
        res.status(500).send(`Approval Error: ${error.message}`);
    } finally {
        client.release();
    }
};

/**
 * Fleet Management: List all fulfillers.
 */
const getFulfillers = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT f.*, u.full_name, u.email, u.phone as user_phone
            FROM fulfillers f
            JOIN users u ON u.id = f.user_id
            ORDER BY f.created_at DESC
        `);
        res.render('fulfillers', { fulfillers: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Fleet Management: Update fulfiller status (suspend, reactivate, terminate).
 */
const updateFulfillerStatus = async (req, res) => {
    const { id } = req.params;
    let { status } = req.body; // active, suspended, terminated

    // Safety: Handle array submission from UI (prevents constraint violation)
    if (Array.isArray(status)) status = status[0];

    try {
        await db.query("UPDATE fulfillers SET status = $1 WHERE id = $2", [status, id]);
        await db.query(
            "INSERT INTO audit_logs (admin_id, action, target_type, target_id, payload) VALUES ($1, $2, $3, $4, $5)",
            [req.session.adminId, 'UPDATE_FULFILLER_STATUS', 'fulfiller', id, JSON.stringify({ status })]
        );
        res.redirect('/admin/fulfillers');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Manual Order Management: Update order status or force complete stuck orders.
 */
const updateOrderStatus = async (req, res) => {
    const { id } = req.params;
    let { status } = req.body; // e.g. DELIVERED, CANCELLED

    // Safety: Handle array submission from UI (prevents constraint violation)
    if (Array.isArray(status)) status = status[0];

    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');
        const { rows } = await client.query("SELECT escrow_status FROM orders WHERE id = $1 FOR UPDATE", [id]);
        const order = rows[0];

        await client.query("UPDATE orders SET status = $1 WHERE id = $2", [status, id]);

        if (status === 'DELIVERED') {
            await client.query("UPDATE orders SET payment_status = 'PAID' WHERE id = $1", [id]);

            // 1. Settle Delivery Fee for Fulfiller (Isolated via SAVEPOINT to prevent transaction abort)
            try {
                await client.query('SAVEPOINT settlement_sp');
                await walletService.processMissionSettlement(id, client);
                await client.query('RELEASE SAVEPOINT settlement_sp');
            } catch (e) {
                await client.query('ROLLBACK TO SAVEPOINT settlement_sp').catch(() => {});
                console.error('[Admin] Fulfiller settlement on force complete failed:', e.message);
            }

            // 2. Release Item Price Escrow if applicable (Isolated via SAVEPOINT to prevent transaction abort)
            if (order && order.escrow_status === 'held') {
                try {
                    await client.query('SAVEPOINT escrow_sp');
                    await walletService.releaseEscrow(id, client);
                    await client.query('RELEASE SAVEPOINT escrow_sp');
                } catch (e) {
                    await client.query('ROLLBACK TO SAVEPOINT escrow_sp').catch(() => {});
                    console.error('[Admin] Escrow release on force complete failed:', e.message);
                }
            }
        }

        await client.query(
            "INSERT INTO audit_logs (admin_id, action, target_type, target_id, payload) VALUES ($1, $2, $3, $4, $5)",
            [req.session.adminId, 'MANUAL_ORDER_UPDATE', 'order', id, JSON.stringify({ status })]
        );

        await client.query('COMMIT');
        res.redirect(`/admin/orders/${id}/track`);
    } catch (error) {
        await client.query('ROLLBACK');
        res.status(500).send(`Order update failed: ${error.message}`);
    } finally {
        client.release();
    }
};

/**
 * Transaction Audit Ledger: List all platform ledger entries and financial activity.
 */
const getTransactions = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT l.*, w.owner_type, w.owner_id
            FROM wallet_ledger_entries l
            JOIN wallets w ON w.id = l.wallet_id
            ORDER BY l.created_at DESC LIMIT 200
        `);
        res.render('transactions', { transactions: rows });
    } catch (error) {
        res.render('transactions', { transactions: [] });
    }
};

/**
 * Customer Management: List all customers.
 */
const getCustomers = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT u.*, w.balance, w.pending_balance
            FROM users u
            LEFT JOIN wallets w ON w.owner_type = 'USER' AND w.owner_id = u.id::text
            WHERE u.role = 'CUSTOMER'
            ORDER BY u.created_at DESC
        `);
        res.render('customers', { customers: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Customer Management: View individual customer details and activity.
 */
const getCustomerDetail = async (req, res) => {
    const { id } = req.params;
    try {
        const userRes = await db.query("SELECT * FROM users WHERE id = $1", [id]);
        if (userRes.rows.length === 0) return res.status(404).send('Customer not found');

        const ordersRes = await db.query("SELECT * FROM orders WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50", [id]);
        const walletRes = await db.query("SELECT * FROM wallets WHERE owner_type = 'USER' AND owner_id = $1", [id.toString()]);

        let ledger = [];
        if (walletRes.rows.length > 0) {
            const ledgerRes = await db.query("SELECT * FROM wallet_ledger_entries WHERE wallet_id = $1 ORDER BY created_at DESC LIMIT 50", [walletRes.rows[0].id]);
            ledger = ledgerRes.rows;
        }

        res.render('customer_detail', {
            customer: userRes.rows[0],
            orders: ordersRes.rows,
            wallet: walletRes.rows[0] || { balance: 0, pending_balance: 0 },
            ledger
        });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Customer Management: Update customer status (suspend/activate).
 */
const updateCustomerStatus = async (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    try {
        await db.query("UPDATE users SET status = $1 WHERE id = $2", [status, id]).catch(() => {});
        res.redirect(`/admin/customers/${id}`);
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const getFulfillerDetail = async (req, res) => {
    const { id } = req.params;
    try {
        const fRes = await db.query(`
            SELECT f.*, u.full_name as user_name, u.email as user_email, u.phone as user_phone
            FROM fulfillers f
            JOIN users u ON u.id = f.user_id
            WHERE f.id = $1`, [id]);

        if (fRes.rows.length === 0) return res.status(404).send('Fulfiller not found');

        const walletRes = await db.query("SELECT * FROM wallets WHERE owner_type = 'FULFILLER' AND owner_id = $1", [id.toString()]);

        let ledger = [];
        if (walletRes.rows.length > 0) {
            const ledgerRes = await db.query("SELECT * FROM wallet_ledger_entries WHERE wallet_id = $1 ORDER BY created_at DESC LIMIT 50", [walletRes.rows[0].id]);
            ledger = ledgerRes.rows;
        }

        res.render('fulfiller_detail', {
            fulfiller: fRes.rows[0],
            wallet: walletRes.rows[0] || { balance: 0, pending_balance: 0 },
            ledger
        });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Nationwide Readiness: City Management
 */
const getCities = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT * FROM operating_cities ORDER BY name ASC");
        res.render('cities', { cities: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const addCity = async (req, res) => {
    const { name, state_name, lat, lng, requires_rider_permit } = req.body;
    try {
        await db.query(
            `INSERT INTO operating_cities (name, state_name, lat, lng, requires_rider_permit)
             VALUES ($1, $2, $3, $4, $5)`,
            [name, state_name, lat, lng, requires_rider_permit === 'true']
        );
        res.redirect('/admin/cities');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const updateCityRules = async (req, res) => {
    const { id } = req.params;
    const { is_active, requires_rider_permit, daylight_start, daylight_end } = req.body;
    try {
        await db.query(
            `UPDATE operating_cities
             SET is_active = $1,
                 requires_rider_permit = $2,
                 daylight_start = $3,
                 daylight_end = $4
             WHERE id = $5`,
            [is_active === 'true', requires_rider_permit === 'true', daylight_start, daylight_end, id]
        );
        res.redirect('/admin/cities');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const getExpansionWaitlist = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT * FROM expansion_waitlist ORDER BY created_at DESC");
        res.render('waitlist', { waitlist: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Emergency SOS Management (v4.3)
 */
const getEmergencyDashboard = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT e.*, f.full_name as fulfiller_name, f.phone as fulfiller_phone,
                   ST_Y(e.last_location::geometry) as lat, ST_X(e.last_location::geometry) as lng
            FROM emergency_alerts e
            JOIN fulfillers f ON f.id = e.fulfiller_id
            WHERE e.status = 'OPEN'
            ORDER BY e.created_at DESC
        `);
        res.render('emergency_resolution', { alerts: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const resolveEmergency = async (req, res) => {
    const { id } = req.params;
    const { resolution_notes } = req.body;
    try {
        await db.query(
            "UPDATE emergency_alerts SET status = 'RESOLVED', resolution_notes = $1, resolved_at = CURRENT_TIMESTAMP WHERE id = $2",
            [resolution_notes, id]
        );
        res.redirect('/admin/emergency');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * AI Knowledge Base & Assistant Management
 */
const getKnowledgeBaseAdmin = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT * FROM knowledge_base ORDER BY priority DESC, created_at DESC");
        res.render('knowledge_base_admin', { articles: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const createKnowledgeArticle = async (req, res) => {
    const { title, content, category, target_audience, priority } = req.body;
    try {
        await db.query(
            `INSERT INTO knowledge_base (title, content, category, target_audience, priority)
             VALUES ($1, $2, $3, $4, $5)`,
            [title, content, category || 'GENERAL', target_audience || 'BOTH', parseInt(priority || 0)]
        );
        res.redirect('/admin/knowledge-base');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const toggleKnowledgeArticle = async (req, res) => {
    const { id } = req.params;
    try {
        await db.query("UPDATE knowledge_base SET is_active = NOT is_active WHERE id = $1", [id]);
        res.redirect('/admin/knowledge-base');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Corporate Accounts Management
 */
const getCorporateAdmin = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT ca.*, u.full_name as owner_name, u.email as owner_email, u.phone as owner_phone,
                   COALESCE(ca.cac_document_url, (SELECT file_url FROM kyc_documents WHERE user_id = ca.owner_user_id AND doc_type = 'CAC_CERTIFICATE' ORDER BY created_at DESC LIMIT 1)) as doc_url,
                   (SELECT COUNT(*) FROM corporate_sub_accounts WHERE corporate_account_id = ca.id) as staff_count
            FROM corporate_accounts ca
            JOIN users u ON u.id = ca.owner_user_id
            ORDER BY ca.created_at DESC
        `);
        res.render('corporate_admin', { accounts: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

const updateCorporateStatus = async (req, res) => {
    const { id } = req.params;
    const { status, is_active } = req.body;
    let targetStatus = status;
    if (!targetStatus && is_active !== undefined) {
        targetStatus = (is_active === 'true' || is_active === true) ? 'ACTIVE' : 'SUSPENDED';
    }
    targetStatus = targetStatus || 'ACTIVE';

    try {
        await db.query(
            "UPDATE corporate_accounts SET status = $1 WHERE id = $2",
            [targetStatus, id]
        );
        res.redirect('/admin/corporate');
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Audit Logs & Compliance Deletion Requests
 */
const getAuditLogsAdmin = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT a.*, u.full_name as admin_name
            FROM audit_logs a
            LEFT JOIN users u ON u.id = a.admin_id
            ORDER BY a.created_at DESC LIMIT 200
        `);
        res.render('audit_logs_admin', { logs: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Marketplace Returns & Disputes Overview
 */
const getReturnsAdmin = async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT r.*, o.item_description, o.user_id, u.full_name as customer_name, u.phone as customer_phone
            FROM returns r
            JOIN orders o ON o.id = r.order_id
            JOIN users u ON u.id = o.user_id
            ORDER BY r.created_at DESC LIMIT 100
        `);
        res.render('returns_admin', { returnsList: rows });
    } catch (error) {
        res.status(500).send(error.message);
    }
};

/**
 * Admin Action: Force Delete/Purge User Account.
 */
/**
 * Helper: Runs a sub-query inside a SAVEPOINT block to keep transaction active on error.
 */
const safeExec = async (client, sql, params, spName) => {
    try {
        await client.query(`SAVEPOINT ${spName}`);
        await client.query(sql, params);
        await client.query(`RELEASE SAVEPOINT ${spName}`);
    } catch (e) {
        await client.query(`ROLLBACK TO SAVEPOINT ${spName}`);
        console.warn(`[SavepointBypass] Sub-operation ${spName} bypassed: ${e.message}`);
    }
};

/**
 * Admin Action: Force Delete/Purge User Account.
 */
const forceDeleteUser = async (req, res) => {
    const { id } = req.params;
    const adminId = req.session.adminId || 0;

    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');

        // 1. Unlink or delete associated order dependencies
        await safeExec(client, "UPDATE orders SET fulfiller_id = NULL, queued_for_fulfiller_id = NULL WHERE fulfiller_id IN (SELECT id FROM fulfillers WHERE user_id = $1) OR queued_for_fulfiller_id IN (SELECT id FROM fulfillers WHERE user_id = $1)", [id], 'sp_orders_ful');
        await safeExec(client, "UPDATE orders SET vendor_id = NULL, kitchen_id = NULL WHERE vendor_id IN (SELECT id FROM vendors WHERE user_id = $1) OR kitchen_id IN (SELECT id FROM kitchens WHERE user_id = $1)", [id], 'sp_orders_merch');
        await safeExec(client, "DELETE FROM emergency_alerts WHERE user_id = $1 OR fulfiller_id IN (SELECT id FROM fulfillers WHERE user_id = $1)", [id], 'sp_alerts');
        await safeExec(client, "DELETE FROM withdrawals WHERE fulfiller_id IN (SELECT id FROM fulfillers WHERE user_id = $1)", [id], 'sp_withdrawals');
        await safeExec(client, "DELETE FROM kyc_documents WHERE user_id = $1 OR fulfiller_id IN (SELECT id FROM fulfillers WHERE user_id = $1)", [id], 'sp_kyc');
        await safeExec(client, "DELETE FROM wallets WHERE (owner_type = 'USER' AND owner_id = $1) OR (owner_type = 'FULFILLER' AND owner_id IN (SELECT id FROM fulfillers WHERE user_id = $1))", [id], 'sp_wallets');
        await safeExec(client, "DELETE FROM corporate_sub_accounts WHERE user_id = $1", [id], 'sp_corp_sub');
        await safeExec(client, "DELETE FROM corporate_accounts WHERE owner_user_id = $1", [id], 'sp_corp_acc');
        await safeExec(client, "DELETE FROM fleet_partner_invites WHERE fleet_partner_id IN (SELECT id FROM fleet_partners WHERE user_id = $1)", [id], 'sp_fleet_invites');

        // 2. Delete business entities
        await safeExec(client, "DELETE FROM fulfillers WHERE user_id = $1", [id], 'sp_ful');
        await safeExec(client, "DELETE FROM vendors WHERE user_id = $1", [id], 'sp_ven');
        await safeExec(client, "DELETE FROM kitchens WHERE user_id = $1", [id], 'sp_kit');
        await safeExec(client, "DELETE FROM fleet_partners WHERE user_id = $1", [id], 'sp_fleet');

        // 3. Delete user session/token records
        await safeExec(client, "DELETE FROM otp_verifications WHERE user_id = $1", [id], 'sp_otp');
        await safeExec(client, "DELETE FROM user_fcm_tokens WHERE user_id = $1", [id], 'sp_fcm');
        await safeExec(client, "DELETE FROM user_sessions WHERE user_id = $1", [id], 'sp_sess');

        // 4. Delete user primary row
        await client.query("DELETE FROM users WHERE id = $1", [id]);

        // Audit Log
        await safeExec(client,
            "INSERT INTO audit_logs (admin_id, action, target_type, target_id, payload) VALUES ($1, $2, $3, $4, $5)",
            [adminId, 'ADMIN_FORCE_DELETE_USER', 'user', id, JSON.stringify({ deleted_at: new Date() })],
            'sp_audit'
        );

        await client.query('COMMIT');
        console.log(`[Admin] User Account #${id} FORCE DELETED by Admin`);

        const referer = req.get('Referer') || '/admin/customers';
        res.redirect(referer);
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('[Admin] Force delete error:', error.message);
        res.status(500).send(`Failed to delete user account: ${error.message}`);
    } finally {
        client.release();
    }
};

/**
 * Admin Action: Delete Merchant Store (Vendor or Kitchen).
 */
const deleteMerchant = async (req, res) => {
    const type = req.params.type || req.body.type; // vendor or kitchen
    const id = req.params.id || req.body.id;
    const adminId = req.session.adminId || 0;

    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');
        const isKitchen = type === 'kitchen';
        const table = isKitchen ? 'kitchens' : 'vendors';

        if (isKitchen) {
            await safeExec(client, "DELETE FROM menu_items WHERE kitchen_id = $1", [id], 'sp_menu');
            await safeExec(client, "DELETE FROM merchant_coupons WHERE kitchen_id = $1", [id], 'sp_coupons_kit');
            await safeExec(client, "DELETE FROM marketplace_returns WHERE kitchen_id = $1", [id], 'sp_returns_kit');
            await safeExec(client, "UPDATE orders SET kitchen_id = NULL WHERE kitchen_id = $1", [id], 'sp_orders_kit');
        } else {
            await safeExec(client, "DELETE FROM products WHERE vendor_id = $1", [id], 'sp_products');
            await safeExec(client, "DELETE FROM merchant_coupons WHERE merchant_id = $1", [id], 'sp_coupons_ven');
            await safeExec(client, "DELETE FROM marketplace_returns WHERE vendor_id = $1", [id], 'sp_returns_ven');
            await safeExec(client, "UPDATE orders SET vendor_id = NULL WHERE vendor_id = $1", [id], 'sp_orders_ven');
        }

        await client.query(`DELETE FROM ${table} WHERE id = $1`, [id]);

        await safeExec(client,
            "INSERT INTO audit_logs (admin_id, action, target_type, target_id, payload) VALUES ($1, $2, $3, $4, $5)",
            [adminId, 'ADMIN_DELETE_MERCHANT', type, id, JSON.stringify({ deleted_at: new Date() })],
            'sp_audit_merch'
        );

        await client.query('COMMIT');
        console.log(`[Admin] Merchant ${type} #${id} DELETED by Admin`);

        const referer = req.get('Referer') || `/admin/${isKitchen ? 'kitchens' : 'vendors'}`;
        res.redirect(referer);
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('[Admin] Delete merchant error:', error.message);
        res.status(500).send(`Failed to delete merchant: ${error.message}`);
    } finally {
        client.release();
    }
};

/**
 * Admin Action: Audit & Restore All Active & Queued Missions.
 */
const restoreAllMissions = async (req, res) => {
    try {
        const { rows: orders } = await db.query(`
            SELECT o.id, o.status, o.user_id, o.fulfiller_id, o.queued_for_fulfiller_id,
                   o.pickup_address, o.delivery_address, o.total_fare, o.item_description, o.created_at
            FROM orders o
            WHERE o.status NOT IN ('DELIVERED', 'CANCELLED', 'RELEASED', 'REFUNDED')
            ORDER BY o.created_at ASC
        `);

        let restoredActiveCount = 0;
        let restoredQueuedCount = 0;
        let searchingCount = 0;

        for (const o of orders) {
            if (o.fulfiller_id && ['SEARCHING', 'PENDING', 'PENDING_ACKNOWLEDGMENT', 'PAYMENT_CAPTURED', 'PAID', 'PROCESSING', 'CONFIRMED'].includes(o.status)) {
                await db.query(
                    "UPDATE orders SET status = 'MATCHED', matched_at = COALESCE(matched_at, CURRENT_TIMESTAMP) WHERE id = $1",
                    [o.id]
                );
                restoredActiveCount++;
            } else if (o.queued_for_fulfiller_id && !o.fulfiller_id) {
                const { rows: activeCheck } = await db.query(
                    "SELECT id FROM orders WHERE fulfiller_id = $1 AND status NOT IN ('DELIVERED', 'CANCELLED', 'RELEASED', 'REFUNDED')",
                    [o.queued_for_fulfiller_id]
                );

                if (activeCheck.length === 0) {
                    await db.query(
                        "UPDATE orders SET fulfiller_id = $1, status = 'MATCHED', matched_at = CURRENT_TIMESTAMP WHERE id = $2",
                        [o.queued_for_fulfiller_id, o.id]
                    );
                    restoredActiveCount++;
                } else {
                    await db.query("UPDATE orders SET status = 'QUEUED' WHERE id = $1", [o.id]);
                    restoredQueuedCount++;
                }
            } else if (o.status === 'QUEUED' && o.fulfiller_id) {
                await db.query("UPDATE orders SET queued_for_fulfiller_id = $1, fulfiller_id = NULL WHERE id = $2", [o.fulfiller_id, o.id]);
                restoredQueuedCount++;
            } else if (!o.fulfiller_id && !o.queued_for_fulfiller_id) {
                searchingCount++;
            }
        }

        console.log(`[AdminRestore] Active: ${restoredActiveCount} | Queued: ${restoredQueuedCount} | Searching: ${searchingCount}`);

        res.status(200).json({
            success: true,
            message: `Restored ${restoredActiveCount} Active Missions and ${restoredQueuedCount} Queued Missions across agents.`,
            data: { restored_active: restoredActiveCount, restored_queued: restoredQueuedCount, searching: searchingCount, total: orders.length }
        });
    } catch (e) {
        console.error('[AdminRestore] Error:', e.message);
        res.status(500).json({ success: false, message: e.message });
    }
};

/**
 * Admin Manual Dispatch Override: Assigns order directly to an online agent.
 */
const assignOrderToAgent = async (req, res) => {
    const { id } = req.params;
    const { fulfiller_id } = req.body;
    const adminId = req.session.adminId || 0;

    const fId = parseInt(fulfiller_id);
    const orderId = parseInt(id);

    if (isNaN(fId) || isNaN(orderId)) {
        return res.status(400).json({ success: false, message: 'Invalid order or agent ID' });
    }

    try {
        const { rows: fUser } = await db.query("SELECT user_id, full_name FROM fulfillers WHERE id = $1", [fId]);
        if (fUser.length === 0) return res.status(404).json({ success: false, message: 'Agent not found' });

        await db.query(
            "UPDATE orders SET fulfiller_id = $1, status = 'MATCHED', matched_at = CURRENT_TIMESTAMP WHERE id = $2",
            [fId, orderId]
        );

        const socketService = require('../services/socketService');
        const io = socketService.getIO();
        io.to(`order_${orderId}`).emit("status_updated", { orderId, status: 'MATCHED' });
        io.to(`user_${fUser[0].user_id}`).emit("order_status_updated", { orderId, status: 'MATCHED' });

        console.log(`[AdminDispatch] Mission #${orderId} MANUALLY ASSIGNED to Agent #${fId} (${fUser[0].full_name}) by Admin #${adminId}`);

        res.status(200).json({
            success: true,
            message: `Mission #${orderId} manually assigned to Agent ${fUser[0].full_name}.`
        });
    } catch (e) {
        console.error('[AdminDispatch] Manual assignment error:', e.message);
        res.status(500).json({ success: false, message: e.message });
    }
};

/**
 * Admin Action: Batch Approve All Pending Payouts.
 */
const batchApproveWithdrawals = async (req, res) => {
    try {
        const { rows: pending } = await db.query("SELECT id FROM withdrawals WHERE status = 'PENDING'");
        let approvedCount = 0;

        for (const w of pending) {
            try {
                await db.query("UPDATE withdrawals SET status = 'SUCCESS', processed_at = CURRENT_TIMESTAMP WHERE id = $1", [w.id]);
                approvedCount++;
            } catch (_) {}
        }

        console.log(`[AdminBatchPayout] Approved ${approvedCount} payouts.`);

        res.status(200).json({
            success: true,
            message: `Successfully approved and processed ${approvedCount} pending payout requests.`
        });
    } catch (e) {
        console.error('[AdminBatchPayout] Error:', e.message);
        res.status(500).json({ success: false, message: e.message });
    }
};

module.exports = {
  login,
  getSignup,
  postSignup,
  getDashboard,
  getOrders,
  trackOrder,
  assignOrderToAgent,
  batchApproveWithdrawals,
  getSettings,
  updateSettings,
  getSupportInbox,
  getConversationDetails,
  getKYCQueue,
  getKYCReview,
  updateKYCStatus,
  updateMerchantKYCStatus,
  getVendors,
  getKitchens,
  getMerchants,
  getMerchantStoreItems,
  toggleMerchantItemStatus,
  updateMerchantItem,
  deleteMerchantItem,
  getFleetPartners,
  updateFleetPartnerStatus,
  getCities,
  restoreAllMissions,
  addCity,
  updateCityRules,
  getExpansionWaitlist,
  getEmergencyDashboard,
  resolveEmergency,
  getAdminUsers,
  addAdmin,
  deleteAdmin,
  getProfile,
  getCoupons,
  createCoupon,
  deleteCoupon,
  getDisputes: getDisputeResolutionCenter,
  resolveDispute,
  getWithdrawals,
  approveWithdrawal,
  getFulfillers,
  getFulfillerDetail,
  updateFulfillerStatus,
  updateOrderStatus,
  getTransactions,
  getLandmarks,
  getTrafficCorridors,
  addTrafficCorridor,
  getCustomers,
  getCustomerDetail,
  updateCustomerStatus,
  getKnowledgeBaseAdmin,
  createKnowledgeArticle,
  toggleKnowledgeArticle,
  getCorporateAdmin,
  updateCorporateStatus,
  getAuditLogsAdmin,
  getReturnsAdmin,
  forceDeleteUser,
  deleteMerchant
};
