const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../services/authService');

/**
 * Validates the JWT Bearer token.
 */
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.status(401).json({ success: false, message: 'Access token required' });

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.status(401).json({ success: false, message: 'Invalid or expired token' });
    req.user = user;
    next();
  });
};

module.exports = {
  authenticateToken
};
