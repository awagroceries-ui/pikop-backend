const nodemailer = require('nodemailer');
const PlatformConfig = require('../config/platform');

const SMTP_HOST = process.env.SMTP_HOST || 'smtp-relay.brevo.com';
const SMTP_PORT = parseInt(process.env.SMTP_PORT || '587');
const SMTP_USER = process.env.SMTP_USER;
const SMTP_PASS = process.env.SMTP_PASS;
const EMAIL_FROM = process.env.EMAIL_FROM || 'awagroceries@gmail.com';

let transporter;

if (SMTP_USER && SMTP_PASS) {
    transporter = nodemailer.createTransport({
        host: SMTP_HOST,
        port: SMTP_PORT,
        secure: false,
        auth: {
            user: SMTP_USER,
            pass: SMTP_PASS,
        },
    });
    console.log('✅ Email Service: SMTP identity confirmed.');
} else {
    console.warn('⚠️ Email Service: Missing credentials.');
}

/**
 * Sends a premium-grade branded transactional email.
 */
const sendMail = async (to, subject, html) => {
  const cleanFrom = EMAIL_FROM.replace(/["'<>]/g, '').trim();

  const premiumTemplate = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
            body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; background-color: #F3F4F6; margin: 0; padding: 0; -webkit-font-smoothing: antialiased; }
            .wrapper { width: 100%; padding: 40px 0; background-color: #F3F4F6; }
            .container { width: 100%; max-width: 600px; margin: 0 auto; background: #ffffff; border-radius: 32px; overflow: hidden; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.08); }
            .header { background-color: #008751; padding: 50px 40px; text-align: center; }
            .logo { height: 42px; width: auto; filter: brightness(0) invert(1); }
            .content { padding: 50px 40px; color: #1F2937; }
            .greeting { font-size: 24px; font-weight: 800; color: #111827; margin-bottom: 20px; letter-spacing: -0.025em; }
            .text { font-size: 16px; line-height: 1.6; color: #4B5563; margin-bottom: 30px; }
            .cta-container { margin: 40px 0; text-align: center; }
            .otp-code { font-size: 42px; font-weight: 900; letter-spacing: 12px; color: #008751; background: #F0FDF4; padding: 24px; border-radius: 20px; display: inline-block; border: 2px dashed #008751; }
            .footer { padding: 40px; text-align: center; background: #F9FAFB; border-top: 1px solid #F3F4F6; }
            .footer-text { font-size: 13px; color: #9CA3AF; line-height: 1.6; }
            .social-links { margin-top: 20px; }
            .social-link { color: #008751; text-decoration: none; font-weight: 600; margin: 0 10px; font-size: 13px; }
            @media (max-width: 600px) {
                .container { border-radius: 0; margin: 0; }
                .content { padding: 40px 24px; }
                .header { padding: 40px 24px; }
            }
        </style>
    </head>
    <body>
        <div class="wrapper">
            <div class="container">
                <div class="header">
                    <img src="https://api.pikop.com.ng/public/assets/logo.png" alt="Pikop Logo" class="logo">
                </div>
                <div class="content">
                    ${html}
                </div>
                <div class="footer">
                    <p class="footer-text">
                        <strong>&copy; 2026 Pikop Logistics Limited.</strong><br>
                        Superior Multi-Platform Logistics Engine.<br>
                        Port Harcourt, Nigeria.
                    </p>
                    <div class="social-links">
                        <a href="https://pikop.com.ng" class="social-link">Website</a>
                        <a href="https://api.pikop.com.ng/support" class="social-link">Support</a>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
  `;

  if (!transporter) return { success: true, messageId: 'mock' };

  try {
    const info = await transporter.sendMail({
      from: `"Pikop" <${cleanFrom}>`,
      to,
      subject: subject.toUpperCase(),
      html: premiumTemplate,
      headers: {
        'X-Priority': '1 (Highest)',
        'X-MSMail-Priority': 'High',
        'Importance': 'High'
      }
    });

    console.log(`[Email] Branded success! Delivered to ${to}.`);
    return { success: true, messageId: info.messageId };
  } catch (error) {
    console.error(`[Email] CRITICAL FAILURE for ${to}:`, {
        message: error.message,
        code: error.code,
        command: error.command,
        response: error.response
    });
    return { success: false, error: error.message };
  }
};

/**
 * Sends Welcome & Onboarding Email upon registration/verification.
 * Tailored for 5 distinct groups: Customer, Agent/Fulfiller, Food Merchant, Groceries Merchant, Shop Merchant.
 */
const sendWelcomeEmail = async (to, name, role, data = {}) => {
    let title = 'Welcome to Pikop Logistics!';
    let contentHtml = '';

    // Fetch dynamic rates from database settings with 5% / 20% fallbacks
    const db = require('../config/db');
    let codRate = 0.05;
    let dispatchCommRate = 0.20;
    let categoryComm = 0.05;

    try {
        const { rows } = await db.query("SELECT key, value FROM settings WHERE key IN ('cod_fee_rate', 'platform_commission', 'food_commission', 'groceries_commission', 'shop_commission')");
        rows.forEach(r => {
            if (r.key === 'cod_fee_rate') codRate = parseFloat(r.value);
            if (r.key === 'platform_commission') dispatchCommRate = parseFloat(r.value);
        });
    } catch (e) {}

    const agentShareStr = ((1 - dispatchCommRate) * 100).toFixed(0) + '%';
    const codFeeStr = (codRate * 100).toFixed(0) + '%';

    if (role === 'CUSTOMER') {
        title = 'Welcome to Pikop Logistics!';
        contentHtml = `
            <h1 class="greeting">Welcome to the Neighborhood! 📍</h1>
            <p class="text">Hello <strong>${name || 'Valued User'}</strong>,</p>
            <p class="text">Thank you for joining Pikop! You can now send packages, track deliveries in real-time, and manage your logistics effortlessly across Port Harcourt and beyond.</p>

            <div style="background: #F9FAFB; padding: 20px; border-radius: 16px; border: 1px solid #E5E7EB; margin-bottom: 25px;">
                <strong style="color: #111827;">What you can do:</strong>
                <ul style="margin-top: 10px; padding-left: 20px; color: #4B5563; font-size: 14px; line-height: 1.6;">
                    <li><strong>Dispatch:</strong> Send items across the city instantly.</li>
                    <li><strong>Food & Kitchen:</strong> Order delicious meals from local kitchens.</li>
                    <li><strong>Groceries:</strong> Get fresh produce and raw food delivered to your door.</li>
                    <li><strong>Marketplace:</strong> Shop for general items from the comfort of your home.</li>
                </ul>
            </div>

            <p class="text"><strong>Buyer Protection:</strong> With our Cash on Delivery (COD) and Escrow system (${codFeeStr} platform fee), your funds are secured until you confirm receipt of your item.</p>
            <p class="text">View our full <a href="https://pikop.com.ng/terms">Terms & Conditions</a> and <a href="https://pikop.com.ng/privacy">Privacy Policy</a>.</p>
        `;
    }
    else if (role === 'FULFILLER') {
        title = 'Welcome to the Pikop Fleet!';
        const category = (data.category || 'Agent').replace('_', ' ').toLowerCase();
        contentHtml = `
            <h1 class="greeting">Welcome to the Fleet! 🚀</h1>
            <p class="text">Hello <strong>${name || 'Agent'}</strong>,</p>
            <p class="text">Your account has been approved! You are now verified as a <strong>${category}</strong> in our network.</p>

            <div style="background: #F0FDF4; padding: 24px; border-radius: 20px; border: 1px solid #BBF7D0; margin: 30px 0;">
                <h3 style="margin-top: 0; color: #008751;">💡 How Missions Work:</h3>
                <ul style="color: #374151; line-height: 1.8; margin-bottom: 0;">
                    <li><strong>Accepting:</strong> Toggle "Online" in the app to see nearby delivery offers.</li>
                    <li><strong>Earning (${agentShareStr} Share):</strong> You receive <strong>${agentShareStr}</strong> of the delivery fare per completed mission, released to your wallet instantly upon delivery.</li>
                    <li><strong>Conduct:</strong> Please review our <a href="https://pikop.com.ng/terms/fulfiller">Fulfiller Conduct Policy</a> to maintain your tier.</li>
                </ul>
            </div>

            <p class="text">Don't forget to complete your payout bank details in the "Wallet" section of the app if you haven't already.</p>
        `;
    }
    else if (role === 'MERCHANT') {
        const merchantType = (data.category || 'Shop').toLowerCase();
        title = `Welcome to Pikop ${merchantType === 'food' ? 'Kitchens' : 'Marketplace'}!`;

        const commissionStr = (categoryComm * 100).toFixed(0) + '%';
        const acceptsCod = data.accepts_cod === true;

        contentHtml = `
            <h1 class="greeting">Your Store is Now Live! 🏪</h1>
            <p class="text">Hello <strong>${name || 'Partner'}</strong>,</p>
            <p class="text">Congratulations! Your business verification is complete. Your ${merchantType} store is now active on Pikop.</p>

            <div style="background: #F9FAFB; padding: 24px; border-radius: 20px; border: 1px solid #E5E7EB; margin: 30px 0;">
                <h3 style="margin-top: 0; color: #111827;">📊 Store Terms Summary:</h3>
                <ul style="color: #4B5563; line-height: 1.8; margin-bottom: 0;">
                    <li><strong>Commission:</strong> Pikop marketplace commission is <strong>${commissionStr}</strong> per sale across all merchant categories.</li>
                    <li><strong>COD Status:</strong> You have opted <strong>${acceptsCod ? 'IN' : 'OUT'}</strong> for Cash on Delivery orders.</li>
                    <li><strong>Payouts:</strong> Sales funds are held in escrow and released to your available balance after the customer confirms receipt.</li>
                </ul>
            </div>

            <p class="text"><strong>Get Started:</strong> Head over to your Merchant Portal to list your first item and start receiving orders!</p>
            <p class="text">Read our <a href="https://pikop.com.ng/terms/merchant">Merchant Service Agreement</a> for more details.</p>
        `;
    }

    const html = `
        ${contentHtml}
        <div style="background: #F9FAFB; padding: 20px; border-radius: 16px; border: 1px solid #E5E7EB; margin-bottom: 25px;">
            <strong style="color: #111827;">Quick Safety Reminder:</strong>
            <ul style="margin-top: 10px; padding-left: 20px; color: #4B5563; font-size: 14px; line-height: 1.6;">
                <li><strong>Prohibited Items:</strong> No illegal goods, drugs, or weapons. Discovery will be reported to the Nigeria Police Force.</li>
                <li><strong>Return Charges:</strong> Return missions are charged at 75% of the original fare.</li>
            </ul>
        </div>
        <p class="text">If you ever need assistance, our support team is available 24/7 in the app Help Center.</p>
    `;

    return await sendMail(to, title, html);
};

/**
 * Sends KYC Approval or Rejection Email to Fulfillers.
 */
const sendKycStatusEmail = async (to, name, status, note) => {
    const isApproved = status === 'VERIFIED';
    const subject = isApproved ? 'Your Pikop Fulfiller Account is Approved!' : 'Pikop Verification Status Update';

    const html = isApproved ? `
        <h1 class="greeting" style="color: #008751;">Congratulations! You are Approved! 🎉</h1>
        <p class="text">Hello <strong>${name || 'Agent'}</strong>,</p>
        <p class="text">Your KYC verification and document review have been successfully approved by our administration team. Your account is now fully active.</p>

        <div style="background: #F0FDF4; padding: 24px; border-radius: 20px; border: 1px solid #BBF7D0; margin: 30px 0;">
            <h3 style="margin-top: 0; color: #008751;">🚀 Fulfiller Operating Guidelines:</h3>
            <ul style="color: #374151; line-height: 1.8; margin-bottom: 0;">
                <li><strong>Go Online:</strong> Toggle your status switch on the dashboard when ready to receive nearby delivery offers.</li>
                <li><strong>Pickup Protocol:</strong> Verify package details and confirm code with the sender before moving.</li>
                <li><strong>Safe Transport:</strong> Keep items secure and deliver within estimated windows.</li>
                <li><strong>Delivery Verification:</strong> Confirm delivery code with recipient to complete mission & unlock earnings.</li>
            </ul>
        </div>

        <p class="text">Open your Pikop app now, go online, and start earning!</p>
    ` : `
        <h1 class="greeting" style="color: #DC2626;">Verification Action Required</h1>
        <p class="text">Hello <strong>${name || 'Applicant'}</strong>,</p>
        <p class="text">We reviewed your submitted verification documents for your Pikop Fulfiller application.</p>
        <p class="text"><strong>Reason / Note:</strong> ${note || 'Document details were unclear or unverified.'}</p>
        <p class="text">Please log back into the Pikop app, re-upload clear photos of your documents or vehicle details, and resubmit for approval.</p>
    `;

    return await sendMail(to, subject, html);
};

/**
 * Sends Payment Confirmation / Receipt Email.
 */
const sendPaymentReceiptEmail = async (to, name, orderId, amount, itemDesc) => {
    const subject = `Payment Confirmation - Mission #${orderId}`;
    const html = `
        <h1 class="greeting">Payment Received!</h1>
        <p class="text">Hello <strong>${name || 'Customer'}</strong>,</p>
        <p class="text">We've confirmed your payment for delivery mission <strong>#${orderId}</strong>.</p>

        <div style="background: #F9FAFB; padding: 24px; border-radius: 20px; border: 1px solid #E5E7EB; margin: 30px 0;">
            <table style="width: 100%; border-collapse: collapse;">
                <tr><td style="padding: 8px 0; color: #6B7280;">Mission ID:</td><td style="text-align: right; font-weight: 700; color: #111827;">#${orderId}</td></tr>
                <tr><td style="padding: 8px 0; color: #6B7280;">Item Description:</td><td style="text-align: right; font-weight: 600; color: #111827;">${itemDesc || 'Package'}</td></tr>
                <tr><td style="padding: 8px 0; color: #6B7280; font-weight: 700;">Total Paid:</td><td style="text-align: right; font-weight: 800; color: #008751; font-size: 18px;">₦${parseFloat(amount || 0).toLocaleString()}</td></tr>
            </table>
        </div>

        <p class="text">Our dispatch system is searching for the nearest available fulfiller. You can track your mission live in the Pikop app!</p>
    `;

    return await sendMail(to, subject, html);
};

/**
 * Sends Order Completion Notice Email.
 */
const sendOrderCompletionEmail = async (to, name, orderId, totalFare) => {
    const subject = `Mission #${orderId} Delivered!`;
    const html = `
        <h1 class="greeting" style="color: #008751;">Mission Completed!</h1>
        <p class="text">Hello <strong>${name || 'Customer'}</strong>,</p>
        <p class="text">Your delivery mission <strong>#${orderId}</strong> has been successfully completed and delivered.</p>

        <p class="text">Thank you for choosing Pikop Logistics! Please rate your agent's service in the app to help us maintain top quality.</p>
    `;

    return await sendMail(to, subject, html);
};

/**
 * Sends Password Reset OTP Email.
 */
const sendPasswordResetEmail = async (to, name, otpCode) => {
    const subject = "Pikop: Password Reset Verification Code";
    const html = `
        <h1 class="greeting">Password Reset Code</h1>
        <p class="text">Hello <strong>${name || 'User'}</strong>,</p>
        <p class="text">We received a request to reset your password for your Pikop account. Use the 6-digit verification code below to complete your password reset:</p>

        <div class="cta-container">
            <div class="otp-code">${otpCode}</div>
        </div>

        <p class="text">This code is valid for 15 minutes. If you did not request a password reset, please ignore this email or contact support if you have concerns.</p>
    `;

    return await sendMail(to, subject, html);
};

module.exports = {
  sendMail,
  sendWelcomeEmail,
  sendKycStatusEmail,
  sendPaymentReceiptEmail,
  sendOrderCompletionEmail,
  sendPasswordResetEmail
};
