const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const http = require('http');
const path = require('path');
const fs = require('fs');
const session = require('express-session');
const expressLayouts = require('express-ejs-layouts');
const compression = require('compression');
const { rateLimit } = require('express-rate-limit');
require('express-async-errors');
require('dotenv').config();

const app = express();
const server = http.createServer(app);

// 0. Ensure Directories Exist
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
  console.log(`✅ Created missing uploads directory at: ${UPLOADS_DIR}`);
}

// 0. Trust Proxy (Crucial for secure cookies behind Nginx)
app.set('trust proxy', 1);

// Initialize Sockets
const socketService = require('./services/socketService');
socketService.init(server);
console.log('✅ Sockets initialized');

// Start Background Jobs
try {
    const escrowWorker = require('./jobs/escrowWorker');
    escrowWorker.startEscrowWorker(15);
    console.log('✅ Escrow worker started');

    const weatherService = require('./services/weatherService');
    weatherService.startWeatherJob(15);
    console.log('✅ Weather service started');

    const dispatchReminderJob = require('./jobs/dispatchReminderJob');
    dispatchReminderJob.startReminderJob(3);
    console.log('✅ Dispatch reminder job started');

    const acknowledgmentReminderJob = require('./jobs/acknowledgmentReminderJob');
    acknowledgmentReminderJob.startAcknowledgmentJob(15);
    console.log('✅ Acknowledgment job started');

    const scheduledOrderJob = require('./jobs/scheduledOrderJob');
    scheduledOrderJob.startScheduledJob(10);
    console.log('✅ Scheduled order job started');

    const fleetJob = require('./jobs/fleetJob');
    fleetJob.startFleetJob(24);
    console.log('✅ Fleet job started');
} catch (jobError) {
    console.error('❌ Background Job Init Failed:', jobError.message);
}

// 1. Basic Middleware
app.use(compression()); // Optimize payload size
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors());
app.use(morgan('dev'));

// Global Anti-Caching Middleware for API V1
app.use('/api/v1', (req, res, next) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate, max-age=0');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

// Admin Latency Middleware
app.use('/admin', (req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    if (duration > 1000) {
      console.warn(`[Admin-Latency] SLOW: ${req.method} ${req.path} took ${duration}ms`);
    } else {
      console.log(`[Admin-Latency] ${req.method} ${req.path} - ${duration}ms`);
    }
  });
  next();
});

app.use(express.json({
  limit: '5mb', // Increased for large webhooks (e.g. Prembly)
  verify: (req, res, buf) => {
    if (req.originalUrl.includes('/webhook')) {
      req.rawBody = buf.toString();
    }
  }
}));
app.use(express.urlencoded({ extended: true }));

// 1.1 Rate Limiting (Brute Force Protection)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  limit: 1000, // Limit each IP to 1000 requests per window
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  skip: (req) => req.path === '/refresh' || req.path === '/fcm-token',
  message: { success: false, message: 'Too many requests, please try again later.' }
});

app.use('/api/v1/auth', authLimiter);
app.use('/admin/login', authLimiter);

// 2. Session Middleware (For Admin)
app.use(session({
  secret: process.env.JWT_SECRET || 'pikop_admin_secret_v3',
  resave: false,
  saveUninitialized: false,
  name: 'pikop.sid',
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// 3. View Engine
const viewsPath = path.join(__dirname, 'views');
app.set('views', viewsPath);
app.set('view engine', 'ejs');
app.use(expressLayouts);
app.set('layout', 'layout');

console.log(`[System] Views directory set to: ${viewsPath}`);

// 4. Static Files
app.use('/public', express.static(path.join(__dirname, '../public')));
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// 5. Routes
app.use('/admin', require('./routes/adminRoutes'));
app.use('/admin/reports', require('./routes/reportRoutes'));
app.use('/admin/finances', require('./routes/financialRoutes'));
app.use('/api/v1/auth', require('./routes/authRoutes'));
app.use('/api/v1/orders', require('./routes/orderRoutes'));
app.use('/api/v1/payments', require('./routes/paymentRoutes'));
app.use('/api/v1/fulfillers', require('./routes/fulfillerRoutes'));
app.use('/api/v1/support', require('./routes/supportRoutes'));
app.use('/api/v1/commerce', require('./routes/commerceRoutes'));
app.use('/api/v1/marketplace', require('./routes/marketplaceRoutes'));
app.use('/api/v1/kitchens', require('./routes/kitchenRoutes'));
app.use('/api/v1/wallets', require('./routes/walletRoutes'));
app.use('/api/v1/merchants', require('./routes/merchantRoutes'));
app.use('/api/v1/fleet-partners', require('./routes/fleetPartnerRoutes'));
app.use('/api/v1/corporate', require('./routes/corporateRoutes'));
app.use('/api/v1/expansion', require('./routes/expansionRoutes'));
app.use('/api/v1/growth', require('./routes/growthRoutes'));
app.use('/api/v1/promo-codes', require('./routes/growthRoutes')); // Legacy Compatibility
app.use('/api/v1/places', require('./routes/placesRoutes'));
app.use('/api/v1/addresses', require('./routes/addressRoutes'));
app.use('/api/v1/settings', require('./routes/settingsRoutes'));
app.use('/api/v1/webhooks', require('./routes/webhookRoutes'));
app.use('/api/v1/legal', require('./routes/legalRoutes'));
app.use('/legal', require('./routes/legalRoutes')); // Web-friendly fallback
app.use('/terms', require('./routes/legalRoutes')); // Root-level terms fallback
app.get('/terms/fulfiller', require('./controllers/legalController').getFulfillerTerms);
app.get('/terms-fulfiller', require('./controllers/legalController').getFulfillerTerms);

// 6. Health & Base Routes
app.get('/health', (req, res) => res.json({ status: 'UP', timestamp: new Date(), version: '3.0.0-core' }));
app.get('/', (req, res) => res.json({ message: 'Pikop V3 API - Professional Multi-Platform Logistics', status: 'ONLINE' }));

// 7. Global Error Handler (Harden Core)
app.use((err, req, res, next) => {
    console.error(`[Error] ${req.method} ${req.path} >>`, err.stack);

    const status = err.status || 500;
    const message = err.message || 'Internal Server Error';

    res.status(status).json({
        success: false,
        error: {
            code: status,
            message: process.env.NODE_ENV === 'production' ? 'An unexpected error occurred' : message,
            path: req.path
        }
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`\n🚀 PIKOP V3 API RESTORED`);
    console.log(`📡 Network: http://0.0.0.0:${PORT}`);
    console.log(`🕒 Mode: ${process.env.NODE_ENV || 'production'}\n`);
});

module.exports = app;
