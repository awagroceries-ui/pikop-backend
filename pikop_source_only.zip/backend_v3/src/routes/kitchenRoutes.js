const express = require('express');
const router = express.Router();
const kitchenController = require('../controllers/kitchenController');
const { authenticateToken } = require('../middleware/authMiddleware');

// Public Browsing
router.get('/', kitchenController.getKitchens);
router.get('/:id', kitchenController.getKitchenDetails);

// Kitchen Management (Authenticated)
router.post('/menu-items', authenticateToken, kitchenController.addMenuItem);
router.patch('/menu-items/:id', authenticateToken, kitchenController.updateMenuItem);
router.delete('/menu-items/:id', authenticateToken, kitchenController.deleteMenuItem);

module.exports = router;
