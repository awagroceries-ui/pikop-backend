const express = require('express');
const router = express.Router();
const merchantController = require('../controllers/merchantController');
const { authenticateToken } = require('../middleware/authMiddleware');
const { authenticateMerchantKey } = require('../middleware/merchantAuth');

// Account Registration (User session)
router.post('/register', authenticateToken, merchantController.registerMerchant);
router.post('/setup', authenticateToken, merchantController.setupMerchantProfile);
router.patch('/settings', authenticateToken, merchantController.updateMerchantSettings);
router.get('/slug/:slug', authenticateToken, merchantController.getMerchantBySlug);
router.get('/dashboard', authenticateToken, merchantController.getSellerDashboard);
router.get('/analytics', authenticateToken, merchantController.getMerchantAnalytics);
router.get('/profile', authenticateToken, merchantController.getMerchantProfile);
router.get('/my-batches', authenticateToken, merchantController.getMyBatches);
router.get('/my-batches/:batchId', authenticateToken, merchantController.getBatchStatus);
router.post('/orders/bulk-session', authenticateToken, merchantController.createBulkOrdersSession);

// Promotion Management (v4.7)
router.get('/coupons', authenticateToken, merchantController.getMerchantCoupons);
router.post('/coupons', authenticateToken, merchantController.createMerchantCoupon);

router.get('/orders', authenticateToken, merchantController.getIncomingOrders);
router.patch('/orders/:id/status', authenticateToken, merchantController.updateOrderStatus);

// Return Management (v4.2)
router.get('/returns', authenticateToken, merchantController.getReturnRequests);
router.post('/returns/:returnId/process', authenticateToken, merchantController.processReturnRequest);
router.post('/returns/:returnId/confirm-receipt', authenticateToken, merchantController.confirmReturnReceipt);

// Programmatic Bulk Operations (API Key)
router.post('/orders/bulk', authenticateMerchantKey, merchantController.createBulkOrders);
router.get('/batches', authenticateMerchantKey, merchantController.getBatches);
router.get('/batches/:batchId', authenticateMerchantKey, merchantController.getBatchStatus);

module.exports = router;
